### Tutorial

Data Download: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM4185643

Orginal paper:

Weinreb, C., Rodriguez-Fraticelli, A., Camargo, F. D., & Klein, A. M. (2020). Lineage tracing on transcriptional landscapes links state to fate during differentiation. Science (New York, N.Y.), 367(6479), eaaw3381. https://doi.org/10.1126/science.aaw3381

Plots recreated may not be a 1-1 match.
