from socket import *
import sys
import getopt
import os
from datetime import datetime
from email.utils import parsedate_to_datetime

def main(argv):
    serverPort = 6789

    # Get the port number at startup, default to 6789
    try:
        opts, args = getopt.getopt(argv, "hp:", ["port="])
    except getopt.GetoptError:
        print('webserver.py -p <port number>')
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-h':
            print('webserver.py -p <port number>')
            sys.exit()
        elif opt in ("-p", "--port"):
            serverPort = int(arg)

    print('Server is running on port ', serverPort)

    # Create a TCP server socket
    serverSocket = socket(AF_INET, SOCK_STREAM)
    serverSocket.bind(("", serverPort))
    serverSocket.listen(1)

    while True:
        print('The server is ready to receive data....')
        connectionSocket, addr = serverSocket.accept()

        try:
            message = connectionSocket.recv(1024).decode('UTF-8')
            if not message:
                connectionSocket.close()
                continue

            # Parse HTTP request
            request_lines = message.split("\r\n")
            request_line = request_lines[0]
            request_parts = request_line.split()

            if len(request_parts) < 2:
                raise IOError("Malformed HTTP request.")

            method = request_parts[0]
            path = request_parts[1]

            # Handle unsupported HTTP methods
            unsupported_methods = ["POST", "HEAD", "PUT", "DELETE", "CONNECT", "OPTIONS", "TRACE"]

            if method in unsupported_methods:
                response = "HTTP/1.1 405 Method Not Allowed\r\n"
                response += "Content-Type: text/html\r\n"
                response += "Connection: close\r\n\r\n"
                response += "<html><head></head><body><h1>405 Method Not Allowed</h1></body></html>"
                connectionSocket.send(response.encode('UTF-8'))
                connectionSocket.close()
                continue
            
           
            # Handle root path
            if path.endswith("/") or path == "/":
                path = path + "index.html"
                print("heres the path: " + path)
            elif path.endswith(".htm"):
                path = path[:-4] + ".html"
            elif path.endswith(".xml"):
                response = (
                    "HTTP/1.1 415 Unsupported Media Type\r\n"
                    f"Date: {datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')}\r\n"
                    "Content-Type: text/html\r\n"
                    "Connection: close\r\n\r\n"
                    "<html><head></head><body><h1>415 Unsupported Media Type</h1></body></html>"
                )
                connectionSocket.send(response.encode('UTF-8'))
                connectionSocket.close()
                continue
            
            if not os.path.splitext(path)[1]:
                path = path + ".html"

            path = os.path.normpath(path.lstrip("/"))
            filepath = os.path.join(os.getcwd(), path)

            print(f"Resolved file path: {filepath}")

            if not os.path.exists(filepath) or not os.path.isfile(filepath):
                raise IOError("File not found.")

            # Check for If-Modified-Since header
            if_modified_since = None
            for header in request_lines[1:]:
                if header.lower().startswith("if-modified-since:"):
                    if_modified_since = header.split(":", 1)[1].strip()
                    break

            file_last_modified = datetime.utcfromtimestamp(os.path.getmtime(filepath))

            if if_modified_since:
                try:
                    if_modified_since_date = parsedate_to_datetime(if_modified_since)
                    if file_last_modified <= if_modified_since_date:
                        # File has not been modified
                        response = (
                            "HTTP/1.1 304 Not Modified\r\n"
                            f"Date: {datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')}\r\n"
                            "Connection: close\r\n\r\n"
                        )
                        connectionSocket.send(response.encode('UTF-8'))
                        connectionSocket.close()
                        continue
                except (TypeError, ValueError):
                    pass

            # Determine file type for MIME type header
            _, ext = os.path.splitext(filepath)
            mime_type = "text/plain"
            if ext in [".html", ".htm"]:
                mime_type = "text/html"
            elif ext == ".jpg":
                mime_type = "image/jpeg"
            elif ext == ".png":
                mime_type = "image/png"
            elif ext == ".gif":
                mime_type = "image/gif"
            elif ext == ".css":
                mime_type = "text/css"
            elif ext == ".js":
                mime_type = "application/javascript"
            elif ext == ".pdf":
                mime_type = "application/pdf"

            with open(filepath, "rb") as file:
                content = file.read()

            response_header = (
                f"HTTP/1.1 200 OK\r\n"
                f"Date: {datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')}\r\n"
                f"Content-Type: {mime_type}\r\n"
                f"Last-Modified: {file_last_modified.strftime('%a, %d %b %Y %H:%M:%S GMT')}\r\n"
                f"Content-Length: {len(content)}\r\n"
                "Connection: close\r\n\r\n"
            )

            connectionSocket.send(response_header.encode('UTF-8'))
            connectionSocket.send(content)

        except IOError as e:
            print(f"Error: {e}")
            connectionSocket.send("HTTP/1.1 404 Not Found\r\n\r\n".encode('UTF-8'))
            connectionSocket.send("<html><head></head><body><h1>404 Not Found</h1></body></html>\r\n".encode('UTF-8'))
        finally:
            connectionSocket.close()

    serverSocket.close()
    sys.exit()

if __name__ == "__main__":
    main(sys.argv[1:])
