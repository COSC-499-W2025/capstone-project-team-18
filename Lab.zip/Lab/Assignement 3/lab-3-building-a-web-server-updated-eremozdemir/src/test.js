function msg(){
 alert("My Javascript works!");
}
