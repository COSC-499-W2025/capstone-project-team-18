package IMClient;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class IMClient {
    // Protocol and system constants
    public static final String serverAddress = "localhost";
    public static final int TCPServerPort = 1234;   // TCP port for server communication
    public static final int UDPServerPort = 1235;     // UDP port for server communication
    private int TCPMessagePort = 0;                  // TCP port for direct client communication, dynamically assigned

    public static final String onlineStatus = "100 ONLINE";
    public static final String offlineStatus = "101 OFFLINE";

    private BufferedReader reader;  // For reading user input
    private String userId;
    private String status;
    private DatagramSocket udpSocket;         // UDP socket for sending status updates
    private ServerSocket welcomeSocket;       // For receiving direct messages
    private Map<String, BuddyInfo> buddies = new HashMap<>();  // Buddy info stored with keys in lower-case

    // Inner class to hold buddy details.
    private class BuddyInfo {
        String status;
        InetAddress address;
        int port;

        BuddyInfo(String status, InetAddress address, int port) {
            this.status = status;
            this.address = address;
            this.port = port;
        }
    }

    public static void main(String[] argv) throws Exception {
        IMClient client = new IMClient();
        client.execute();
    }

    public IMClient() throws SocketException, IOException {
        userId = null;
        status = offlineStatus;
        udpSocket = new DatagramSocket();  // Create UDP socket for status updates
        initializeWelcomeSocket();
    }

    // Bind to an ephemeral port for direct client-to-client messaging.
    private void initializeWelcomeSocket() throws IOException {
        welcomeSocket = new ServerSocket(0);  // OS selects an available port
        TCPMessagePort = welcomeSocket.getLocalPort();
        System.out.println("Listening for direct messages on port: " + TCPMessagePort);
        new Thread(() -> {
            while (true) {
                try {
                    Socket connection = welcomeSocket.accept();
                    handleIncomingMessage(connection);
                } catch (IOException e) {
                    System.out.println("Error handling incoming message: " + e.getMessage());
                    break;
                }
            }
        }).start();
    }

    public void execute() throws Exception {
        String choice;
        reader = new BufferedReader(new InputStreamReader(System.in));
        printMenu();
        choice = reader.readLine().toUpperCase();
        while (!choice.equals("X")) {
            switch (choice) {
                case "R":
                    registerUser();
                    break;
                case "L":
                    loginUser();
                    break;
                case "A":
                    addBuddy();
                    break;
                case "D":
                    deleteBuddy();
                    break;
                case "M":
                    startMessaging();
                    break;
                case "S":
                    getBuddyStatus();
                    break;
                default:
                    System.out.println("Invalid input!");
                    break;
            }
            printMenu();
            choice = reader.readLine().toUpperCase();
        }
        shutdown();
    }

    // Check that the provided ID contains only letters and digits.
    private boolean isValidUserId(String id) {
        return id.matches("[a-zA-Z0-9]+");
    }

    // Check locally if the user is registered (file exists).
    private boolean localUserExists(String id) {
        File f = new File(id + ".txt");
        return f.exists();
    }

    private void registerUser() throws IOException {
        Socket clientSocket = new Socket(serverAddress, TCPServerPort);
        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        System.out.print("Enter user id to register: ");
        userId = reader.readLine().trim();
        if (!isValidUserId(userId)) {
            System.out.println("Invalid user id format. Use letters and numbers only.");
            clientSocket.close();
            return;
        }
        String command = "REG " + userId;
        outToServer.writeBytes(command + "\n");
        String response = inFromServer.readLine();
        System.out.println("FROM SERVER: " + response);
        clientSocket.close();
        if (response.startsWith("200")) {
            status = onlineStatus;
            sendUDPStatus();
        }
    }

    private void loginUser() throws IOException {
        System.out.print("Enter user id: ");
        userId = reader.readLine().trim();
        if (!isValidUserId(userId)) {
            System.out.println("Invalid user id format. Use letters and numbers only.");
            return;
        }
        // Ensure the user is registered (file exists)
        if (!localUserExists(userId)) {
            System.out.println("User does not exist. Please register first.");
            return;
        }
        status = onlineStatus;
        System.out.println("User id set to: " + userId);
        sendUDPStatus();
    }

    private void addBuddy() throws IOException {
        if (userId == null) {
            System.out.println("Please log in first.");
            return;
        }
        System.out.print("Enter buddy user ID to add: ");
        String buddyId = reader.readLine().trim();
        if (!isValidUserId(buddyId)) {
            System.out.println("Invalid buddy user ID format. Use letters and numbers only.");
            return;
        }
        if (buddyId.equalsIgnoreCase(userId)) {
            System.out.println("You cannot add yourself as a buddy.");
            return;
        }
        try (Socket clientSocket = new Socket(serverAddress, TCPServerPort);
             DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
             BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
            String command = "ADD " + userId + " " + buddyId;
            outToServer.writeBytes(command + "\n");
            String response = inFromServer.readLine();
            System.out.println("Server response: " + response);
        }
    }

    private void deleteBuddy() throws IOException {
        if (userId == null) {
            System.out.println("Please log in first.");
            return;
        }
        System.out.print("Enter buddy user ID to delete: ");
        String buddyId = reader.readLine().trim();
        if (!isValidUserId(buddyId)) {
            System.out.println("Invalid buddy user ID format. Use letters and numbers only.");
            return;
        }
        if (buddyId.equalsIgnoreCase(userId)) {
            System.out.println("You cannot delete yourself.");
            return;
        }
        try (Socket clientSocket = new Socket(serverAddress, TCPServerPort);
             DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
             BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
            String command = "DEL " + userId + " " + buddyId;
            outToServer.writeBytes(command + "\n");
            String response = inFromServer.readLine();
            System.out.println("Server response: " + response);
        }
    }

    private void startMessaging() throws IOException {
        if (userId == null) {
            System.out.println("Please log in first.");
            return;
        }
        System.out.print("Enter buddy user ID to message: ");
        String buddyId = reader.readLine().trim();
        if (!isValidUserId(buddyId)) {
            System.out.println("Invalid buddy user ID format. Use letters and numbers only.");
            return;
        }
        // Look up buddy info in our map (keys stored in lower-case)
        BuddyInfo buddy = buddies.get(buddyId.toLowerCase());
        if (buddy == null || !buddy.status.equals(onlineStatus)) {
            System.out.println("Buddy not found or not online.");
            return;
        }
        try (Socket connectionSocket = new Socket(buddy.address, buddy.port);
             DataOutputStream outToBuddy = new DataOutputStream(connectionSocket.getOutputStream());
             BufferedReader inFromBuddy = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()))) {
            System.out.println("Connected to buddy. Type 'exit' to end.");
            Scanner scanner = new Scanner(System.in);
            String message;
            while (!(message = scanner.nextLine()).equalsIgnoreCase("exit")) {
                outToBuddy.writeBytes(message + "\n");
                String reply = inFromBuddy.readLine();
                System.out.println("Buddy says: " + reply);
            }
        }
    }

    private void sendUDPStatus() throws IOException {
        String statusMessage = "SET " + userId + " " + status + " " + TCPMessagePort;
        byte[] sendData = statusMessage.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,
                InetAddress.getByName(serverAddress), UDPServerPort);
        udpSocket.send(sendPacket);
    }

    private void getBuddyStatus() throws IOException {
        String request = "GET " + userId;
        byte[] sendData = request.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,
                InetAddress.getByName(serverAddress), UDPServerPort);
        udpSocket.send(sendPacket);

        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        udpSocket.receive(receivePacket);
        String statusList = new String(receivePacket.getData(), 0, receivePacket.getLength());
        System.out.println("Buddy Statuses:\n" + statusList);
        parseBuddyStatuses(statusList);
    }

    // Expected format per buddy: "<buddyId> <statusCode> <statusText> <IPaddress> <port>"
    // This method clears the buddy map before updating it.
    private void parseBuddyStatuses(String data) {
        buddies.clear();
        String[] entries = data.split("\n");
        for (String entry : entries) {
            String[] parts = entry.split(" ");
            if (parts.length >= 5) {
                String id = parts[0].trim().toLowerCase();
                if (!isValidUserId(id)) {
                    System.out.println("Skipping invalid buddy id: " + id);
                    continue;
                }
                String stat = parts[1].trim() + " " + parts[2].trim();
                try {
                    InetAddress address = InetAddress.getByName(parts[3].trim());
                    int port = Integer.parseInt(parts[4].trim());
                    buddies.put(id, new BuddyInfo(stat, address, port));
                } catch (NumberFormatException | UnknownHostException e) {
                    System.out.println("Error updating buddy info: " + e.getMessage());
                }
            }
        }
        // Debug: print buddy keys
        System.out.println("Updated buddy map keys:");
        for (String key : buddies.keySet()) {
            System.out.println("  " + key);
        }
    }

    private void handleIncomingMessage(Socket connection) throws IOException {
        BufferedReader inFromBuddy = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        DataOutputStream outToBuddy = new DataOutputStream(connection.getOutputStream());
        String receivedMessage;
        while ((receivedMessage = inFromBuddy.readLine()) != null) {
            System.out.println("Message from buddy: " + receivedMessage);
            // Echo the message back
            outToBuddy.writeBytes("Echo: " + receivedMessage + "\n");
        }
        connection.close();
    }

    private void shutdown() throws IOException {
        if (udpSocket != null && !udpSocket.isClosed()) {
            udpSocket.close();
        }
        if (welcomeSocket != null && !welcomeSocket.isClosed()) {
            welcomeSocket.close();
        }
        System.out.println("Client shutdown.");
    }

    private void printMenu() {
        System.out.println("\nChoose an option:");
        System.out.println("R - Register");
        System.out.println("L - Login");
        System.out.println("A - Add Buddy");
        System.out.println("D - Delete Buddy");
        System.out.println("M - Message Buddy");
        System.out.println("S - Show Status");
        System.out.println("X - Exit");
        System.out.print("Your choice: ");
    }
}
