## Labs - Week 5 (DFD and UML Class Diagrams)

### DFD L0, L1
![Level 0](Level_0_DFD.drawio.png)

![Level 1](L1_DFD_Diagram.drawio.png)


### UML class Diagram:

![UML Diagram](UMLDiagram.drawio.png)

