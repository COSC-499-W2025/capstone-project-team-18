# What is in the `client` directory?

The `client` directory contains the files neccessary to run the Tkinter part of this application, which serves the frontend to the user for this app. It contains the following directories and files:

- The `src` directory: Contains all related Python files for Tkinter 
- `Dockerfile`: Neccessary for creating an image of our Tkinter app. 
- `requirements.txt`: Contains all libraries that are used in the Tkinter app. Docker will run a `pip install` command which reads the libraries that are in this file and installs them in the Docker container. 
- `README.md`: The file you are currently reading from.

**For information on what Docker is and why we need to use programs such as XQuartz for the GUI, refer to [this markdown file](Docker-X11-VcXsrv.md).

# Running a GUI in Docker

### macOS (and other Unix-based operating systems)

1. Install [XQuartz](https://www.xquartz.org/)

2. Restart your computer

3. Open up your terminal and open XQuartz
```open -a XQuartz```

5. Go the the XQuartz terminal and allow localhost type:
```xhost + 127.0.0.1```

6. Go back to this repo and run docker compose up. You should see the GUI pop up in the corner!

## Windows

*Note: you only need to follow steps 1 & 2 on the first time. Any time after, make sure that Docker Desktop is open before you follow step 3. and onwards*s

1. Install [Docker Desktop](https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe?utm_source=docker&utm_medium=webreferral&utm_campaign=docs-driven-download-win-amd64) 
    - After you install, go to Settings -> General, then scroll down until you see"Use the WSL 2 based engine" and make sure that it is selected. Then, go to Resources -> WSL integration, and make sure that "Enable integration with my default WSL distro" is selected. Docker will automatically install WSL2 for you, which is neccessary for our Tkinter GUI.
2. Install [VcXsrv](https://sourceforge.net/projects/vcxsrv/) from SourceForge.
3. Open VcXsrv- it will be an app called `XLaunch`.
4. Configure your X server in XLaunch:
    1. Ensure that "Multiple windows" is selected, not "Fullscreen", "One large window", or "One window without tilebar". Leave the display number as -1, then click "Next".
    2. Select "Start no client", then select "Next".
    3. Make sure that "Clipboard, "Primary Selection", and "Native opengl" are all selected. Then select "Next".
    4. Select "Finish". Your XServer is now running locally and is waiting to display something.
5. Create a new terminal in VS Code and run `docker compose up`. This will read the `docker-compose.yml` file in the main directory and should open a small GUI in the top-left of your screen.
