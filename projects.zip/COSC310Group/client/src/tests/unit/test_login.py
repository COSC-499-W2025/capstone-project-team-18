import pytest
from unittest.mock import MagicMock, patch
from tkinter import Tk
from Classes.Frames.Login.login import LoginWindow
from Classes.Util.server_req import ServerRequest
from app import App

"""
This file will test the login frame
"""

@pytest.fixture
def app():
    root = App()
    yield root
    root.destroy()

@pytest.fixture
def login_window(app):
    return LoginWindow(app, None)

def test_create_widgets(login_window):
    """
    Ensure widgets get created! We shouldn't see nothing
    """
    assert login_window.user_entry is not None
    assert login_window.pass_entry is not None

def test_authenticate_success(login_window):
    """
    Here, we test with a vaild username and password.
    We mock the response of ServerRequest.login to
    mimic a successful login.

    We test that a valid username and password will
    run the function login_success.
    """
    login_window.user_entry.insert(0, "johndoe")
    login_window.pass_entry.insert(0, "!hashmeplease!")

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {'user_role': 'student'}

    with patch.object(ServerRequest, 'login', return_value=mock_response):
        with patch.object(login_window, 'login_success') as mock_login_success:
            login_window.authenticate()
            mock_login_success.assert_called_once_with('student')

def test_authenticate_missing_username(login_window):
    """
    Same logic setup as above. But this time we verify
    that tkiner gives the user and warning about missing
    user name and password.
    """
    login_window.user_entry.insert(0, "")
    login_window.pass_entry.insert(0, "irrelevant_pswd")

    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.json.return_value = {'bad request': 'missing username'}


    with patch.object(ServerRequest, 'login', return_value=mock_response):
        with patch('tkinter.messagebox.showinfo') as mock_showinfo:
            login_window.authenticate()
            mock_showinfo.assert_called_once_with("Error", "Missing username. Please enter and try again.")

def test_authenticate_missing_password(login_window):
    """
    We do the same as above, but we ensure that
    the message box with an apporiate error appears
    """
    login_window.user_entry.insert(0, "wronguser")
    login_window.pass_entry.insert(0, "")

    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.json.return_value = {'bad request': 'missing pswd'}


    with patch.object(ServerRequest, 'login', return_value=mock_response):
        with patch('tkinter.messagebox.showinfo') as mock_showinfo:
            login_window.authenticate()
            mock_showinfo.assert_called_once_with("Error", "Missing password. Please enter and try again.")

def test_authenticate_invalid_credentials(login_window):
    """
    We do the same as above, but we ensure that
    the message box with an apporiate error appears
    """
    login_window.user_entry.insert(0, "wronguser")
    login_window.pass_entry.insert(0, "wrongpass")

    mock_response = MagicMock()
    mock_response.status_code = 401

    with patch.object(ServerRequest, 'login', return_value=mock_response):
        with patch('tkinter.messagebox.showinfo') as mock_showinfo:
            login_window.authenticate()
            mock_showinfo.assert_called_once_with("Error", "Invalid credentials, try again")

