"""
This file tests the GlobalState class.
"""

import pytest

from Classes.Util.global_state import GlobalState

@pytest.fixture(scope='function', autouse=True)
def global_state_object():

    global_state = GlobalState()
    yield global_state

def test_throw_error_before_login(global_state_object):
    """
    Throw an error if we try to get role before
    we are logged in
    """
    with pytest.raises(ValueError):
        global_state_object.is_user_admin()

def test_global_state_is_singleton(global_state_object):
    """
    Ensure that the object is a singleton
    """
    assert global_state_object == GlobalState()

def test_login_logout(global_state_object):
    """
    Login and logout test that global state
    knows what state we are in
    """
    global_state_object.login(True)
    global_state_object.logout()

    assert not global_state_object.is_user_logged_in()
    with pytest.raises(ValueError):
        global_state_object.is_user_admin()
