"""
Here are unit tests for the app.py. It will prompt you the following
"""
import pytest
from unittest.mock import patch
from app import App

from Classes.Frames.Login.login import LoginFrameFactory
from Classes.Frames.Dashboard.admin_dashboard import AdminDashboardFactory
from Classes.Frames.Dashboard.student_dashboard import StudentDashboardFactory

@pytest.fixture(scope="function", autouse=True)
def app_object():
    app = App()
    yield app
    app.destroy()

def test_app_starts_on_login(app_object):
    """
    Here we simply test that the app starts on the
    LoginFrame.
    """

    app = app_object

    assert app.display_frame.current_frame_state == (LoginFrameFactory, ())

def test_app_frame_stack(app_object):
    """
    Here will verify that the stack of
    frames is valid.
    """
    app = app_object.display_frame

    app.frame_stack = []
    app.current_frame_state = None

    expected_frame_stack = [
        (LoginFrameFactory, ())
    ]

    expected_current_frame_state = (StudentDashboardFactory, ())

    app.show_frame(LoginFrameFactory(), ())
    app.show_frame(LoginFrameFactory(), ())
    app.show_frame(StudentDashboardFactory(), ())
    app.show_frame(StudentDashboardFactory(), ())
    app.show_frame(StudentDashboardFactory(), ())

    assert app.frame_stack == expected_frame_stack
    assert app.current_frame_state == expected_current_frame_state

def test_app_go_back(app_object):
    """
    Test the go_back functionality.
    """
    app = app_object.display_frame

    app.show_frame(LoginFrameFactory(), ())
    app.show_frame(StudentDashboardFactory(), ())

    with patch('tkinter.messagebox.askyesno', return_value=True):
        app.go_back()

    assert app.current_frame_state == (LoginFrameFactory, ())

def test_app_log_out(app_object):
    """
    Test the log_out functionality.
    """
    app = app_object.display_frame

    app.show_frame(LoginFrameFactory(), ())
    app.show_frame(StudentDashboardFactory(), ())

    with patch('tkinter.messagebox.askyesno', return_value=True):
        app.log_out()

    assert app.current_frame_state == (LoginFrameFactory, ())
    assert app.frame_stack == []

def test_app_show_my_profile_before_login(app_object):
    """
    Test the show_my_profile functionality.
    """
    app = app_object.display_frame

    with patch("tkinter.messagebox.showinfo", return_value=None):
        app.show_my_profile()

    assert app.current_frame_state == (LoginFrameFactory, ())

def test_app_refresh_current_frame(app_object):
    """
    Test the refresh_current_frame functionality.
    """
    app = app_object.display_frame

    app.show_frame(StudentDashboardFactory(), ())
    app.refresh_current_frame()

    assert app.current_frame_state == (StudentDashboardFactory, ())
