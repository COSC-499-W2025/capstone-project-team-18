import pytest
import tkinter as tk
from unittest.mock import Mock
from Classes.Frames.StudentManagment.sidebar import SideBar

@pytest.fixture
def root():
    return tk.Tk()

@pytest.fixture
def sidebar_container(root):
    return tk.Frame(root)

@pytest.fixture
def switch_screen_callback():
    return Mock()

@pytest.fixture
def sidebar(sidebar_container, switch_screen_callback):
    return SideBar(
        sidebar_container=sidebar_container,
        switch_screen_callback=switch_screen_callback,
        user_own_profile=True,
        user_is_admin=False,
        student_pk=1
    )

def test_sidebar_initialization(sidebar):
    """Test if the sidebar is initialized correctly."""
    assert isinstance(sidebar, tk.Frame)
    assert hasattr(sidebar, 'switch_screen')


def test_modify_visual_aspects(sidebar):
    """Test if the visual aspects are correctly modified."""
    assert sidebar.cget("relief") == "solid"
    assert sidebar.cget("bd") == 2


def test_create_option_edit_personal_details(sidebar, switch_screen_callback):
    """Test if clicking 'Edit Personal Details' triggers the correct callback."""
    for widget in sidebar.winfo_children():
        if isinstance(widget, tk.Button) and "Edit Personal Details" in widget.cget("text"):
            widget.invoke()
            switch_screen_callback.assert_called_once()
            break
    else:
        pytest.fail("Edit Personal Details button not found")


def test_create_option_edit_current_enrollments(sidebar, switch_screen_callback):
    """Test if clicking 'Edit Current Enrollments' triggers the correct callback."""
    for widget in sidebar.winfo_children():
        if isinstance(widget, tk.Button) and "Edit Current Enrollments" in widget.cget("text"):
            widget.invoke()
            switch_screen_callback.assert_called()
            break
    else:
        pytest.fail("Edit Current Enrollments button not found")


def test_invalid_case():
    """Test that an invalid case raises a ValueError."""
    with pytest.raises(ValueError, match="Students cannot manage others"):
        SideBar(
            sidebar_container=tk.Frame(),
            switch_screen_callback=Mock(),
            user_own_profile=False,
            user_is_admin=False,
            student_pk=1
        )
