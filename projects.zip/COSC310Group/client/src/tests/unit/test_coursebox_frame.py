"""
This file tests the coursebox class.
"""

import pytest
from unittest.mock import MagicMock, patch
from tkinter import Tk
from Classes.Frames.Dashboard.course_student_box import coursebox
from typing import Callable
from app import App

@pytest.fixture
def app():
    root = App()
    yield root
    root.destroy()

@pytest.fixture
def course_box(app):
    """
    Here we just make a random Course that we will use
    """
    parent = Tk()
    course_box = coursebox(
        subject="CS",
        coursenum="101",
        coursename="Intro to CS",
        coursedesc="This is an introductory course to Computer Science.",
        studentcount=10,
        maxstudents=30,
        coursestatus="Open",
        student_is_enrolled=False,
        student_is_waitlisted=False,
        course_pk=1,
        waitlist_pos=0,
        parent=parent,
        refresh_frame=lambda : None,
        controller=app
    )
    yield course_box

    parent.destroy()

def test_coursebox_enroll(course_box):
    """
    Tests that student can enroll
    """

    server_req = course_box.controller.server_req
    server_req.enroll_student = MagicMock(return_value={"placement": "enrolled"})

    with patch("tkinter.messagebox.showinfo"):
        course_box.on_coursebox_click()
        server_req.enroll_student.assert_called_once_with(course_box.course_pk)

def test_coursebox_drop(course_box):
    """
    Tests that a course can be dropped
    """
    course_box.student_is_enrolled = True
    course_box.rbutton.config(text="Drop Course")

    server_req = course_box.controller.server_req
    server_req.drop_student = MagicMock(return_value={"msg": "Student deleted off enrollment"})

    with patch('tkinter.messagebox.askyesno', return_value=True):
        with patch('tkinter.messagebox.showinfo'):
            course_box.on_coursebox_click()
            server_req.drop_student.assert_called_once_with(course_box.course_pk)

def test_coursebox_leave_waitlist(course_box):
    """
    Tests student can leave the waitlist
    """
    course_box.student_is_waitlisted = True
    course_box.rbutton.config(text="Leave Waitlist")

    server_req = course_box.controller.server_req
    server_req.drop_student = MagicMock(return_value={"msg": "Student deleted off waitlist"})

    with patch('tkinter.messagebox.askyesno', return_value=True):
        with patch('tkinter.messagebox.showinfo'):
            course_box.on_coursebox_click()
            server_req.drop_student.assert_called_once_with(course_box.course_pk)

def test_coursebox_toggle_description(course_box):
    """
    Tests description
    """
    assert not course_box.descopen
    course_box.toggledesc()
    assert course_box.descopen
    assert course_box.descdrop.cget("text") == "Description: ▲"
    course_box.toggledesc()
    assert not course_box.descopen
    assert course_box.descdrop.cget("text") == "Description: ▼"
