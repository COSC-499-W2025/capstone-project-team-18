import pytest
import tkinter as tk
from unittest.mock import patch, MagicMock
from Classes.Frames.StudentManagment.SubScreens.show_enrollments import ShowCourseBoxEnrollments

@pytest.fixture
def root():
    """Create a Tkinter root window for testing."""
    return tk.Tk()

def test_initialization(root):
    """Test initialization of ShowCourseBoxEnrollments."""

    with patch.object(ShowCourseBoxEnrollments, 'define_body_visual_elements') as mock_method:

        frame = ShowCourseBoxEnrollments(root, student_pk=1, titleOfPage="Student Courses")

        mock_method.assert_called_once()

        assert frame.student_pk == 1
        assert frame.titleOfPage == "Student Courses"
