"""
Unit tests for the server_req class, which is responsible for making HTTP requests to a server.
The tests cover the following functionalities:
- Initialization of the ServerRequest object with different environment variables.
- The ping method to check server connectivity.
- The __make_request method for making POST requests and handling invalid request methods.
Tested Functions:
- test_server_request_initialization: Tests the initialization of the ServerRequest object with and without environment variables.
- test_ping: Tests the ping method to ensure it correctly pings the server.
- test_make_request_post_login_success: Tests the __make_request method for a successful POST login request.
- test_make_request_invalid_method: Tests the __make_request method for handling invalid request methods.

"""
from unittest.mock import patch, MagicMock
import pytest
from Classes.Util.server_req import ServerRequest

@pytest.fixture()
def adminReq():
    admin_req = ServerRequest()
    admin_req.login('suebelcher', 'admin')

    yield admin_req

@pytest.fixture()
def studentReq():
    client_req  = ServerRequest()
    client_req.login('johndoe', '!hashmeplease!')

    yield client_req

@pytest.fixture()
def john_doe_pk():
    client_req  = ServerRequest()
    client_req.login('johndoe', '!hashmeplease!')
    student_info = client_req.get_student()

    client_req.log_out()

    yield student_info.get('id')


def test_for_singleton():
    """
    Test that if two different ServerRequest objects are
    created, they point to the same object instance
    """
    s1 = ServerRequest()
    s2 = ServerRequest()
    assert id(s1) == id(s2)

def test_ping():
    """
    Tests the ping method to ensure it correctly calls the /ping endpoint
    and returns the expected response.
    """
    req = ServerRequest()
    with patch("requests.get") as mock_get:
        mock_get.return_value.text = "pong"
        response = req.ping()
        assert response == "pong"
        mock_get.assert_called_once_with("http://localhost:8000/ping", timeout=5)

def test_make_request_post_login_success():
    """
    Tests the __make_request method for a successful POST login request.
    It should call the server with the correct authentication details.
    """
    server_req = ServerRequest()
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"status": "login-success", 'message': 'Login successful'}
    mock_response.token = '123'

    # `with patch` temporarily replaces the requests.post function with a mock object
    with patch("requests.post", return_value=mock_response) as mock_post:

        response = server_req._ServerRequest__make_request(
            "POST", {"username": "johndoe", "pswd": "!hashmeplease!"}, "/auth/login"
        )

        mock_post.assert_called_once_with("http://localhost:8000/auth/login", json={'username':"johndoe", 'pswd' : "!hashmeplease!"}, timeout=5)
        assert response.status_code == 200

def test_make_request_invalid_method():
    """
    Tests the __make_request method for an invalid HTTP method.
    It should return an error message when an unsupported method is used.
    """
    req = ServerRequest()
    response = req._ServerRequest__make_request("INVALID", {}, "/test")
    assert response == {"Error": "Invalid request. Try again."}

def test_get_course_by_parameters_valid():
    """
    Test getting a course by valid parameters.
    """

    params = {
        'department': 'COSC',
        'course_code': '101',
        'year': 2022,
        'session': 'Winter'
    }

    response = ServerRequest().get_courses(**params)

    for course in response:
        for key, value in params.items():
            assert course[key] == value

def test_get_course_by_parameters_invalid():
    """
    Test getting a course by invalid parameters.
    """

    params = {
        'department': 'INVALID',
        'course_code': '999',
        'year': 2022,
        'session': 'Winter'
    }

    response = ServerRequest().get_courses(**params)

    assert response == []

def test_get_course_by_parameters_empty_params():
    """
    Test getting a course with empty parameters. This should
    return every single course
    """

    response = ServerRequest().get_courses()

    assert len(response) > 0

def test_get_student_from_student_tok(studentReq):
    """
    Get student infomation when logged in as a student
    """

    res = studentReq.get_student()

    assert res.get("fname") == "John"
    assert res.get("lname") == "Doe"

def test_get_student_from_studentID(john_doe_pk, adminReq):
    """
    As an admin, get info for a student by
    their ID.
    """

    res = adminReq.get_student(john_doe_pk)

    assert res.get("fname") == "John"
    assert res.get("lname") == "Doe"

def test_generate_report_valid_json(john_doe_pk, adminReq):
    """
    Test generate_report with JSON file type for a specific student.
    """

    data = adminReq.generate_report(file_type="JSON", student_pk=john_doe_pk)

    assert "fname" in data, "First name should be in response"
    assert "lname" in data, "Last name should be in response"
    assert "transcript" in data, "Transcript data should be in response"

def test_generate_report_valid_XML(john_doe_pk, adminReq):
    """
    Test generate_report with JSON file type for a specific student.
    """

    data = adminReq.generate_report(file_type="XML", student_pk=john_doe_pk)

    assert "fname" in data, "First name should be in response"
    assert "lname" in data, "Last name should be in response"
    assert "transcript" in data, "Transcript data should be in response"

def test_generate_report_valid_txt(john_doe_pk, adminReq):
    """
    Test generate_report with JSON file type for a specific student.
    """

    data = adminReq.generate_report(file_type="TXT", student_pk=john_doe_pk)


    assert "Student Info" in data, "Student infomation should be in Txt"
    assert "fname" in data, "First name should be in response"
    assert "lname" in data, "Last name should be in response"
    assert "Transcript" in data, "Transcript data should be in response"
