"""
This file tests the student dashboard. Must have Server docker running!
"""

import pytest
from unittest.mock import MagicMock, patch
from tkinter import Tk
from Classes.Frames.Dashboard.student_dashboard import StudentDashboard, StudentDashboardFactory
from Classes.Util.server_req import ServerRequest
from app import App

@pytest.fixture
def app():
    root = App()
    yield root
    root.destroy()

@pytest.fixture
def student_dashboard(app):

    # Use our favorite student John Doe to get a vaild login
    # state so we can get courses from the server
    server_req = ServerRequest()
    server_req.login(username="johndoe", password="!hashmeplease!")

    return app.display_frame.show_frame(StudentDashboardFactory(), ())

def test_create_widgets(student_dashboard):
    """
    We had a valid login, so we should see courses
    in our list.
    """

    assert len(student_dashboard.olist) != 0

def test_populate_filters(student_dashboard):
    """
    Test that the filters are populated correctly.
    """
    student_dashboard.populate_filters()

    assert student_dashboard.searchframe is not None
    assert student_dashboard.searchfilter is not None
    assert student_dashboard.searchbox is not None
    assert student_dashboard.lvlframe is not None
    assert student_dashboard.lvlfilters is not None
    assert student_dashboard.lvl1 is not None
    assert student_dashboard.lvl2 is not None
    assert student_dashboard.lvl3 is not None
    assert student_dashboard.lvl4 is not None
    assert student_dashboard.lvl5 is not None
    assert student_dashboard.applyframe is not None
    assert student_dashboard.applybutton is not None

def test_filter_courses(student_dashboard):
    """
    Test the filter functionality.
    """
    student_dashboard.populate_filters()
    student_dashboard.olist = [
        MagicMock(subject="CS", coursenum="101", coursename="Intro to CS"),
        MagicMock(subject="CS", coursenum="201", coursename="Data Structures"),
        MagicMock(subject="CS", coursenum="301", coursename="Algorithms"),
        MagicMock(subject="CS", coursenum="401", coursename="Operating Systems"),
        MagicMock(subject="CS", coursenum="501", coursename="Machine Learning"),
    ]

    # Clear searchbox and put "Data" into it
    student_dashboard.searchbox.delete(0, 'end')
    student_dashboard.searchbox.insert(0, "Data")

    student_dashboard.filter()
    assert len(student_dashboard.clist) == 1
    assert student_dashboard.clist[0].coursename == "Data Structures"

    # Test course level filter
    student_dashboard.searchbox.delete(0, 'end')
    student_dashboard.onelvl.set(1)
    student_dashboard.twolvl.set(0)
    student_dashboard.threelvl.set(0)
    student_dashboard.fourlvl.set(0)
    student_dashboard.fivelvl.set(0)
    student_dashboard.filter()
    assert len(student_dashboard.clist) == 1
    assert student_dashboard.clist[0].coursenum == "101"

    # Test multiple filters
    student_dashboard.onelvl.set(1)
    student_dashboard.twolvl.set(1)
    student_dashboard.threelvl.set(1)
    student_dashboard.fourlvl.set(1)
    student_dashboard.fivelvl.set(1)
    student_dashboard.searchbox.insert(0, "CS")
    student_dashboard.filter()
    assert len(student_dashboard.clist) == 5

def test_apply_filters_button(student_dashboard):
    """
    Test that the apply button triggers the filter function.
    """

    student_dashboard.populate_filters()
    student_dashboard.filter = MagicMock()
    student_dashboard.applybutton.invoke()
    student_dashboard.filter.assert_called_once()
