import pytest
from unittest.mock import MagicMock, patch
from tkinter import Tk
from Classes.Frames.Dashboard.admin_dashboard import AdminDashboard, AdminDashboardFactory
from Classes.Util.server_req import ServerRequest
from app import App

@pytest.fixture
def app():
    root = App()
    yield root
    root.destroy()

@pytest.fixture
def admin_dashboard(app) -> AdminDashboard:

    # Use our favorite admin Sue Belcher to get a vaild login
    # state so we can get courses from the server
    server_req = ServerRequest()
    server_req.login(username="suebelcher", password="admin")

    return app.display_frame.show_frame(AdminDashboardFactory(), ())

def test_create_widgets(admin_dashboard):
    """
    Test that students were correctly loaded into
    the dashboard
    """

    assert(len(admin_dashboard.olist)) != 0

def test_filter(admin_dashboard):
    """
    Test that you can search students by their name
    """
    admin_dashboard.olist = [
        MagicMock(fullname="Joesph Joestar"),
        MagicMock(fullname="Adam Joestar"),
        MagicMock(fullname="Mickey Mouse"),
        MagicMock(fullname="Ben Steven"),
        MagicMock(fullname="Steve Rizz")
    ]

    admin_dashboard.populate_filters()

    # Clear searchbox and put "Data" into it
    admin_dashboard.searchbox.delete(0, 'end')
    admin_dashboard.searchbox.insert(0, "Joestar")

    admin_dashboard.filter()

    assert len(admin_dashboard.clist) == 2




