"""
Defines the Singleton Layout for classes
"""

class SingletonMeta(type):
    '''
    We use the metaclass approach for ensuring that
    there is *actually* only one instance of
    DatabaseConnector in our app.
    '''

    _instances = {}

    def __call__(cls, *args, **kwargs):
        """
        Possible changes to the value of the `__init__` argument do not affect
        the returned instance.
        """
        if cls not in cls._instances:
            instance = super().__call__(*args, **kwargs)
            cls._instances[cls] = instance
        return cls._instances[cls]
