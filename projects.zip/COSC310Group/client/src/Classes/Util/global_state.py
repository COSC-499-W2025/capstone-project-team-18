"""
This file defines the GlobalState class.
"""

from Classes.Util.singleton_meta import SingletonMeta

class GlobalState(metaclass = SingletonMeta):
    """
    This class will be a Singelton that will hold global
    variables. User infomation, current year, special colors,
    etc
    """

    CURRENT_YEAR = 2022
    CURRENT_SESSION = "Winter"

    user_is_admin : bool = None

    def login(self, is_admin):
        self.user_is_admin = is_admin

    def logout(self):
        self.user_is_admin = None

    def is_user_admin(self):
        if self.user_is_admin is None:
            raise ValueError("User is not logged in or I dont know")

        return self.user_is_admin

    def is_user_logged_in(self):
        return self.user_is_admin is not None

