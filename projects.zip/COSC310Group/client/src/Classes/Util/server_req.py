"""
Defines ServerRequest Class
"""

import os
import requests
from typing import Literal
from Classes.Util.singleton_meta import SingletonMeta
from Classes.Util.global_state import GlobalState


class ServerRequest(metaclass = SingletonMeta):
    """
    This class will handle all calls to the server. The ServerRequest class itself
    only holds the token variable for the current logged in user and the role.
    """

    # variable for timeout time
    time_limit: int = 5

    # a token will be returned by the server on a successful request and uses it
    # to making requests (e.g. get profile)
    token: str = None

    def __init__(self):

        # Check to see if there is a env var that holds the host
        # this is only present if the script is running on docker.
        self.url = os.environ.get("SERVER_ENDPOINT")

        if self.url is None:
            self.url = "http://localhost:8000"

    def log_out(self):
        """
        Not an endpoint. Performs 'cleanup' by reseting token
        as user as logged out
        """

        self.token = None

    def ping(self) -> str:
        """
        Calls the /ping endpoint. This is a simple function to make sure the
        link between the two systems are working
        """

        res = requests.get(self.url + "/ping", timeout=self.time_limit)

        return res.text

    def get_courses(self,
                    department: str = None,  # Example: "COSC", "MATH"
                    course_code: str = None,  # Example: "101", "2*", "303"
                    has_capacity: bool = None,  # Example: True
                    instructor: int = None,  # Example: 27 (Instructor PK)
                    year: int = None,  # Example: 2022, 2023s
                    session: str = None  # Example: "Winter", "Summer"
                    ) -> list:
        """
            Calls the /course/search endpoint with the given parameters to get courses.
        """
        params = {
            "department": department,
            "course_code": course_code,
            "has_capacity": has_capacity,
            "instructor": instructor,
            "year": year,
            "session": session
        }

        # Remove empty parameters
        params = {k: v for k, v in params.items() if v}

        res = requests.post(self.url + "/course/search", json=params, timeout=self.time_limit)

        return res.json()

    def get_student_by_params(
            self,
            gpa_min : str = None,
            gpa_max : str = None,
            course_pk : str = None,
            name : str = None
    ):
        """
        Calls the /admin/getStudentByParameters endpoint

        Admins can filter students by 0 or more of the following:
        - A minimum GPA value
        - A maximum GPA value
        - Students enrolled in a specific course
        - By (first AND last) name
        """

        params = {
            "gpa_min" : gpa_min,
            "gpa_max" : gpa_max,
            "name" : name,
            "course_pk" : course_pk
        }

        params = {k: v for k, v in params.items() if v}

        params = self.__append_token_to_body(params)

        res = requests.post(self.url + "/admin/getStudentByParameters", json=params, timeout=self.time_limit)

        json = res.json()

        if res.status_code != 200:
            raise ValueError(json['err'])

        return json

    def get_student(self, student_pk : int = None):
        """
        This endpoint gets infomation about a student. There are two cases:

            Case 1: Current login is a student. In this case, we only pass
            the token into body and the infomation returned will be about
            the student themseleves.

            Case 2: Current login is an admin. In this case, the json will be
            about the student from student_pk
        """

        endpoint = "/student/info"

        if student_pk is not None:
            endpoint += f"?student_id={student_pk}"

        body = self.__append_token_to_body()

        res = requests.get(self.url + endpoint, json = body, timeout=self.time_limit)

        return res.json()

    def generate_report(self, file_type : str, student_pk : int = None):
        endpoint = "/transcript/generateReport"

        if file_type not in ["XML", "JSON", "TXT"]:
            raise ValueError("Unsupported File Type")

        if student_pk is not None:
            endpoint += f"?student_id={student_pk}"

        body = {
            "file_type" : file_type
        }

        body = self.__append_token_to_body(body)

        res = requests.get(self.url + endpoint, json = body, timeout=self.time_limit)

        if res.status_code != 200:
            raise ValueError(res.text)

        return res.text

    def get_all_students(self):

        res = requests.get(self.url + "/student/all", timeout=self.time_limit)

        return res.json()

    def update_student(self, data, student_pk = None):
        """
        Update the student specifieced in student_id to have all data
        that is present in the data arg.

        """

        data = self.__append_token_to_body(data)

        endpoint = ""
        if student_pk is not None:
            endpoint += f"?student_id={student_pk}"

        res = requests.post(self.url + f"/student/update" + endpoint, json=data, timeout=self.time_limit)

        return res.json()

    def login(self, username, password):
        """
        Calls the login endpoint. The login_creds must be formated as follows.

        Responses
        ---------
        400 Bad Request:
            The user did not enter a username or a password
            RETURNS:
                {'bad request': 'missing username'} OR {'bad request': 'missing pswd'}
                 - Note: if both the username AND password are missing, a 'missing username' is thrown

        401 Unauthorized:
            The user did not enter valid credentials. They either mistyped or need to make an account
            RETURNS: {
                "status": "error",
                "message": "Invalid credentials"
                }
        200 OK:
            The user entered valid login credentials.
            RETURNS: {
                'status': 'login-success',
                'message': 'Login successful',
                'user_role': result_role,
                'token': jwt
            }

        """

        login_creds = {
            'username' : username,
            'pswd' : password
        }

        req_method = 'POST'
        endpoint = '/auth/login'

        res = self.__make_request(req_method, login_creds, endpoint)

        if res.status_code == 200:
            self.token = res.json().get('token')  # Get token from cookies

            GlobalState().login(res.json().get("user_role") == "admin")

        return res

    def grade_course(self, course_id, student_id, grade):
        """
        Student of given id will get a course of the given
        grade for the given course
        """

        body = {
            "student_id" : student_id,
            "course_id": course_id,
            "course_grade": grade
        }

        body = self.__append_token_to_body(body)

        res = requests.put(self.url + "/admin/gradeCourse", json=body, timeout=self.time_limit)

        return res


    def enroll_student(self, course_id: int, student_id: int = None):
        """
        This endpoint allows a student to enroll in a course. If the course has available capacity, the student is enrolled directly.
        If the course is full, the student is placed on the waitlist.

        Request JSON format:
        {
            "student_id": "<student_id>",
            "course_id": "<course_id>"
        }

        Responses
        ---------
        200 OK:
            Successful enrollment or waitlist placement.
            RETURNS: {
                "placement": "enrolled" | "waitlisted"
            }
        400 Bad Request:
            Missing student_id or course_id.
            RETURNS: {
                "error": "Missing student_id or course_id"
            }
        400 Bad Request:
            Student already is enrolled or on waitlist.
            RETURNS: {
                "err": "Student already is enrolled or on waitlist"
            }
        400 Bad Request:
            Unknown error occurred.
            RETURNS: {
                "err": "Unknown error occurred"
            }
        """

        body = self.__append_token_to_body({"course_id": course_id})
        if student_id:
            body['student_id'] = student_id

        res = requests.post(self.url + "/student/enroll", json=body, timeout=self.time_limit)

        if res.status_code != 200:
            raise ValueError(f"Response is status {res.status_code} message {res.json().get('err')}")

        return res.json()

    def drop_student(self, course_id: int, student_id: int = None):
        """
        This endpoint allows a student to drop a course. If the student is enrolled in the course, they are removed from the enrollment.
        If the student is on the waitlist for the course, they are removed from the waitlist. If the course has a waitlist, the next student
        on the waitlist is moved to the enrollment.

        Request JSON format:
        {
            "student_id": "<student_id>",
            "course_id": "<course_id>"
        }

        Responses
        ---------
        200 OK:
            Successful drop from enrollment or waitlist.
            RETURNS: {
                "msg": "Student deleted off enrollment" | "Student deleted off waitlist"
            }
        400 Bad Request:
            Missing student_id or course_id.
            RETURNS: {
                "error": "Missing student_id or course_id"
            }
        400 Bad Request:
            Student is not enrolled or on waitlist.
            RETURNS: {
                "err": "Student is not enrolled or on waitlist for course"
            }
        400 Bad Request:
            Unknown error occurred.
            RETURNS: {
                "err": "Unknown error occurred"
            }
        """
        body = self.__append_token_to_body({"course_id": course_id})
        if student_id:
            body['student_id'] = student_id

        res = requests.post(self.url + "/student/drop", json=body, timeout=self.time_limit)

        if res.status_code != 200:
            raise ValueError(f"Response is status {res.status_code}")

        return res.json()

    def upload_transcript(self, student_id, transcript):


        body = {
            "student_id" : student_id,
            "transcript_data" : transcript
        }

        body = self.__append_token_to_body(body)

        res = requests.post(self.url + "/transcript/uploadTranscript", json=body, timeout=self.time_limit)

        if res.status_code != 200:
            raise ValueError(res.json().get("err"))

        return

    def __make_request(self, req_method: str, req_body: dict, endpoint_name: str) -> dict:
        '''
        Makes a request to the server on behalf of the client.
        Expected Input:
         req_method: a string for the type of http request to be made
         req_body: the body of the request (e.g. for login, "username":"use, pswd:password, etc.)
         endpoint_name: API endpoint to make request to (e.g. /login)
        Expected Output:
         return success: return a dict indicating successful, including any additional data
         return fail: return a dict indicating failure.
         Note: the output should have a return code (e.g. 200 or 400)
        TODO: implement default param so that body doesn't require contents
        '''
        req_url = self.url + endpoint_name
        req = requests
        if req_method == 'GET':
            print('TODO: Implement GET request')
        elif req_method == 'POST':
            #The requests library has built-in authentication, so we check if the request to be made
            #is to log in.
            if (len(req_body) == 2 and 'username' in req_body and 'pswd' in req_body):
                try:
                    req = requests.post(req_url, json=req_body, timeout=self.time_limit)  # make request
                except requests.exceptions.Timeout:
                    print('408: Request Timeout \nLogin unsuccessful. ')
        elif req_method == 'PUT':
            print('TODO: Implement PUT request')
        elif req_method == 'DELETE':
            print('TODO: Implement DELETE request')
        elif req_method == 'HEAD':
            print('TODO: Implement HEAD request')
        elif req_method == 'OPTIONS':
            print('TODO: Implement OPTIONS request')
        else:
            req = {'Error': 'Invalid request. Try again.'}

        return req

    def __append_token_to_body(self, body : dict = {}):
        return {**body, 'token' : self.token}
