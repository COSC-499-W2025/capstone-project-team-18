"""
This files defines all the frame factory. We use the Factory method
design pattern to implement switching screens
"""

import tkinter as tk
from typing import TYPE_CHECKING
from typing import Callable

if TYPE_CHECKING:
    from app import App


class FrameFactory:
    def build_args() -> tuple:
        return ()

    def create_frame(app : tk.Frame, show_frame: Callable, edit_app_aspects: Callable, args: tuple) -> tk.Frame:
        raise ImportError("You need to override me!")
