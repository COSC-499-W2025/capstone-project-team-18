"""
This file defines the StudentDashboard class
"""

from typing import TYPE_CHECKING, Callable
import tkinter as tk

from Classes import constants
from Classes.Frames.Dashboard.general_dashboard import GeneralDashboard
from Classes.Util.frame_factory import FrameFactory
from Classes.Frames.Dashboard.course_student_box import coursebox

from Classes.Util.server_req import ServerRequest
from Classes.Util.global_state import GlobalState

if TYPE_CHECKING:
    from app import App

class StudentDashboardFactory(FrameFactory):

    @staticmethod
    def build_args():
        return tuple

    def create_frame(self, app : tk.Frame, show_frame: Callable, edit_app_aspects: Callable, args) -> tk.Frame:

        dwin = StudentDashboard(app, show_frame)

        edit_app_aspects(
            title = "Student Dashboard",
            geometry = constants.dashboard_size,
            resizable = True
        )

        return dwin

class StudentDashboard(GeneralDashboard):

    show_frame : Callable

    def __init__(self, window, show_frame):
        super().__init__(window, "Courses")

        self.show_frame = show_frame

        self.retrieve_courses_from_database(window)


    def retrieve_courses_from_database(self, window):
        """
        Retrieves course info from database and puts them into a list of CourseBox objects
        """
        server_req = ServerRequest()

        all_courses_from_server = server_req.get_courses(year=GlobalState.CURRENT_YEAR, session=GlobalState.CURRENT_SESSION)
        student_info = server_req.get_student()

        if student_info.get("err") is not None:
            return self

        enrolled_cid = [c.get('cid') for c in student_info.get("enrollments")]
        invaild_cid = [c.get('cid') for c in student_info.get("previous_enrollments")]
        waitlist_cid = [c.get('cid') for c in student_info.get("waitlist")]
        waitlist_pos = [c.get('waitlist_position') for c in student_info.get("waitlist")]


        coursebox_list = []

        # For every course in the database we want to make a coursebox object
        # we do some logic to make sure every coursebox has all the infomation
        # that it needs
        for course in all_courses_from_server:

            course_pk = course.get("cid")

            # If a student already has a grade for a course, dont let them even
            # see that course on their dashboard.
            if course_pk in invaild_cid:
                all_courses_from_server.remove(course)
                continue

            student_is_enrolled = course_pk in enrolled_cid
            student_is_on_waitlist = course_pk in waitlist_cid

            waitlist_position = None
            if student_is_on_waitlist:
                waitlist_position = waitlist_pos[waitlist_cid.index(course_pk)]

            coursebox_list.append(coursebox(
                subject= course["department"],
                coursenum= course["course_code"],
                coursename= course["title"],
                coursedesc= "",
                studentcount= course["ccount"],
                maxstudents= course["capacity"],
                coursestatus= "Open" if course["ccount"] < course["capacity"] else "Full",
                student_is_enrolled= student_is_enrolled,
                student_is_waitlisted= student_is_on_waitlist,
                waitlist_pos= waitlist_position,
                course_pk= course["cid"],
                parent= self.course_list,
                controller=window,
                refresh_frame = lambda: self.refresh_frame()
            ))

        self.setlist(coursebox_list)

    def refresh_frame(self):
        """
        Refreshes the entire frame by clearing and reinitializing
        the course list and filters using the factory.
        """

        args = StudentDashboardFactory.build_args()
        self.show_frame(StudentDashboardFactory(), args)

    def populate_filters(self):
        """
        The filters section is defined in the superclass
        GeneralDashboard. Here, we define what it will look
        like. For student course we have a keyword search
        course level checkbox
        """
        # keyword search
        self.searchframe = tk.Frame(self.filtersection,background='white')
        self.searchfilter= tk.LabelFrame(self.searchframe, text="Search",font=('Verdana', constants.default_font_size,'bold'),background='white')
        self.searchbox = tk.Entry(self.searchfilter,width=15,fg='gray',font=('Verdana', constants.default_font_size),highlightbackground=constants.navigation_button_bg_color,highlightthickness=2)
        # course level
        self.lvlframe = tk.LabelFrame(self.filtersection, text="Course level",font=('Verdana', constants.default_font_size,'bold'),background='white')
        self.lvlfilters = tk.Frame(self.lvlframe,background='white',bd=3,highlightbackground=constants.navigation_button_bg_color,highlightthickness=2)
        self.onelvl = tk.IntVar()
        self.twolvl = tk.IntVar()
        self.threelvl = tk.IntVar()
        self.fourlvl = tk.IntVar()
        self.fivelvl = tk.IntVar()
        self.lvl1 = tk.Checkbutton(self.lvlfilters, text="100 level",background='white',variable=self.onelvl,offvalue=0,onvalue=1)
        self.lvl2 = tk.Checkbutton(self.lvlfilters, text="200 level",background='white',variable=self.twolvl,offvalue=0,onvalue=1)
        self.lvl3 = tk.Checkbutton(self.lvlfilters, text="300 level",background='white',variable=self.threelvl,offvalue=0,onvalue=1)
        self.lvl4 = tk.Checkbutton(self.lvlfilters, text="400 level",background='white',variable=self.fourlvl,offvalue=0,onvalue=1)
        self.lvl5 = tk.Checkbutton(self.lvlfilters, text="500 level",background='white',variable=self.fivelvl,offvalue=0,onvalue=1)
        # apply button
        self.applyframe = tk.Frame(self.filtersection,background='white',bd=3)
        self.applybutton = tk.Button(self.applyframe, text="Apply",fg='white',bg=constants.navigation_button_bg_color,font=('Verdana', constants.default_font_size, 'bold'), command=lambda:self.applyfilters(),relief=tk.RAISED,anchor="center",padx=10)
        # place filters
        self.lvlframe.columnconfigure(0,weight=1)
        self.searchframe.grid(column=0)
        self.searchfilter.grid(column=0)
        self.searchbox.grid(column=0)
        self.searchbox.insert(0,'Keywords')
        self.searchbox.bind("<Button-1>",lambda x:self.click_search())
        self.lvlframe.grid(column=0, sticky="new")
        self.lvlfilters.grid(column=0, sticky="new")
        self.lvl1.grid(column=0)
        self.lvl2.grid(column=0)
        self.lvl3.grid(column=0)
        self.lvl4.grid(column=0)
        self.lvl5.grid(column=0)
        self.applyframe.grid(column=0, sticky="new")
        self.applyframe.columnconfigure(0,weight=1)
        self.applybutton.grid(pady=constants.small_pady)

    def click_search(self):
        if self.searchbox.get() == "Keywords":
            self.searchbox.delete(0,'end')
        self.searchbox.config(fg='black')

    def filter(self):
        """
        This function will sort through all the courseboxs
        that fullfill the given filters. Note that this
        courseboxes are not destoryed but rather we only
        select ones that we show
        """

        l1 = self.onelvl.get() == 1
        l2 = self.twolvl.get() == 1
        l3 = self.threelvl.get() == 1
        l4 = self.fourlvl.get() == 1
        l5 = self.fivelvl.get() == 1

        if not (l1 or l2 or l3 or l4 or l5):
            l1 = l2 = l3 = l4 = l5 = True

        entrytext = self.searchbox.get().lower()
        if entrytext == "keywords":
            entrytext=''

        self.clist = []
        for thing in self.olist:
            if str(thing.subject + ' ' + thing.coursenum + ' ' + thing.coursename).lower().find(entrytext) != -1 or entrytext == '':
                if l1 and thing.coursenum[0] == "1":
                    self.clist.append(thing)
                elif l2 and thing.coursenum[0] == "2":
                    self.clist.append(thing)
                elif l3 and thing.coursenum[0] == "3":
                    self.clist.append(thing)
                elif l4 and thing.coursenum[0] == "4":
                    self.clist.append(thing)
                elif l5 and thing.coursenum[0] == "5":
                    self.clist.append(thing)


        self.place_courses()
