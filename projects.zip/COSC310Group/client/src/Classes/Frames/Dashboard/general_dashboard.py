"""
Admin Dashboard and Student Dashboard use the same basic layout
here, we define a Dashboard layout that needs a filter box and implements a
list
"""

import tkinter as tk
from Classes import constants
import os
from tkinter import PhotoImage
from typing import TYPE_CHECKING

from Classes.Util.frame_factory import FrameFactory
from Classes.Frames.Dashboard.course_student_box import ListClass

# This trick here avoids a circular import issue in Python
# App only needs to be imported to help our dev experience, but
# will lead to an error if we import it outright.
if TYPE_CHECKING:
    from app import App

class GeneralDashboard:
    """
    Here is the General Dashboard class. This class will setup everything for the dashboard
    """

    admin: bool  # Admin dashboard?
    listOfBoxes: ListClass  # The class to list

    def __init__(self, window: 'App', title_of_list_section : str):
        # INITIALIZE VARIABLES
        #-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        self.maxpage=0
        self.currentpage=0
        self.currentitem=0
        self.clist=[] # current list
        self.olist=[] # stored list

        #window.geometry("1000x600")
        #window.resizable(True, True)
        #window.minsize(765,550)
        #window.config(background='#230a3c')

        # CONFIGURE COLUMN WEIGHTS
        #-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        window.columnconfigure(1,weight=1)
        self.spacer = tk.Frame(window, background='red',width=20)
        self.spacer.grid(row=0,column=2,padx=(10,50))
        #-------------------------------------------------------------------------------------------------------------------------------------------------------------------

        # FILTERS
        #-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        self.filtersection = tk.LabelFrame(window, text="Filters",font=('Verdana', constants.title_font_size,'bold'),background='white')
        self.filtersection.grid(row=1,column=0,sticky='ne',padx=(10,10))
        self.filtersection.columnconfigure(0,weight=1)
        #-------------------------------------------------------------------------------------------------------------------------------------------------------------------

        # COURSE LIST SECTION
        #-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if title_of_list_section == 'Students':
            self.course_list = tk.LabelFrame(window, text="Students",font=('Verdana', constants.title_font_size,'bold'),background='white')    
        else: 
            self.course_list = tk.LabelFrame(window, text="Courses",font=('Verdana', constants.title_font_size,'bold'),background='white')
        self.course_list.grid(row=1,column=1,sticky='ew',padx=(10,50))
        self.course_list.columnconfigure(0,weight=1)
        # -------------------------------------------------------------------------------------------------------------------------------------------------------------------

        # PAGE NAVIGATION
        # -------------------------------------------------------------------------------------------------------------------------------------------------------------------
        self.nav=tk.Frame(window,background=constants.navigation_button_bg_color)
        self.pdisplay=tk.Label(self.nav,text= "0 of 0",fg='white',font=('Verdana', constants.default_font_size,'bold'),background=constants.navigation_button_bg_color)
        self.lbutton=tk.Button(self.nav, text="<",font=('Verdana', constants.default_font_size,'bold'), command=lambda:self.pagedown(),relief=tk.SUNKEN,background='lightgray')
        self.rbutton=tk.Button(self.nav, text=">",font=('Verdana', constants.default_font_size,'bold'), command=lambda:self.pageup(),relief=tk.SUNKEN,background='lightgray')


        self.nav.grid(row=2,column=0,ipady=3, pady=(10,50),sticky='ewn',columnspan=3)
        self.nav.columnconfigure(0,weight=1)
        self.nav.columnconfigure(1,weight=1)
        self.nav.columnconfigure(2,weight=1)

        self.pdisplay.grid(row=0,column=1,sticky='ewn')
        self.lbutton.grid(row=0,column=0,sticky='e',padx=constants.large_padx,ipadx=30)
        self.rbutton.grid(row=0,column=2,sticky='w',padx=constants.large_padx,ipadx=30)
        #-------------------------------------------------------------------------------------------------------------------------------------------------------------------

        self.populate_filters()

    def populate_filters(self):
        # This method should be overridden by subclasses to add specific filters
        pass

    def applyfilters(self):

        for c in self.clist:
            c.erase()

        self.currentpage = 0
        self.currentitem = 0

        self.filter()

        pass

    def filter(self):
        # This method should be overridden by subclasses to apply specific filters
        pass

    def pageup(self):
        if self.currentpage != self.maxpage:
            for c in self.clist:
                c.erase()
            self.currentpage += 1
            self.place_courses()

    def pagedown(self):
        if self.currentpage > 0:
            for c in self.clist:
                c.erase()
            self.currentpage -= 1
            self.currentitem -= 10
            self.place_courses()

    def place_courses(self):
        """
        Put courses on the page based on the
        current page
        """
        self.maxpage = int(len(self.clist) / 5) - 1
        lastpageamt = int(len(self.clist) % 5)
        todisplay = int(len(self.clist) % 5)
        if todisplay == 0:
            todisplay = 5
            lastpageamt = 5
        else:
            self.maxpage += 1

        self.pdisplay.configure(text=(str(self.currentpage + 1) + ' of ' + str(self.maxpage + 1)))

        if self.currentpage == self.maxpage:
            for idx in range(todisplay):
                if self.currentitem < (self.currentpage * 5 + lastpageamt):
                    self.clist[self.currentpage * 5 + idx].create()
                    self.currentitem += 1
        else:
            for idx in range(5):
                if self.currentitem < (self.currentpage * 5 + 5):
                    self.clist[self.currentpage * 5 + idx].create()
                    self.currentitem += 1

        if self.currentpage != self.maxpage:
            self.rbutton.configure(relief=tk.RAISED, background='white')
        else:
            self.rbutton.configure(relief=tk.SUNKEN, background='lightgray')
        if self.currentpage > 0:
            self.lbutton.configure(relief=tk.RAISED, background='white')
        else:
            self.lbutton.configure(relief=tk.SUNKEN, background='lightgray')

    def setlist(self, crs: list):
        self.clist = crs
        self.olist = crs
        self.place_courses()
