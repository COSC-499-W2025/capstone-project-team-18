import tkinter as tk
from tkinter import messagebox

from typing import TYPE_CHECKING, Callable

from Classes import constants
from Classes.Util.server_req import ServerRequest

from Classes.Frames.StudentManagment.student_manager import StudentManagerFactory

if TYPE_CHECKING:
    from app import App

# Abstract class
class ListClass:
    """
    This class will defined a list object. In the student dashboard, we need to filter
    and search by courses. In the admin dashboard, we need to filter by students. Instead
    of making two classes of course and student, we instead use this abstract file.

    This class defines the main layout of a list item to be used in Dashboard. It is extended
    by courseBox and StudentBox. It is up to each box the title, subtitle, description, button
    text and the button callback function

    """

    descopen : bool = False
    bg : str = 'white'
    font : str = ('Verdana', constants.default_font_size,'bold')

    def create(self):
        """
        Make the object visible
        """
        self.body.grid(sticky='ew')
        self.title.grid(row=0,column=0,sticky='w')
        self.info.grid(row=1,column=0,sticky='w')
        self.rbutton.grid(row=0,column=2,rowspan=3,sticky='e',padx=(50,0))

        if(self.descdrop != None):
            self.descdrop.grid(row=2,column=0,sticky='w')

    def erase(self):
        self.body.grid_forget()

    def __init__(self,
                 parent,
                 title : str,
                 subtitle : str,
                 button_text : str,
                 description : str,
                 on_button_click # Call back function
            ):

        # Create container
        self.body=tk.Frame(parent,
                           height=constants.csb_height,
                           width=constants.csb_width,
                           padx=constants.default_padx,
                           pady=constants.default_pady,
                           bg='white',
                           bd=3,
                           relief=tk.RAISED)

        self.body.columnconfigure(0,minsize=constants.csb_width,weight=1)

        # Define title section
        self.title = tk.Label(
            self.body,
            text = title,
            bg = 'white',
            font=('Verdana', constants.default_font_size,'bold')
        )

        # Define subtitle section
        self.info=tk.Label(
            self.body,
            text = subtitle,
            bg = self.bg,
            font = self.font
        )

        # Define button
        self.rbutton= tk.Button(
            self.body,
            text = button_text,
            command = on_button_click,
            bg = constants.foreground_color,
            font = self.font
        )

        if(description != ""):
            # Define Description Button
            self.descdrop = tk.Button(
                self.body,
                text="Description: ▼",
                command=lambda:self.toggledesc(),
                relief=tk.FLAT,
                bd=0,
                bg = self.bg,
                font = self.font,
                cursor='hand2'
                )

            # Define actual description
            self.desc = tk.Label(
                self.body,
                text = description,
                bg = self.bg,
                font = self.font
            )
        else:
            self.descdrop = None
    def toggledesc(self):
        """
        When clicking the dropdown button on the description, this function
        toggles the direction of the arrow and the visibility of the description text
        """

        if(self.desc is None):
            return

        if self.descopen:
            self.descdrop.config(text="Description: ▼")
            self.desc.grid_forget()
            self.descopen=False
        else:
            self.descdrop.config(text="Description: ▲")
            self.desc.grid(row=3,column=0,columnspan=3,sticky='w')
            self.descopen=True


class coursebox(ListClass):
    """
    This is the coursebox class. It has the job of setting up
    the button callback function and all of the titles and subtitles
    of superclass ListClass.
    """

    def __init__(self,
                 subject :str,
                 coursenum :str,
                 coursename :str,
                 coursedesc : str,
                 studentcount : int,
                 maxstudents : int,
                 coursestatus : str,
                 student_is_enrolled: bool,
                 student_is_waitlisted: bool,
                 course_pk: int,
                 waitlist_pos: int,
                 parent,
                 controller : 'App',
                 refresh_frame : Callable
                ):

        self.controller = controller

        self.subject = subject
        self.coursenum = coursenum
        self.coursename = coursename
        self.refresh_frame = refresh_frame

        self.course_pk = course_pk
        self.course_identifer = f"{subject} {coursenum}"

        self.student_is_enrolled = student_is_enrolled
        self.student_is_waitlisted = student_is_waitlisted
        self.waitlist_pos = waitlist_pos
        self.course_full : bool = studentcount == maxstudents

        button_text = "Enroll"
        if student_is_enrolled:
            button_text = "Drop Course"
        elif student_is_waitlisted:
            button_text = "Leave Waitlist"
        elif self.course_full:
            button_text = "Join Waitlist"

        super().__init__(
            parent,
            (subject + " " + coursenum + " | " + coursename),
            (coursestatus + " | Enrolled/Capacity: " + str(studentcount)+ "/" + str(maxstudents)),
            button_text,
            coursedesc,
            lambda: self.on_coursebox_click()
        )

    def on_coursebox_click(self):

        course_pk = self.course_pk
        server_req = ServerRequest()

        self.register(course_pk, server_req)

        self.refresh_frame()


    def register(self, course_pk, server_req):
        '''Method for requesting registration via button in course box'''

        if not self.student_is_enrolled and not self.student_is_waitlisted:
            # Enroll student normally into a course
            json = server_req.enroll_student(course_pk)

            placement = json.get('placement')

            if placement:
                messagebox.showinfo("Success", f"You are now {placement} for course {self.course_identifer}")
                return

        elif self.student_is_enrolled:
            if messagebox.askyesno("Warning", f"You are currently enrolled in {self.course_identifer} are you sure you want to drop the course?"):

                json = server_req.drop_student(course_pk)

                msg = json.get('msg')

                if msg == "Student deleted off enrollment" or msg == 'Student deleted off enrollment and waitlist updated':
                    messagebox.showinfo("Success", f"You are no longer enrolled in {self.course_identifer}")
                    return
        elif self.student_is_waitlisted:
            if messagebox.askyesno("Warning", f"You are position {str(self.waitlist_pos)} for course {self.course_identifer}. Are you sure you want to leave the waitlist?"):
                json = server_req.drop_student(course_pk)

                msg = json.get('msg')

                if msg == "Student deleted off waitlist":
                    messagebox.showinfo("Success", f"You are no longer on the waitlist for {self.course_identifer}")
                    return

        messagebox.showwarning("Error", "Something went wrong")

class StudentBox(ListClass):

    def __init__(self,
                 parent,
                 student_id: int,
                 first_name: str,
                 last_name: str,
                 email: str,
                 username: str,
                 phone: str,
                 address: str,
                 show_frame: Callable
                ):

        self.student_id = student_id
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.username = username
        self.phone = phone
        self.address = address

        self.fullname = f"{first_name.capitalize()} {last_name.capitalize()}"
        self.show_frame = show_frame

        super().__init__(
            parent,
            self.fullname,
            f" Username: {username}",
            "Edit",
            f"Email: {email} | Phone: {phone} |Address: {address}",
            self.edit_student
        )

    def edit_student(self):
        '''Method for editing student details'''

        args = StudentManagerFactory.build_args(False, True, self.student_id)

        self.show_frame(StudentManagerFactory(), args)
