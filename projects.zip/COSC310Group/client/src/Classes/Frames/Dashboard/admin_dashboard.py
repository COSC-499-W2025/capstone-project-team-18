"""
This file defines the admin_dashboard class
"""

import tkinter as tk

from Classes import constants
from Classes.Frames.Dashboard.general_dashboard import GeneralDashboard
from Classes.Util.frame_factory import FrameFactory
from Classes.Frames.Dashboard.course_student_box import StudentBox
from Classes.Frames.AdvancedSearch.advance_student_search import AdvanceStudentSearchFactory
from typing import Callable

from Classes.Util.server_req import ServerRequest

class AdminDashboardFactory(FrameFactory):

    @staticmethod
    def build_args():
        return ()

    def create_frame(self, app: tk.Frame, show_frame: Callable, edit_app_aspects: Callable, args: tuple) -> tk.Frame:

        dwin = AdminDashboard(app, show_frame)

        edit_app_aspects(
            title = "Admin Dashboard",
            geometry = constants.admin_dashboard_size,
            resizable = True
        )

        return dwin

class AdminDashboard(GeneralDashboard):
    """
    This is the admin """

    show_frame: Callable

    def __init__(self, window: tk.Frame, show_frame: Callable):
        super().__init__(window, "Students")

        self.show_frame = show_frame

        self.retieve_students_from_database()


    def retieve_students_from_database(self):
        server_req = ServerRequest()

        all_students = server_req.get_all_students()

        students = []
        for student in all_students:
            students.append(StudentBox(
                parent = self.course_list,
                show_frame = self.show_frame,
                student_id = student["id"],
                first_name = student["fname"],
                last_name = student["lname"],
                email = student["email"],
                username = student["username"],
                phone = student["phone"],
                address = student["address"]
            ))

        self.setlist(students)

    def populate_filters(self):

        # keyword search
        self.searchframe = tk.Frame(self.filtersection, relief=tk.RAISED, background='lightgray', bd=3)
        self.searchfilter = tk.LabelFrame(self.searchframe, text="Search", font=('Verdana', 8, 'bold'), background='lightgray')
        self.searchbox = tk.Entry(self.searchfilter)
        self.searchframe.grid(column=0)
        self.searchfilter.grid(column=0)
        self.searchbox.grid(column=0)

        # apply button
        self.applyframe = tk.Frame(self.filtersection, relief=tk.RAISED, background='lightgray', bd=3)
        self.applybutton = tk.Button(self.applyframe, text="Apply", command=self.applyfilters, relief=tk.RAISED, background='white', anchor="center")
        self.applyframe.grid(column=0, sticky="new")
        self.applyframe.columnconfigure(0, weight=1)
        self.applybutton.grid(pady=5)

        tk.Button(self.applyframe, text="Advance Search", anchor="center", command=self.go_to_advance_search).grid(pady=7)

    def go_to_advance_search(self):
        args = AdvanceStudentSearchFactory.build_args()
        self.show_frame(AdvanceStudentSearchFactory(), args)

    def filter(self):

        entrytext = self.searchbox.get().lower()

        # If search is empty, simply return all students
        if entrytext == "":
            self.clist = self.olist
            self.place_courses()
            return

        self.clist = []
        for student in self.olist:
            if student.fullname.lower().find(entrytext) != -1 or entrytext == '':
                self.clist.append(student)

        self.place_courses()

