import tkinter as tk
from typing import TYPE_CHECKING

from Classes import constants
from Classes.Util.frame_factory import FrameFactory
from Classes.Frames.StudentManagment.sidebar import SideBar
from Classes.Frames.StudentManagment.SubScreens.edit_personal_details import EditPersonalDetails

from Classes.Util.server_req import ServerRequest

if TYPE_CHECKING:
    from app import App

class StudentManagerFactory:

    @staticmethod
    def build_args(
        user_own_profile : bool,
        user_is_admin : bool,
        student_id : str = None
        ):
        return (user_own_profile, user_is_admin, student_id)

    def create_frame(self, app, callback, edit_app_aspects, args):

        edit_app_aspects(
            title = "User Manager",
            geometry= constants.dashboard_size,
            resizable = True
        )

        user_own_profile, user_is_admin, student_id = args

        if not user_is_admin and not user_own_profile:
            raise ValueError("Student can not manage other student's profiles")

        StudentManager(app, user_own_profile, user_is_admin, student_id).pack(fill="both", expand=True)

class StudentManager(tk.Frame):
    """
    This class is composed of two main screens: A sidebar and
    a working screen.

    The point of this class is to cover these following options:

    1. User is a student managing themseleves. user_own_profile = True, user_is_admin = False, student_id = None
    2. User is an admin managing a Student. user_own_profile = False, user_is_admin = True, student_id = <student id>
    3. User is an admin managing themselves. user_own_profile = True, user_is_admin = True, student_id = None

    The sidebar will be built depending on which case we fall under

    """

    app : 'App'
    user_own_profile : bool
    user_is_admin : bool
    student_id : str
    title_text : str = None

    current_window_container : tk.Frame = None
    current_frame : tk.Frame = None

    # Constants
    FONT = ("Font", 30)

    def __init__(self, app: 'App', user_own_profile: bool, user_is_admin: bool, student_id: str):
        super().__init__(app)

        self.app = app
        self.user_own_profile = user_own_profile
        self.user_is_admin = user_is_admin
        self.student_id = student_id

        if user_own_profile:
            self.__configure_screen_for_profile()
        else:
            self.__configure_screen_for_admin()

        # Define Frames
        title_label = tk.Label(self, text=self.title_text, font=self.FONT)
        sidebar_container = tk.Frame(self)
        self.current_window_container = tk.Frame(self)
        separator = tk.Frame(self, width=2, bg="black")

        # Define Layout of Frames
        title_label.pack(side=tk.TOP, pady=constants.default_pady)
        sidebar_container.pack(side=tk.LEFT, padx=constants.default_padx, pady=constants.default_pady)
        separator.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        self.current_window_container.pack(side=tk.RIGHT, expand=True, padx=constants.default_padx, pady=constants.default_pady)

        # Define Content of Frames
        SideBar(
            sidebar_container= sidebar_container,
            switch_screen_callback= self.__switch_sub_screen,
            user_own_profile= user_own_profile,
            user_is_admin= user_is_admin,
            student_pk=student_id
            )

        # Init to edit personal Details
        self.__switch_sub_screen(EditPersonalDetails, args = {
                "student_pk" : student_id,
                "admin_view" : user_is_admin
            })


    def __switch_sub_screen(self, classNameOfSubScreen: type, args: dict, force_refresh = False):
        """
        Switches the current sub-screen to the specified screen.

        Args:
            classNameOfSubScreen (type): The class of the sub-screen to display.
            args (dict): Arguments to pass to the sub-screen's constructor.
        """

        if type(self.current_frame) == classNameOfSubScreen and not force_refresh:
            return


        for widget in self.current_window_container.winfo_children():
            widget.destroy()

        # Create and display the new sub-screen
        self.current_frame = classNameOfSubScreen(self.current_window_container, **args)
        self.current_frame.pack()

    def __configure_screen_for_profile(self):
        """
        All config commands for when the user
        is managing their own profile
        """
        #self.app.title("My Profile")
        self.title_text = "My Profile"

    def __configure_screen_for_admin(self):

        server_req = ServerRequest()

        student_info = server_req.get_student(self.student_id)

        self.title_text = f"Editing Student {student_info.get('fname')} {student_info.get('lname')}"





