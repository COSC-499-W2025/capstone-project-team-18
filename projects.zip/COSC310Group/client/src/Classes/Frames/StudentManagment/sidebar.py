import tkinter as tk

from Classes import constants
from Classes.Frames.StudentManagment.SubScreens.edit_current_enrollments import EditCurrentEnrollment
from Classes.Frames.StudentManagment.SubScreens.edit_personal_details import EditPersonalDetails
from Classes.Frames.StudentManagment.SubScreens.generate_transcript import GenerateTranscript
from Classes.Frames.StudentManagment.SubScreens.grade_current_enrollments import GradeCurrentEnrollment
from Classes.Frames.StudentManagment.SubScreens.upload_transcript import UploadTranscript
from Classes.Frames.StudentManagment.SubScreens.enroll_student_in_course import EnrollStudentInCourse

class SideBar(tk.Frame):
    """

    Here we define the Sidebar class. This class will be used in the
    StudentManager class.

    """

    def __init__(self,
                 sidebar_container: tk.Frame,
                 switch_screen_callback,
                 user_own_profile,
                 user_is_admin,
                 student_pk
                 ):

        super().__init__(sidebar_container)

        self.switch_screen = switch_screen_callback

        self.modify_visual_aspects()

        self.construct_side_bar(
            user_own_profile = user_own_profile,
            user_is_admin = user_is_admin,
            student_pk= student_pk
            )

        self.pack()

    def modify_visual_aspects(self):
        """
        Modifies the visual aspects of the sidebar, including adding a label and an outline.
        """
        # Add a label to the top of the sidebar
        tk.Label(self, text="Menu", font=("Arial", 14, "bold")).pack(pady=constants.default_pady)

        # Add an outline to the sidebar frame
        self.config(relief="solid", bd=2)


    def construct_side_bar(self, user_own_profile: bool, user_is_admin: bool, student_pk):
        """
        Constructs the sidebar options based on the user's role and profile context.

        Args:
            user_own_profile (bool): Indicates if the user is managing their own profile.
            user_is_admin (bool): Indicates if the user has admin privileges.
        """

        # Always include the option to edit personal details
        self.create_option_edit_personal_details(student_pk=student_pk, is_admin=user_is_admin)

        if user_own_profile and not user_is_admin:
            # Case 1: User is a student managing their own profile
            self.create_option_edit_current_enrollments(student_pk = None, is_admin = False)
            self.create_option_generate_transcript(student_pk = None)

        elif not user_own_profile and user_is_admin:
            # Case 2: User is an admin managing a student's profile
            self.create_option_edit_current_enrollments(student_pk = student_pk, is_admin = True)
            self.create_option_generate_transcript(student_pk = student_pk)
            self.create_option_grade_current_enrollments(student_pk= student_pk)
            self.create_option_upload_transcript(student_pk = student_pk)
            self.enroll_student_in_courses(student_pk= student_pk)

        elif user_own_profile and user_is_admin:
            # Case 3: User is an admin managing their own profile
            pass  # No specific options for this case

        else:
            # Invalid case: Students cannot manage other students
            raise ValueError("Students cannot manage others")

    def create_option_edit_personal_details(self, student_pk, is_admin):
        """
        Adds a button to the sidebar to switch to the 'Edit Personal Details' sub-screen.
        """
        self.add_to_sidebar(
            text="Edit Personal Details",
            callback=lambda: self.switch_screen(EditPersonalDetails, {
                "student_pk" : student_pk,
                "admin_view" : is_admin
            })
        )

    def create_option_edit_current_enrollments(self, student_pk, is_admin):
        """
        Adds a button to the sidebar to switch to the 'Edit Current Enrollments' sub-screen.
        """
        self.add_to_sidebar(
            text="Edit Current Enrollments",
            callback=lambda: self.switch_screen(EditCurrentEnrollment, {
                "student_pk" : student_pk,
                "admin_view" : is_admin
            })
        )

    def create_option_grade_current_enrollments(self, student_pk):
        """
        Adds a button to the sidebar to switch to the 'Grade Current Enrollments' sub-screen.
        """
        self.add_to_sidebar(
            text="Grade Current Enrollments",
            callback=lambda: self.switch_screen(GradeCurrentEnrollment, {
                "student_pk": student_pk
            })
        )

    def create_option_upload_transcript(self, student_pk):
        """
        Adds a button to the sidebar to switch to the 'Upload Transcript' sub-screen.
        """
        self.add_to_sidebar(
            text="Upload Transcript",
            callback=lambda: self.switch_screen(UploadTranscript, {
                "student_pk" : student_pk
            })
        )

    def create_option_generate_transcript(self, student_pk):
        """
        Adds a button to the sidebar to switch to the 'Generate Transcript' sub-screen.
        """
        self.add_to_sidebar(
            text="Generate Transcript",
            callback=lambda: self.switch_screen(GenerateTranscript, {
                "student_pk": student_pk
            })
        )

    def enroll_student_in_courses(self, student_pk):

        self.add_to_sidebar(
            text="Enroll Student in Course",
            callback= lambda: self.switch_screen(EnrollStudentInCourse, {
                "student_pk": student_pk
            })
        )

    def add_to_sidebar(self, text: str, callback):
        """
        Adds a button to the sidebar with the specified text and callback function.
        Ensures the button is left-aligned.
        """

        but = tk.Button(self, text= "  "+text, command=callback, anchor="w", justify="left")
        but.pack(fill="x", padx=5, pady=2)

