import tkinter as tk
from tkinter import messagebox

from Classes import constants
from Classes.Util.server_req import ServerRequest


class EditPersonalDetails(tk.Frame):
    """
    This frame is used to edit personal details such as name, email, username, etc.
    """

    def __init__(self, container: tk.Frame, student_pk: int, admin_view: bool):
        super().__init__(container)

        self.container = container
        self.student_pk = student_pk
        self.admin_view = admin_view
        self.server_req = ServerRequest()

        # Fetch student data
        self.student_object = self.fetch_student_data()

        # Title
        title_text = f"Editing Personal Details for {self.student_object['fname']} {self.student_object['lname']}" \
            if admin_view else "Editing Your Personal Details"
        title = tk.Label(self, text=title_text, font=("Arial", 14, "bold"))
        title.grid(row=0, column=0, columnspan=2, pady=constants.default_pady)

        # Create labels and entry widgets for each field
        self.create_label_and_entry("First Name", self.student_object["fname"], 2)
        self.create_label_and_entry("Last Name", self.student_object["lname"], 3)
        self.create_label_and_entry("Email", self.student_object["email"], 4)
        self.create_label_and_entry("Username", self.student_object["username"], 5)
        self.create_label_and_entry("Phone", self.student_object["phone"], 6)
        self.create_label_and_entry("Address", self.student_object["address"], 7)

        # Save button
        save_button = tk.Button(self, text="Save", command=self.save_profile)
        save_button.grid(row=8, column=0, columnspan=2, pady=constants.default_pady)

    def fetch_student_data(self):
        """
        Fetches student data from the server.
        """
        return self.server_req.get_student(self.student_pk)

    def create_label_and_entry(self, label_text, value, row):
        """
        Creates a label and entry widget for a given field.
        """
        label = tk.Label(self, text=label_text)
        label.grid(row=row, column=0, sticky="e", padx=constants.small_padx, pady=constants.small_pady)
        entry = tk.Entry(self)
        entry.grid(row=row, column=1, padx=constants.small_padx, pady=constants.small_pady)
        entry.insert(0, value)
        setattr(self, f"{label_text.lower().replace(' ', '_')}_entry", entry)

    def save_profile(self):
        """
        Saves the updated personal details to the server.
        """
        # Collect data from entry widgets
        updated_data = {
            "fname": self.first_name_entry.get(),
            "lname": self.last_name_entry.get(),
            "email": self.email_entry.get(),
            "username": self.username_entry.get(),
            "phone": self.phone_entry.get(),
            "address": self.address_entry.get()
        }

        # Send update request to the server
        response = self.update_student_data(updated_data)

        # Handle response
        if 'success' in response:
            messagebox.showinfo("Success!", "The profile is now updated.")
            self.refresh_frame()
        elif 'err' in response:
            messagebox.showerror("Error", response['err'])
        else:
            messagebox.showerror("Error", "An unknown error occurred.")

    def update_student_data(self, updated_data):
        """
        Sends the updated data to the server.
        """
        if self.admin_view:
            return self.server_req.update_student(student_pk=self.student_pk, data=updated_data)
        return self.server_req.update_student(data=updated_data)

    def refresh_frame(self):
        """
        Refresh the frame by destroying and recreating it.
        """
        self.destroy()
        new_frame = EditPersonalDetails(self.container, self.student_pk, self.admin_view)
        new_frame.pack()
