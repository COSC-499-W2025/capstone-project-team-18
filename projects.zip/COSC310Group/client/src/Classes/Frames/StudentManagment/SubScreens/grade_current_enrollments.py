"""
This file defines the GradeCurrentEnrollment class.
"""

import tkinter as tk
from tkinter import messagebox

from Classes import constants
from Classes.Frames.StudentManagment.SubScreens.show_enrollments import ShowCourseBoxEnrollments
from Classes.Util.server_req import ServerRequest

class GradeCurrentEnrollment(ShowCourseBoxEnrollments):

    def __init__(self, container, student_pk: int):
        super().__init__(container,
                         student_pk= student_pk,
                         titleOfPage="Grade Student's Current Enrollments")

    def refresh_frame(self):
        """
        Refresh the current frame to update the displayed enrollments.
        """

        self.retrive_student_details()

        for widget in self.winfo_children():
            widget.destroy()

        self.define_body_visual_elements()

    def define_body_visual_elements(self):

        self.create_course_list(
            label_text="Enrollments",
            courses=self.enrollments,
            row=1,
            callbackFunc=self.on_grade_button_click,
            button_text="Grade"
        )

        if self.enrollments == []:
            tk.Label(self, text="No enrollments to grade!").grid(row=1, column=0, columnspan=2, pady=3, padx=3)

    def on_grade_button_click(self, course):
        """
        When user clicks the button create a popup frame. With
        grade text box
        """

        self.popup = tk.Toplevel(self.container)
        self.popup.title(f"Enter Grade")

        tk.Label(self.popup, text=f"Enter grade for course {course.get('title')} (0-100):").pack(pady=5)
        self.grade_entry = tk.Entry(self.popup)
        self.grade_entry.pack(pady=5)

        # Submit button
        submit_button = tk.Button(self.popup, text="Submit", command=lambda: self.submit_grade(course))
        submit_button.pack(pady=constants.default_pady)

    def submit_grade(self, course):
        """
        If grade is vaild, grade the course, otherwise give
        error message with why.
        """

        grade = self.grade_entry.get()

        response_message = self.vaildate_grade(grade)

        if response_message != "success":
            tk.messagebox.showerror("Invalid Input", response_message)
            return
        
        res = ServerRequest().grade_course(
            course_id=course.get("cid"),
            student_id=self.student_pk,
            grade = grade
            )
        
        status_code = res.status_code # get the http response status code
        info = res.json()

        if status_code == 200: # success, student already has GPA so we update it
            status_msg = 'Grade was saved, student dropped from course, and their GPA was updated.'
            messagebox.showinfo('Success', status_msg)
        elif status_code == 201: # success, student does not have GPA, so their GPA = course grade
            status_msg = 'Grade was saved, student dropped from course, and their GPA was created.'
            messagebox.showinfo('Success', status_msg)
        elif status_code == 400: # Something is missing from the request (e.g. course_id)
            error_msg = f"Tried to grade student, but got error: {info.get('bad request')}"
            messagebox.showerror("Error", error_msg)
            #raise ValueError(error_msg)
        elif status_code == 401:
            error_msg = f"Unauthorized: This is an admin-only permission."
            messagebox.showerror("Error", error_msg)
            #raise ValueError(error_msg)


        self.popup.destroy()
        self.refresh_frame()

    def vaildate_grade(self, grade) -> str:
        """
        Make sure the entry is a vaild number
        and that it is between 100 and 0
        """

        try:
            grade = float(grade)
            if 0 <= grade <= 100:
                return "success"
            else:
                return "Grade must be between 0 and 100."
        except ValueError:
            return "Please enter a valid number."
