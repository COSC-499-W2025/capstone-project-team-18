import tkinter as tk
from tkinter import filedialog, messagebox

from Classes import constants
from Classes.Util.server_req import ServerRequest

class GenerateTranscript(tk.Frame):

    report_txt : str = None

    def __init__(self, container, student_pk):
        super().__init__(container)

        self.student_pk = student_pk

        tk.Label(self, text="Generate Transcript").pack()

        #Deafult Selection XML
        self.selected_file_type = tk.StringVar(value='XML')
        sizes = (('.XML', 'XML'),
            ('.JSON', 'JSON'),
            ('.TXT', 'TXT')
            )

        # radio buttons
        for size in sizes:
            r = tk.Radiobutton(
            self,
            text=size[0],
            value=size[1],
            variable=self.selected_file_type
            )
            r.pack(padx=5, pady=5)

        generate_button = tk.Button(
            self,
            text="Generate report",
            command=self.generate_selected_report
        )
        generate_button.pack(padx=constants.small_padx, pady=constants.small_pady)

        download_button = tk.Button(
            self,
            text="Download report",
            command=self.download_report
        )
        download_button.pack(padx=constants.small_padx, pady=constants.small_pady)

        self.text_box = tk.Text(self, wrap='word', width=80, height=20)
        self.text_box.pack(side=tk.RIGHT, expand=True)

    def download_report(self):

        self.generate_selected_report()

        if self.report_txt is None:
            messagebox.showinfo("Error", "Generate a transcript first before downloading")
            return

        file_type = self.selected_file_type.get().lower()
        file_extension = f".{file_type.lower()}"
        file_name = f"transcript{file_extension}"

        # Open a file dialog to select the save location
        file_path = filedialog.asksaveasfilename(
            defaultextension=file_extension,
            filetypes=[(f"{file_type.upper()} files", f"*{file_extension}")],
            initialfile=file_name
        )

        if file_path:
            with open(file_path, 'w') as file:
                file.write(self.report_txt)


    def generate_selected_report(self):

        server_request = ServerRequest()

        try:
            self.report_txt = server_request.generate_report(file_type= self.selected_file_type.get(), student_pk = self.student_pk)
        except Exception as e:
            messagebox.showerror("Error", "Something went wrong with your request")

        self.text_box.config(state='normal')  # Enable editing temporarily
        self.text_box.delete('1.0', tk.END)
        self.text_box.insert(tk.END, self.report_txt)
        self.text_box.config(state='disabled')  # Disable editing again

