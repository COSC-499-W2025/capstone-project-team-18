"""
This file defines a subclass of ListCurrentEnrollments
"""

import tkinter as tk
from tkinter import messagebox

from Classes.Util.server_req import ServerRequest
from Classes.Frames.StudentManagment.SubScreens.show_enrollments import ShowCourseBoxEnrollments

class EditCurrentEnrollment(ShowCourseBoxEnrollments):
    """
    This frame is used to manage course enrollments and waitlists.
    """

    def __init__(self, container, student_pk: int, admin_view: bool):
        super().__init__(container,
                         student_pk = student_pk,
                         titleOfPage="Editing Enrollments and Waitlist"
                         )

        self.admin_view = admin_view

    def define_body_visual_elements(self):
        """
        Refreshes the course lists for enrollments and waitlists.
        """

        # Create course list for enrollments
        self.create_course_list(label_text="Enrollments",
                    courses=self.enrollments,
                    row=1,
                    callbackFunc=self.handle_enrollment_drop,
                    button_text="Drop"
                    )

        # Create course list for waitlist
        self.create_course_list(label_text="Waitlist",
                    courses=self.waitlist,
                    row=len(self.enrollments) + 3,
                    callbackFunc=self.handle_waitlist_drop,
                    button_text="Drop"
                    )

        if self.waitlist == [] and self.enrollments == []:
            tk.Label(self, text="No waitlist or enrollments this semester!").grid(row=1, column=0, columnspan=2, pady=3, padx=3)

    def handle_enrollment_drop(self, course):
        """
        Handles the drop button click for courses in enrollments.
        """

        course_id = course.get("cid")
        course_title = f"{course['department']} {course['title']}"

        if self.admin_view:
            messagebox_warning = f"You are about to drop student {self.student_object['fname']} {self.student_object['lname']} from the enrolled course {course_title}. Are you sure?"
        else:
            messagebox_warning = f"You are about to drop yourself from the enrolled course {course_title}. Are you sure?"

        self.drop_course_assignment(messagebox_warning, course_id)

    def handle_waitlist_drop(self, course):
        """
        Handles the drop button click for courses in waitlists.
        """

        course_id = course.get("cid")
        course_title = f"{course['department']} {course['title']}"

        if self.admin_view:
            messagebox_warning = f"You are about to remove student {self.student_object['fname']} {self.student_object['lname']} from the waitlisted course {course_title}. Are you sure?"
        else:
            messagebox_warning = f"You are about to remove yourself from the waitlisted course {course_title}. Are you sure?"

        self.drop_course_assignment(messagebox_warning, course_id)

    def drop_course_assignment(self, messagebox_warning: str, course_id):
        """
        Ask warning before droping
        """
        if messagebox.askyesno("Warning", messagebox_warning):
            self.server_req.drop_student(course_id, self.student_pk)
            self.refresh_frame()

    def refresh_frame(self):
        """
        Refresh the frame by destroying and recreating it.
        """
        self.destroy()
        new_frame = EditCurrentEnrollment(self.container, self.student_pk, self.admin_view)
        new_frame.pack()


