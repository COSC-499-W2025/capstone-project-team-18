import tkinter as tk
from tkinter import messagebox
from tkinter import filedialog as fd
import json
from Classes.Util.server_req import ServerRequest


class UploadTranscript(tk.Frame):

    def __init__(self, container, student_pk):
        super().__init__(container)

        self.student_pk = student_pk

        tk.Label(self, text="Upload Transcript").pack()

        tk.Label(self, text="The transcript must be in JSON format.").pack()

        tk.Button(
            self,
            text='Open Files',
            command=self.select_files
        ).pack()

        self.textbox = tk.Text(self, width=50, height=20)
        self.textbox.pack()

        self.submit_button = tk.Button(self, text="Submit", command=self.submit_transcript)
        self.submit_button.pack()

    def submit_transcript(self):
        transcript_data = self.textbox.get('1.0', 'end-1c').strip()

        # Strip whitespace and special characters
        transcript_data = ''.join(filter(str.isprintable, transcript_data))

        print(transcript_data)

        try:
            parsed_data = json.loads(transcript_data)

            ServerRequest().upload_transcript(self.student_pk, parsed_data)

            messagebox.showinfo("Success!", "Transcript as been updated")
        except json.JSONDecodeError as e:
            messagebox.showerror("Invalid Input", "Error: Invalid JSON format. Please check your input.")
        except ValueError as e:
            messagebox.showerror("Invaild Input", f"Error: {str(e)}")

    def select_files(self):

        filename = fd.askopenfilenames(
            title='Open files',
            initialdir='/',
            filetypes=[("JSON files", "*.json")])

        with open(filename[0], "r", encoding="utf-8") as f:
            string = "".join(char for char in f.read() if char.isalnum() or char.isspace() or char in '",_[].{}@:')

        self.textbox.insert("1.0", string)

