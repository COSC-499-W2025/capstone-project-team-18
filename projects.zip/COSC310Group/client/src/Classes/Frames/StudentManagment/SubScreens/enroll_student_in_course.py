import tkinter as tk
from tkinter import messagebox
from Classes.Util.global_state import GlobalState
from Classes.Util.server_req import ServerRequest
from Classes.Frames.StudentManagment.SubScreens.show_enrollments import ShowCourseBoxEnrollments

class EnrollStudentInCourse(ShowCourseBoxEnrollments):
    """
    Used for admins, enroll students in
    courses
    """

    def __init__(self, container, student_pk):
        super().__init__(container,
                    student_pk = student_pk,
                    titleOfPage="Enroll student in Course"
                    )


    def define_visual_elements(self):

        self.get_courses_not_enrolled()

        if len(self.courses_that_validate_search) == 0:
            tk.Label(self, text="Try searching for courses")

        searchbar_and_button = tk.Frame(self)
        searchbar_and_button.grid(row = 0, column= 0 )

        self.search_var = tk.StringVar()
        tk.Entry(searchbar_and_button, textvariable=self.search_var).grid(row=1, column=0)
        tk.Button(searchbar_and_button, text='Search', command=lambda: self.search_button_callback()).grid(row=1, column=2)
        self.refesh_course_list()

    def refesh_course_list(self):

        if self.course_list is not None:
            self.course_list.destroy()

        self.create_course_list(label_text="Avaiable Courses",
                    courses=self.courses_that_validate_search,
                    row=2,
                    callbackFunc=self.handle_enrollment,
                    button_text="Enroll"
                    )


    def search_button_callback(self):

        entrytext = self.search_var.get().lower()
        if entrytext == "keywords":
            entrytext=''

        self.courses_that_validate_search = []

        for course in self.free_course:
            if str(course.get('department') + ' ' + course.get('course_code') + ' ' + course.get('title')).lower().find(entrytext) != -1 or entrytext == '':
                self.courses_that_validate_search.append(course)

            if len(self.courses_that_validate_search) == 5:
                break

        self.refesh_course_list()


    def handle_enrollment(self, enroll_course):
        try:
            self.server_req.enroll_student(enroll_course.get("cid"), self.student_pk)
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        messagebox.showinfo("Success!", "Student is enrolled")

        for course in self.courses_that_validate_search:
            if course.get("cid") == enroll_course.get("cid"):
                self.courses_that_validate_search.remove(course)

        self.refesh_course_list()

    def get_courses_not_enrolled(self):
        self.courses_that_validate_search = []
        all_courses_from_server = self.server_req.get_courses(year=GlobalState.CURRENT_YEAR, session=GlobalState.CURRENT_SESSION)

        enrolled_cid = [c.get('cid') for c in self.enrollments]
        graded_cid = [c.get('cid') for c in self.graded_courses_this_year]
        waitlist_cid = [c.get('cid') for c in self.waitlist]

        for course in all_courses_from_server:
            if course.get('cid') in enrolled_cid or course.get('cid') in waitlist_cid or course.get('cid') in graded_cid:
               all_courses_from_server.remove(course)



        self.free_course = all_courses_from_server
