

import tkinter as tk

from Classes import constants
from Classes.Util.server_req import ServerRequest

class ShowCourseBoxEnrollments(tk.Frame):
    """
    This Frame simply gets CurrentEnrollments and displays that
    Box in this Frame. It is up to the subclass to implement callback
    logic
    """

    def __init__(self,
                 container: tk.Frame,
                 student_pk: int,
                 titleOfPage: str,
                 ):
        super().__init__(container)

        self.container = container
        self.student_pk = student_pk
        self.titleOfPage = titleOfPage
        self.server_req = ServerRequest()
        self.course_list = None

        self.retrive_student_details()

        # Refresh course lists
        self.define_visual_elements()

        self.pack()

    def define_visual_elements(self):
        title = tk.Label(self, text=self.titleOfPage)
        title.grid(row=0, column=0, columnspan=2, pady=constants.default_pady)

        self.define_body_visual_elements()

    def define_body_visual_elements(self):
        raise ValueError("Implement me in subclass")

    def retrive_student_details(self):
        student_object = self.server_req.get_student(self.student_pk)
        self.student_object = student_object

        self.enrollments = self.student_object.get("enrollments", [])
        self.waitlist = self.student_object.get("waitlist", [])
        self.graded_courses_this_year = self.student_object.get("previous_enrollments", [])

    def create_course_list(self, label_text, courses, row, callbackFunc, button_text):
        """
        Creates a list of courses for enrollments or waitlists.
        """
        self.course_list = tk.LabelFrame(self, text=label_text, font=('Verdana', constants.default_font_size, 'bold'))
        self.course_list.grid(row=row, column=0, rowspan=4, padx=constants.default_padx, pady=constants.default_pady, sticky="n")

        # Import is here to prevent circular imports
        from Classes.Frames.Dashboard.course_student_box import ListClass

        for course in courses:
            course_title = f"{course['department']} {course['title']}"

            cb = ListClass(
                parent=self.course_list,
                title=course_title,
                subtitle="",
                button_text=button_text,
                description="",
                on_button_click=lambda course=course: callbackFunc(course)
            )

            cb.create()
