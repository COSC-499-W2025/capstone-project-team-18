"""
This file defines the advance search Frame.
This file will be used by admins to search for
students by various advanced features
"""

import re
import tkinter as tk
from tkinter import messagebox
from Classes.Util.frame_factory import FrameFactory
from Classes.Util.server_req import ServerRequest
from Classes.Util.global_state import GlobalState
from Classes.Frames.Dashboard.course_student_box import ListClass
from Classes.Frames.StudentManagment.student_manager import StudentManagerFactory
from Classes import constants

class AdvanceStudentSearchFactory(FrameFactory):

    def build_args():
        return ()

    def create_frame(self, app, show_frame, edit_app_aspects, args):

        edit_app_aspects(
            title = "Advanced Student Search",
            geometry = constants.advanced_search_size,
            resizable = True
        )
        AdvanceStudentSearchFrame(app, show_frame, edit_app_aspects, args)

class AdvanceStudentSearchFrame(tk.Frame):
    """
    This class will allow sort and filter
    Student based on critiea. The following
    attruibutes can be filtered (query)
        - Course Membership
        - GPA (by range)
        - Name (search)

    The following attruibutes can be sorted:

        - GPA asec. desc.
        - Name (Alpsbetical)
        -
    """

    gpa_low : tk.StringVar
    gpa_high: tk.StringVar
    name_entry: tk.StringVar
    selected_course_id : str = None

    popup : tk.Frame = None

    student_results = None
    sort_direction = {'fname' : 0, 'lname' : 0, 'gpa' : 0} # Will be used to track if user is sorting asc or desc.

    container : tk.Frame

    def __init__(self, container, show_frame, edit_app_aspects, args):
        super().__init__(container)

        self.container = container
        self.show_frame = show_frame
        self.edit_app_aspects = edit_app_aspects

        self.define_visual_elements()

        self.pack()

    def clear_frame(self, tk_frame):
        for subframe in tk_frame.winfo_children():
            subframe.destroy()

    def define_visual_elements(self):
        """
        This function defines the visual
        elements of the Frame. There are
        two main things: The search boxs
        and the query
        """

        self.query_frame = tk.LabelFrame(self,
                                         text="Query",
                                         background=constants.foreground_color,
                                         font=constants.title_font_bold
                                         )

        self.result_frame = tk.Frame(self, background=constants.foreground_color)

        self.define_query_frame_visual()
        self.define_result_frame_visual()

        self.query_frame.pack(side=tk.LEFT)
        self.result_frame.pack(side=tk.LEFT, expand=True, padx=50, pady=50)

    def define_query_frame_visual(self):

        self.name_entry = tk.StringVar()
        self.gpa_low = tk.StringVar()
        self.gpa_high = tk.StringVar()

        tk.Label(self.query_frame,
                 font=constants.subtext_font,
                 text="Student Name:",
                 background=constants.foreground_color).pack(ipadx=2, ipady=2)

        tk.Entry(self.query_frame, textvariable=self.name_entry).pack()


        tk.Label(self.query_frame,
            font=constants.subtext_font,
            text="Grade Range:",
            background=constants.foreground_color).pack(ipadx=2, ipady=2)

        gpa_frame = tk.Frame(self.query_frame, background=constants.foreground_color)
        tk.Label(gpa_frame, text="GPA: From", background=constants.foreground_color, font=constants.subtext_font).pack(side="left")
        tk.Entry(gpa_frame, textvariable=self.gpa_low, width=5, font=constants.subtext_font, background=constants.foreground_color).pack(side="left")
        tk.Label(gpa_frame, text="To", background=constants.foreground_color, font=constants.subtext_font).pack(side="left")
        tk.Entry(gpa_frame, textvariable=self.gpa_high, width=5, font=constants.subtext_font, background=constants.foreground_color).pack(side="left")
        gpa_frame.pack(ipadx=10, ipady=10)

        tk.Label(self.query_frame,
            font=constants.subtext_font,
            text="Student is Enrolled in:",
            background=constants.foreground_color).pack(ipadx=2, ipady=2)

        # Course Membership
        tk.Button(self.query_frame,
                  text="Select Course",
                  command=self.open_course_finder,
                  background=constants.foreground_color).pack()


        self.selected_course_title = tk.StringVar(self, "")
        self.selected_course = tk.Label(self.query_frame,
                                        textvariable=self.selected_course_title).pack()

        tk.Button(self.query_frame,
                  text="Search Students",
                  command=lambda: self.populate_result_frame_with_students(),
                  background=constants.foreground_color).pack()

    def open_course_finder(self):

        self.popup = tk.Toplevel()

        self.search_var = tk.StringVar()
        tk.Entry(self.popup, textvariable=self.search_var).pack()
        tk.Button(self.popup, text='Search', command=lambda: self.course_search_button()).pack()

        self.search_res = tk.LabelFrame(self.popup, text="Course Results")
        self.search_res.pack()


    def course_search_button(self):

        self.clear_frame(self.search_res)

        entrytext = self.search_var.get().lower()

        course_added = 0

        for course in ServerRequest().get_courses(year=GlobalState.CURRENT_YEAR, session=GlobalState.CURRENT_SESSION):
            if str(course.get('department') + ' ' + course.get('course_code') + ' ' + course.get('title')).lower().find(entrytext) != -1 or entrytext == '':

                course_title = f"{course['department']} {course['course_code']} {course['title']}"

                cb = ListClass(
                    parent=self.search_res,
                    title=course_title,
                    subtitle="",
                    button_text="Select",
                    description="",
                    on_button_click= lambda course = course: self.select_course(course)
                )

                cb.create()
                course_added +=1

            if course_added == 5:
                break


    def destroy(self):
        if self.popup is not None:
            self.popup.destroy()

        return super().destroy()

    def select_course(self, course):
        self.popup.destroy()

        self.selected_course_title.set(f"{course['department']} {course['course_code']}")

        self.selected_course_id = course['cid']

    def define_result_frame_visual(self):

        self.clear_frame(self.result_frame)
        self.result_frame.grid_forget()

        if self.student_results is None:
            tk.Label(self.result_frame,
                     text="Try searching for students!").pack()
            return

        if len(self.student_results) == 0:
            tk.Label(self.result_frame,
                     text="No student match query.").pack()

            return



        attributes = [
            ("First Name", "fname"),
            ("Last Name", "lname"),
            ("GPA", "gpa")
        ]

        for col, (text, keyValue) in enumerate(attributes):
            '''
            label = tk.Label(self.result_frame,
                    text=text,
                    background=constants.foreground_color,
                    font=constants.title_font_bold
                    )

            #label.grid(column=col, row=0, padx=9, pady=9)
            '''
            tk.Button(
                self.result_frame,
                text=text,
                command=lambda key=keyValue: self.sort_students(key),
                font=constants.title_font_bold,
                background=constants.foreground_color
            ).grid(column=col, row=0, padx=9, pady=9)



            # label.bind(f"<Button-{col+1}>", lambda f: self.sort_students(attributes[col][1]))

        tk.Label(self.result_frame,
                 text="Edit Student",
                 background=constants.foreground_color,
                 font=constants.title_font_bold
                 ).grid(column=3, row=0)


        for row, student in enumerate(self.student_results):
            for col, (text, key) in enumerate(attributes):
                tk.Label(self.result_frame,
                         text=student.get(key),
                         background=constants.foreground_color,
                         ).grid(column=col, row=(row+1))

            tk.Button(self.result_frame,
                      text="Edit Student",
                      command=lambda id=student.get('id'): self.show_frame(StudentManagerFactory(), StudentManagerFactory.build_args(False, True, id)),
                      background=constants.foreground_color
                      ).grid(column= len(attributes), row=row+1)


    def is_valid_number(self, s):
        pattern = r'^(100(\.0{1,3})?|0?\d{1,2}(\.\d{1,3})?)$'
        return bool(re.fullmatch(pattern, s))

    def populate_result_frame_with_students(self):

        gpa_high_param = self.gpa_high.get()
        gpa_low_param = self.gpa_low.get()
        name_entry_param = self.name_entry.get().lower()
        course_id_param = self.selected_course_id

        if gpa_high_param == '':
            gpa_high_param = None

        if gpa_low_param == '':
            gpa_low_param = None

        if name_entry_param == "":
            name_entry_param = None

        if course_id_param == None:
            course_id_param = None

        if gpa_high_param is not None and not self.is_valid_number(gpa_high_param):
            messagebox.showerror("", "Invalid High GPA: Check your GPA and try again")
            return

        if gpa_low_param is not None and not self.is_valid_number(gpa_low_param):
            messagebox.showerror("", "Invalid Low GPA: Check your GPA and try again")
            return

        self.student_results = ServerRequest().get_student_by_params(
            gpa_max= gpa_high_param,
            gpa_min= gpa_low_param,
            name= name_entry_param,
            course_pk= course_id_param
        )
        # sort the resulting students gpa ascending by default
        sorted_students = sorted(self.student_results, key=lambda d: d['gpa'])
        self.student_results = sorted_students
        self.sort_direction['gpa'] += 1

        self.define_result_frame_visual()

    def sort_students(self, key):
        '''
        Sorts the student results by asc or desc
        according to first name, last name, or
        gpa
        '''

        self.clear_frame(self.result_frame)

        if self.sort_direction[key] % 2 == 0: # sort ascending
            sorted_students = sorted(self.student_results, key=lambda d: d[key])
            self.student_results = sorted_students
        else:
            sorted_students = sorted(self.student_results, key=lambda d: d[key], reverse=True)
            self.student_results = sorted_students

        self.sort_direction[key] += 1

        self.define_result_frame_visual()
