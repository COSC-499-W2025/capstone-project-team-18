""" This defines the login frame for the client. """

import tkinter as tk
from tkinter import messagebox
from typing import TYPE_CHECKING, Callable
from urllib3.exceptions import NewConnectionError
from requests.exceptions import ConnectionError

from Classes import constants
from Classes.Util.server_req import ServerRequest
from Classes.Util.frame_factory import FrameFactory
from Classes.Frames.Dashboard.student_dashboard import StudentDashboardFactory
from Classes.Frames.Dashboard.admin_dashboard import AdminDashboardFactory

# This trick here avoids a circular import issue in Python
# App only needs to be import to help our dev experience, but
# will lead to an error if we import it outright.
if TYPE_CHECKING:
    from app import App

class LoginFrameFactory(FrameFactory):

    @staticmethod
    def build_args():
        return ()

    def create_frame(self, app: tk.Frame, show_frame: Callable, edit_app_aspects: Callable, args) -> tk.Frame:

        edit_app_aspects(
            title = "Login",
            geometry = constants.login_size,
            resizable = False
        )

        LoginWindow(app, show_frame).pack(fill="both", expand=True)

class LoginWindow(tk.Frame):
    """
    This is the LoginWindow. It has a username, login field and a submit button.
    This frame is the landing page for any client. After a succesful login,
    the user should be taken to the dashboard.
    """

    show_frame: Callable

    def __init__(self, container: tk.Frame, show_frame: Callable):
        super().__init__(container)

        self.show_frame = show_frame
        self.container = container # we are passing in the App object from app.py

        self.create_widgets().pack(side=tk.TOP, expand=True)

        tk.Label(self, background=constants.navigation_button_bg_color, text="No Login? Try username: johndoe, password: !hashmeplease!", fg='white').pack(anchor='s', expand=True, ipadx=100, pady=(40,0))

    def create_widgets(self):
        """
        This defines the master layout. How the page should look
        """

        self.config(background=constants.navigation_button_bg_color)

        root = tk.LabelFrame(self, relief="raised",background='white')
        root.bind("<Button-1>",lambda x:self.click_root())

        # configure the grid
        root.columnconfigure(0, weight=1)
        root.columnconfigure(1, weight=3)

        tk.Label(root, text="Sign in",background='white', font=('Verdana', 20,'bold')).grid(column=0, row=0, columnspan=2, pady=(20,20),padx=80)

        # username
        self.user_entry = tk.Entry(root,fg='gray',font=('Verdana', constants.default_font_size),highlightbackground=constants.navigation_button_bg_color,highlightthickness=2)
        self.user_entry.grid(column=0, columnspan=2, row=1, sticky='nsew', padx=constants.large_padx, pady=(0,15),ipady=2,ipadx=2)
        self.user_entry.insert(0,'Username')
        self.user_entry.bind("<Button-1>",lambda x:self.click_user())

        # password
        self.pass_entry = tk.Entry(root,fg='gray',font=('Verdana', constants.default_font_size),highlightbackground=constants.navigation_button_bg_color,highlightthickness=2)
        self.pass_entry.grid(column=0, columnspan=2, row=2, sticky='nsew', padx=constants.large_padx, pady=(0,15),ipady=2,ipadx=2)
        self.pass_entry.insert(0,'Password')
        self.pass_entry.bind("<Button-1>",lambda x:self.click_pass())
        self.pass_entry.bind("<FocusIn>", lambda x: self.click_pass())

        # login button
        login_button = tk.Button(root,fg='white',bg=constants.navigation_button_bg_color,text="Log in", font=('Verdana', constants.default_font_size, 'bold'), command= self.authenticate)
        login_button.grid(column=0, columnspan=2, row=3, sticky='nsew', padx=constants.large_padx, pady=(10,20),ipadx=2)

        return root

    def click_user(self):
        '''If temp text is displayed, remove it, if other entry box is empty, set temp text'''
        if self.user_entry.get() == "Username":
            self.user_entry.delete(0,'end')
        self.user_entry.config(fg='black')
        if len(self.pass_entry.get()) == 0:
            self.pass_entry.config(fg='gray',show="")
            self.pass_entry.insert(0,'Username')
    def click_pass(self, event=None):
        '''If temp text is displayed, remove it, if other entry box is empty, set temp text'''
        if self.pass_entry.get() == "Password":
            self.pass_entry.delete(0, 'end')
        self.pass_entry.config(fg='black', show="•")
        if len(self.user_entry.get()) == 0:
            self.user_entry.config(fg='gray')
            self.user_entry.insert(0, 'Username')

    def click_root(self):
        '''If any entry box is empty, set temp text'''
        self.focus()
        if len(self.user_entry.get()) == 0:
            self.user_entry.config(fg='gray')
            self.user_entry.insert(0,'Username')
        if len(self.pass_entry.get()) == 0:
            self.pass_entry.config(fg='gray',show="")
            self.pass_entry.insert(0,'Password')

    def authenticate(self):
        """
        When a user hits submit on this Frame, this function will vaildate their login.
        It will either display a messsage box will a error message or it will take the
        user to the dashboard.
        """

        user_input = self.user_entry.get()
        pass_input = self.pass_entry.get()

        # Replace placeholder text in text boxes with empty strings.
        # This ensures that if the user tries submitting without typing anything,
        # the endpoint reads the request as {'username': ''} and not {'username': 'Username'}.
        # The same goes for pswd.
        if user_input == "Username":
            user_input = ''
        if pass_input == 'Password':
            pass_input = ''

        serverReq = ServerRequest()

        response = serverReq.login(username = user_input, password = pass_input)


        if response.status_code == 200:
            return self.login_success(response.json().get('user_role'))
        if response.status_code == 400:
            if response.json().get('bad request') == 'missing username':
                messagebox.showinfo("Error", "Missing username. Please enter and try again.")
            elif response.json().get('bad request') == 'missing pswd':
                messagebox.showinfo("Error", "Missing password. Please enter and try again.")
        elif response.status_code == 401:
            messagebox.showinfo("Error", 'Invalid credentials, try again')

    def login_success(self, user_role):
        """
        Called when the user has a successful login. This function will take the App to the
        dashboard.
        """

        if user_role ==  'admin':
            self.show_frame(AdminDashboardFactory())
        else:
            self.show_frame(StudentDashboardFactory())
