"""
This file defines a switchable frame
"""

from typing import TYPE_CHECKING

import tkinter as tk
from tkinter import messagebox

from Classes.Frames.Login.login import LoginFrameFactory
from Classes.Frames.AdvancedSearch.advance_student_search import AdvanceStudentSearchFactory
from Classes.Frames.StudentManagment.student_manager import StudentManagerFactory

from Classes.Util.frame_factory import FrameFactory
from Classes.Util.global_state import GlobalState

if TYPE_CHECKING:
    from app import App

class SwitchableFrame(tk.Frame):
    """
    This function defines a switchable Frame.
    A switchable Frame is a Frame that can be switched
    with other Frames.

    The class keeps track of the stack that is created
    by switching frames, so it is possible to "go back"
    think the back button in your browser.
    """

    app: 'App'

    # A list of frames that the user has visted. Added for the back button feature
    frame_stack: list = []
    current_frame_state : tuple = None

    # Current Frame
    display_frame : tk.Frame

    def __init__(self, app : 'App'):
        super().__init__(app)

        self.app = app

        self.display_frame = tk.Frame()
        self.display_frame.pack(padx=50, pady=30)

        self.start_session()

    def start_session(self) -> bool:
        """
        This function will completely wipe the current
        session and it will start a new one. Can be used
        on startup, or on logout.
        """

        self.clear_frame()

        # Clear all history
        self.frame_stack = []
        self.current_frame_state = None

        GlobalState().logout()

        # Go to login
        args = LoginFrameFactory.build_args()
        self.show_frame(LoginFrameFactory(), args)

    def show_my_profile(self):
        """
        Go see my own profile. Will be called by menu taskbar
        function.
        """

        if not GlobalState().is_user_logged_in():
            messagebox.showinfo("Error", "You must login before you can see your profile")
            return

        args = StudentManagerFactory.build_args(user_own_profile=True, user_is_admin= GlobalState().is_user_admin())

        self.show_frame(StudentManagerFactory(), args)

    def show_frame(self, frame_factory : FrameFactory, args : tuple = None, going_back: bool = False):
        """
        Frames are seprate screens. Student Dashboard, Admin Dashboard,
        Profile, etc. A frame is unquily identifiyed by the FrameFactory
        class and arguments.

        This class handles all the switching logic, that is switching
        between screens.

        We do this with the factory method design pattern.
        Every main screen has a Factory that extends the FrameFactory
        class. The FrameFactory then makes that screen and we go to it.

        That frame handles the moment we switch to another screen, and
        uses this method to switch the screen.

        We also define a stack of frame. We only add to this stack when
        we leave a current frame and we only add to this stack if the
        FrameFractory or it's arugments we pass into it are different.

        We return FrameInstance for testing.
        """

        if self.current_frame_state is not None \
            and not going_back \
            and (self.current_frame_state[0], self.current_frame_state[1]) != (type(frame_factory), args):

            self.frame_stack.append(self.current_frame_state)

        self.clear_frame()

        to_return = frame_factory.create_frame(self.display_frame,
                                               self.show_frame,
                                               self.app.edit_app_aspects,
                                               args)

        self.current_frame_state = (type(frame_factory), args)

        return to_return

    def window_arugments():
        pass

    def refresh_current_frame(self):
        """
        Called when calls to the database require a referesh
        of the page. It will take the current frame state and
        load it all again
        """
        frame_fract, args = self.current_frame_state
        self.show_frame(frame_factory=frame_fract(), args=args, going_back=True)

    def clear_frame(self):
        """
        Clear this frame.
        """
        for widget in self.display_frame.winfo_children():
            widget.destroy()

    def go_back(self):
        """
        This method will go back to the previous screen in the stack.
        If the back is to the login screen, show a confirmation dialog.
        """

        # Under normal situations show screen
        if len(self.frame_stack) > 1:

            frame_factory, args = self.frame_stack.pop()

            self.show_frame(frame_factory(), args, going_back = True)

        # In case the previous screen was the login screen. Make sure user wants to log out
        elif len(self.frame_stack) == 1:
            self.log_out()

        # In case the stack is empty
        else:
            messagebox.showinfo("Error", "No screen to go back to.")

    def log_out(self):

        if len(self.frame_stack) == 0:
            return

        if not messagebox.askyesno("Confirm Logout", "Are you sure you want to log out?"):
            return

        self.start_session()

        return
