navigation_button_bg_color = '#230a3c'
default_font_size = 10
title_font_size = 15
dashboard_size = "1000x700"
admin_dashboard_size="1300x700"
advanced_search_size = "1200x400"
default_pady = 10
default_padx = 10
large_padx = 15
csb_height = 50
csb_width = 300
small_padx = 5
small_pady = 5
login_size = "500x460"


global_typeface = "Verdana"

title_font_bold = (global_typeface, 20, 'bold')
deafult_font = (global_typeface, 13)
subtext_font = (global_typeface, 10)
background_color = '#230a3c'
foreground_color = 'white'
