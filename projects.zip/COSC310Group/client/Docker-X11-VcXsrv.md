# Docker, X11, and VcXsrv Info

*This file is to contextualize what Docker is and how we can deploy a GUI using Docker on Windows OS.*

Docker is utilized for delivering software in packages called containers. However, displaying a GUI is not one of Docker's purposes, and so it does not have access to a display or graphical environment. Thus, we cannot run a GUI app from a Docker container out of the box.

### What Makes Up Docker? - The Recipe Analogy

Let's quickly cover what actually makes up Docker. In our `client` directory, we have the `Dockerfile`. Also, in the Docker Desktop app, you will see the four tabs on your left: Builds, Volumes, Images, Containers. Let's take a closer look at them:

1. **`Dockerfile`:** Think of the Dockerfile as a recipe for a yummy cake that you quickly wrote down on a notecard. Your handwriting is quite messy and the recipe is only really legible to you (i.e., the app only works on your local device).
2. **Builds**: Now, you want a legible form of your recipe to share with others. So, you go to your computer, create a new GitHub repo with a `cake-build.md` file, and enter the ingredients and steps in as you read them from your notecard. Each time you save some changes to the `.md` file (say, enter a new ingredient or step) you push those changes to your Main branch. Because your changes are being pushed, you can track them. Similarly, the Build tab in Docker Desktop shows the history of your build processes (i.e., every time you ran `docker build`). Each of these builds are images that were made using a `Dockerfile`. When you run the `docker build` command, Docker reads your `Dockerfile` and builds an image with it.
    - Example: `docker build -t tkinter-gui-app .` The `-t` flag is used to tag an image with a name (here our name is `tkinter-gui-app`). The `.` is used to tell docker to use the current directory as the build context. This means that docker will include everything inside the current directory when it builds an image (except for anything specified in a `.dockerignore` file, if one is provided).
3. **Images:** Think of an image as the neatly typed recipe for your cake. It is a template that contains all of the instructions (layers) and ingredients (dependencies, libraries, code, etc.) needed for anyone to be able to bake your cake. Now that your recipe is legible to others, it can be shared! However, the recipe is read-only; only you can update it. In the Images tab on Docker Desktop, you will see all of the images you have created. This differs from the Builds tag because images in the Images tab are identified by their name (e.g., `tkinter-gui-app`), tag (e.g., `latest`, `1.1`), and Image ID.
    - *Note: A Docker image's tag should not be confused with the tag flag `-t` that is used when building a Docker image. The `-t` flag is for naming the image; the image's tag is an optional identifier used to represent a specific version or variant of the image.*
    - *Note: A Docker image's Image ID is a unique identifier for assigned to that specific image.*
4. **Containers:** Containers are the cakes themselves. You and others can use the neatly-typed  cake recipe (image) to create your very own cake (container). That is, containers are running instances of images.
5. **Volumes:** I don't really know how to fit this into the cake analogy so I'm going to use a different one instead. Image you work from home and have a filing cabinet with important documents pertaining to your job. One day, you get a job offer at a better company and take it. Because you work from home, there isn't cubicle for your old company to clean out in their building, and so you get to keep the documents from your old job. Similarly, a volume is a place in Docker where you can externally store data for a container outside of the container externally. If you were to change jobs (containers), you still get to keep the files from your old job in your filing cabinet (volume).

- **Bonus:** Our app is going to need multiple containers- one for the Tkinter app, one for the Flask app, and one for the DB. We create a `docker-compose.yml` file in the main directory to define and run a multi-container app in a single container.

## X11

Before we dive into what VcXsrv's purpose is, we need to understand what X11 is. X11 (aka X, X server, or 𝕏) is an application built for Unix-like operating systems (e.g. Ubuntu) that works as a server, which can be ran locally or remotely. It manages ≥ 1 GUIs and ≥ 1 user input devices (e.g., a keyboard) for Unix-like operating systems. This allows users to run GUI apps inside a Linux system and allows applications to receive input from the user.

## VcXsrv

Now, you might be asking yourself, "X11 is built for Unix-like operating systems but Windows isn't Unix based, so how do we use it?" This is where VcXsrv (**V**isual **C**++ **X** **S**e**rv**er) comes into play! VcXsrv is simply an X server designed to run on Windows devices. Docker Desktop for Windows installs a sort of "middle-man" between Windows and Unix called WSL2. However, if we try to run a Tkinter GUI app in Docker it won't have any way to open the GUI because it doesn't know how to. With VcXsrv, Docker has an X server to forward the Tkinter GUI to (which doesn't even need to be running on the user's local device) and the X server will handle displaying the GUI and managing user input.
****

Now that you have an understanding of what Docker is, and what programs are needed to get a GUI working in a Docker container on Windows, refer to [README.md](README.md#Windows) for steps to get a Docker container up and running.
