#!/bin/bash

# To run this file, run `sh macOS-startup.sh`.

# This opens the XQuartz. `osascript -e` minimizes the XQuartz terminal.
# The -a flag returns true of the file (XLaunch) exists.
osascript -e open -a XQuartz 


# This removes everything from the access control list (just a precaution)
xhost -

# Add local host to the access control list
xhost + 127.0.0.1

# Build the container
docker compose up --build
