# Startup Script Directory

This directory contains the startup scripts to start the app on macOS and Windows devices. It also contains the script to run all of our pytests and a Docker compose file to run the pytests in our Docker container.

For a full setup guide on running this app locally, refer to the "Setup Guide for Local Development" page on our repo wiki.

``` txt
startup-testing-scripts/
|── README.md
├── macOS-startup.sh
├── docker-testing/
│   ├── ci_mac.sh
│   └── docker-compose.ci.yml
└── windows/
    ├── config.xlaunch
    └── windows-startup.ps1
```

****

## The `macOS-startup.sh` Script

This is the startup script for running the app on macOS devices. It will start XQuartz with preconfigured settings, then start the docker container using the `docker-compose.yml` file in the root directory.

To run this script, cd to the `startup-testing-scripts` directory, then run `sh macOS-startup.sh`.

## The `/docker-testing/` Directory

``` txt
docker-testing/
├── ci_mac.sh
└── docker-compose.ci.yml
```

### `ci_mac.sh1`

This script will automatically test all of our pytest unit tests for us. To run this script, cd into `docker-testing`, then run `sh ci_mac.sh`.

*Note: This script will not work with Powershell.*

### `docker-compose.ci.yml`

This file is different from the `docker-compose.yml` file in the root directory. This is a docker compose .ci (Continuous Intergration) file, meaning it will run the pytests *in the docker container* and check the logs of the Docker container to verify the outcome of the tests.

The idea behind this file is that you run the ci_mac.sh script to ensure tests work locally on your machin, and then run this file. To run this file, cd into `docker-testing` and run the file with `docker compose -f docker-compose.ci.yml up -d --build` to verify that it works in the Docker container.

## The `windows` Directory

``` txt
windows/
├── ci_mac.sh
└── docker-compose.ci.yml
```

### `config.xlaunch`

This file is used in `windows-startup.ps1` to configure the VcXsrv X Server when it is launched. Do not modify it.

### `windows-startup.ps1`

This is the startup script for running the app on Windows devices. It will start XLaunch (VcXsrv) with the preconfigured settings defined in `config.xlaunch`, then start the docker container using the `docker-compose.yml` file in the root directory.

To run this script, cd into `/windows`, then run `.\windows-startup.ps1` (or, `powershell -File "windows-startup.ps1"` if using Command Prompt).
