# This will start XLaunch with preconfigured settings.
Invoke-Item ".\config.xlaunch"

# To run this file, run `.\startup-testing-scripts\windows\windows-startup.ps1`

# Start the docker container
docker compose up --build