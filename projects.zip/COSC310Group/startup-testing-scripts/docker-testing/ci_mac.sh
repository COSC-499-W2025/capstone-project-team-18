#!/bin/bash
# Small quality of life script to test services automatically
docker-compose up -d mysql server

# Wait for the docker containers to be fully up and running
until docker-compose exec mysql mysqladmin ping -h "127.0.0.1" --silent; do
    echo "Waiting for mysql container..."
    sleep 2
done

# Wait server is up by pinging server
until [ "$(curl http://localhost:8000/ping)" == "I have been pinged" ]; do
    echo "Waiting for server container..."
    sleep 2
done

cd ../../server/src

pytest

cd ../../client/src

pytest
