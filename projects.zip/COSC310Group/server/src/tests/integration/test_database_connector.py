"""
File to integration test the class DatabaseConnector. Must have the SQL docker container running!
"""

import pytest
from Classes.database_connector import DatabaseConnector # pylint: disable=import-error
import mysql.connector
from mysql.connector import errorcode


def test_for_singleton():
    """
    Test that if two different DatabaseConnectors are 
    created, they point to the same object instance
    """
    s1 = DatabaseConnector()
    s2 = DatabaseConnector()
    assert id(s1) == id(s2)

@pytest.fixture(scope="session", autouse=True)
def setup_and_cleanup():
    """
    Here we clean the DB so that we can perfom our tests without worrying and what state
    the DB is in. Then we cleanup to leave it the way we found it. The only data we assume
    to be present in database and unaltred are the data in test.

    Obviously this needs the functions we are testing to be working. But we will lead to
    failures if is not working so tests will fail :).

    All example data we will test with as the prefix test_ in the username and test. in the
    email. DO NOT USE THESE PREFIXS IN NORMAL WORK!
    """

    connector = DatabaseConnector()

    delete_stmt = "DELETE FROM UserLogin WHERE username LIKE 'test_%'"

    # If there are any inserts from failed tests, get rid of them
    connector.delete(delete_stmt)

    yield # This is where all testing happends

    # Clean up our data we left in DB
    connector.delete(delete_stmt)


def test_connection_to_database():
    """
    This test makes sure that the DatabaseConnector, can, in fact connect to the database.
    """

    connector = None

    try:
        connector = DatabaseConnector()
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            raise mysql.connector.errors.ProgrammingError(
                "Something is wrong with your user name or password"
                )
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            raise mysql.connector.errors.DatabaseError(
                "Database does not exist. Is the database docker container running?"
                )
        else:
            raise err

    assert connector.cnx is not None, ("No connection could be made with database"
                                       "in Database Connector class")

def test_query():
    """
    This test will query the database with an object that is known 100% to be in the database.
    """

    connector = DatabaseConnector()

    sql = ("SELECT fname, lname, email, username, phone, address, role "
            "FROM UserLogin WHERE username = %s")

    params = ('johndoe', )

    results = connector.query(sql, params)

    assert len(results) == 1, "Expected one result got " + str(len(results))

    user = results[0]
    assert user == ('John', 'Doe', 'john.doe@example.com',
                    'johndoe', '123-456-7890', '123 Main St', 'student'), \
        "User data does not match expected values"

def test_query_json():
    """
    This function is the exact same as test_query, but it returns everything in a JSON format
    """

    connector = DatabaseConnector()

    sql = ("SELECT fname, lname, email, username, phone, address, role "
            "FROM UserLogin WHERE username = %s")

    params = ('johndoe', )

    results = connector.query_json(sql, params)

    assert len(results) == 1, "Expected one result got " + str(len(results))
    assert results == [
        {'fname': 'John',
         'lname': 'Doe',
         'email': 'john.doe@example.com',
         'username': 'johndoe',
         'phone': '123-456-7890',
         'address': '123 Main St',
         'role': 'student'}
         ], "Actual JSON does not match expected JSON"

def test_empty_query():
    """
    This test will query the database for empty UserLogin. This can not happen, so it
    will return nothing. If anything else happens, something has gone wrong.
    """

    connector = DatabaseConnector()

    sql = ("SELECT fname, lname, email, username, phone, address, role "
            "FROM UserLogin WHERE username IS NULL")

    results = connector.query(sql)

    assert len(results) == 0, "Expected no result got " + str(len(results))

def test_empty_query_json():
    """
    This test is the same as test_empty_query, but testing for JSON results
    """

    connector = DatabaseConnector()

    sql = ("SELECT fname, lname, email, username, phone, address, role "
            "FROM UserLogin WHERE username IS NULL")

    results = connector.query_json(sql)

    assert len(results) == 0, "Expected no result got " + str(len(results))


def test_insert_single():
    """
    This test will insert a single record into the database and verify that it was inserted
    correctly.
    """

    connector = DatabaseConnector()

    salt = "4596b6084ae03f1612ca480d3fd9ac62"
    password = "be57475eb03835d55df9c7720b0d641ba16dbc3086ab71d02dc143cd4f3aa3b2"

    insert_stmt = (
        "INSERT INTO UserLogin "
        "(fname, lname, email, username, salt, password, phone, address, role) "
        "VALUES ('Amy', 'Smith', 'test.amy.smith@gmail.com', 'test_amy123', "
        f"X'{salt}', "
        f"X'{password}', "
        "'123-456-7890', 'Main St.', 'student')"
    )

    primary_key = connector.insert(insert_stmt)

    assert primary_key > 0, "Primary key returned not vaild"

    query_stmt = (
        "SELECT fname, lname, email, username, salt, password, phone, address, role "
        "FROM UserLogin WHERE id = %s"
    )
    query_params = (primary_key,)
    results = connector.query(query_stmt, query_params)

    assert len(results) == 1, "Expected one result, got " + str(len(results))

    user = results[0]
    expected_user = (
        'Amy', 'Smith', 'test.amy.smith@gmail.com', 'test_amy123',
        bytes.fromhex(salt),
        bytes.fromhex(password),
        '123-456-7890', 'Main St.', 'student'
    )

    assert user == expected_user, "User data does not match expected values"

def test_insert_multiple():
    """
    Insert mutiple statments into DB. Makes sure that given two that the infomation is
    present on the database
    """

    connector = DatabaseConnector()

    salt = "4596b6084ae03f1612ca480d3fd9ac62"
    password = "be57475eb03835d55df9c7720b0d641ba16dbc3086ab71d02dc143cd4f3aa3b2"

    insert_stmt = (
        "INSERT INTO UserLogin "
        "(fname, lname, email, username, salt, password, phone, address, role) "
        "VALUES (%s, %s, %s, %s, "
        "X%s, "
        "X%s, "
        "%s, %s, %s)"
    )

    stmt_list = [insert_stmt, insert_stmt]

    parameters = [
        ('Steve', 'Jones', 'test.steve.jones@example.com', 'test_jone_steve',
          salt, password, '123-456-7890', '123 Main St', 'student'),
        ('Jane', 'Doe', 'test.jane.doe@example.com', 'test_janedoe',
          salt, password, '987-654-3210', '456 Elm St', 'admin')
    ]

    primary_key = connector.insert(stmt_list, parameters)

    assert len(primary_key) == 2, "Insert returned more or less primary keys than insert statment"

    query_stmt = (
        "SELECT fname, lname, email, username, salt, password, phone, address, role "
        "FROM UserLogin WHERE id IN (%s, %s)"
    )
    query_params = (primary_key[0], primary_key[1])
    results = connector.query(query_stmt, query_params)

    assert len(results) == 2, "Expected two results, got " + str(len(results))

    expected_user = parameters

    expected_users = [
        (
            'Steve', 'Jones', 'test.steve.jones@example.com', 'test_jone_steve',
            bytes.fromhex(salt), bytes.fromhex(password),
            '123-456-7890', '123 Main St', 'student'
        ),
        (
            'Jane', 'Doe', 'test.jane.doe@example.com', 'test_janedoe',
            bytes.fromhex(salt), bytes.fromhex(password),
            '987-654-3210', '456 Elm St', 'admin'
        )
    ]

    for user, expected_user in zip(results, expected_users):
        assert user == expected_user, "User data does not match expected values"
def test_delete():
    """
    This test will insert a record into the database, delete it, and verify that it was deleted
    correctly.
    """

    connector = DatabaseConnector()

    salt = "4596b6084ae03f1612ca480d3fd9ac62"
    password = "be57475eb03835d55df9c7720b0d641ba16dbc3086ab71d02dc143cd4f3aa3b2"

    insert_stmt = (
        "INSERT INTO UserLogin "
        "(fname, lname, email, username, salt, password, phone, address, role) "
        "VALUES ('Mark', 'Brown', 'test.mark.brown@gmail.com', 'test_mark123', "
        f"X'{salt}', "
        f"X'{password}', "
        "'123-456-7890', 'Main St.', 'student')"
    )

    primary_key = connector.insert(insert_stmt)

    assert primary_key > 0, "Primary key returned not valid"

    delete_stmt = "DELETE FROM UserLogin WHERE id = %s"
    delete_params = (primary_key,)
    rows_affected = connector.delete(delete_stmt, delete_params)

    assert rows_affected == 1, "Expected one row to be deleted, got " + str(rows_affected)

    query_stmt = (
        "SELECT fname, lname, email, username, salt, password, phone, address, role "
        "FROM UserLogin WHERE id = %s"
    )
    query_params = (primary_key,)
    results = connector.query(query_stmt, query_params)

    assert len(results) == 0, "Expected no results, got " + str(len(results))

def test_insert_invalid_data():
    """
    This test will attempt to insert invalid data into the database and verify that it fails.
    """

    connector = DatabaseConnector()

    insert_stmt = (
        "INSERT INTO UserLogin "
        "(fname, lname, email, username, salt, password, phone, address, role) "
        "VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)"
    )

    try:
        connector.insert(insert_stmt)
        assert False, "Expected an error due to invalid data, but insert succeeded"
    except mysql.connector.Error:
        pass  # Expected behavior

def test_insert_rollback():
    """
    This test will test the rollback function. It will insert one valid statement
    and one invalid statement. There will be a Programming error. Then, we make sure our
    first statement did not in fact make it to the DB.
    """

    connector = DatabaseConnector()

    valid_stmt = (
        "INSERT INTO UserLogin "
        "(fname, lname, email, username, salt, password, phone, address, role) "
        "VALUES ('Rollback', 'Test', 'test.rollback.test@gmail.com', 'test_rollback123', "
        "X'4596b6084ae03f1612ca480d3fd9ac62', "
        "X'be57475eb03835d55df9c7720b0d641ba16dbc3086ab71d02dc143cd4f3aa3b2', "
        "'123-456-7890', 'Main St.', 'student')"
    )

    invalid_stmt = (
        "INSERT INTO UserLogin "
        "(fname, lname, email, username, salt, password, phone, address, role) "
        "VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)"
    )

    stmt_list = [valid_stmt, invalid_stmt]

    try:
        connector.insert(stmt_list)
        assert False, "Expected an error due to invalid data, but insert succeeded"
    except mysql.connector.Error:
        pass  # Expected behavior

    query_stmt = (
        "SELECT fname, lname, email, username, salt, password, phone, address, role "
        "FROM UserLogin WHERE username = %s"
    )
    query_params = ('test_rollback123',)
    results = connector.query(query_stmt, query_params)

    assert len(results) == 0, "Expected no results, got " + str(len(results))

def test_update():
    """
    This test will insert a record into the database, update it, and verify that it was updated
    correctly.
    """
    connector = DatabaseConnector()

    salt = bytes.fromhex("4596b6084ae03f1612ca480d3fd9ac62")
    password = bytes.fromhex("be57475eb03835d55df9c7720b0d641ba16dbc3086ab71d02dc143cd4f3aa3b2")

    # Insert a record to update
    insert_stmt = (
        "INSERT INTO UserLogin (fname, lname, email, "
        "username, salt, password, phone, address, role) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
    )
    insert_params = (
        'Test', 'User', 'test.user@example.com', 'test_testuser', salt,
        password, '123-456-7890', '123 Test St', 'student'
    )

    primary_key = connector.insert(insert_stmt, insert_params)

    assert primary_key > 0, "Primary key returned not valid"

    # Update the record
    update_stmt = (
        "UPDATE UserLogin SET fname = %s, lname = %s, email = %s, "
        "phone = %s, address = %s WHERE id = %s"
    )
    update_params = (
        'Updated', 'User',
        'test.updated.user@example.com',
        '987-654-3210', '456 Updated St', primary_key
    )
    rows_affected = connector.update(update_stmt, update_params)

    assert rows_affected == 1, "Update failed, no rows affected"

    # Verify the update
    query_stmt = (
        "SELECT fname, lname, email, username, salt, password, phone, address, role "
        "FROM UserLogin WHERE id = %s"
    )
    query_params = (primary_key,)
    results = connector.query(query_stmt, query_params)

    assert len(results) == 1, "Expected one result, got " + str(len(results))

    user = results[0]
    expected_user = (
        'Updated', 'User', 'test.updated.user@example.com', 'test_testuser',
        salt, password, '987-654-3210', '456 Updated St', 'student'
    )
    assert user == expected_user, "User data does not match expected values"
