"""
This file will test the following endpoints:
    - student/enroll
    - student/drop
    - student/info
    - student/update
"""
import pytest
from Classes.database_connector import DatabaseConnector # pylint: disable=import-error
from app import app # pylint: disable=import-error
from Util.make_token import Token

connector = DatabaseConnector()

def __delete_all_test_inserts():
    """
    Delete everything test from the database
    """
    delete_userlogin_stmt = "DELETE FROM UserLogin WHERE username LIKE 'test_%'"
    delete_course_stmt = "DELETE FROM Course WHERE department = 'TEST'"

    connector.delete([delete_userlogin_stmt, delete_course_stmt])

def __insert_test_variables() -> tuple:
    """
    Insert two UserLogins and one course. Will be deleted with __delete_all_test_inserts
    """
    insert_user_1 = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Ardal', 'Bader', 'test_ardal_bader99@mail.com', 'test_ardal_bader', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_user_2 = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Sam', 'Adam', 'test_sam_adam@mail.com', 'test_sam_adam', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_course = "INSERT INTO Course (title, year, session, department, course_code, capacity, ccount) VALUES ('Test Course', 2022, 'Winter', 'TEST', 544, 1, 0);"
    insert_user_admin = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Admin', 'Steve', 'test_admin@mail.com', 'test_admin_steve', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'admin', X'0307394446525c60a7fa422fadcf6267');"

    test_user_pk_1 = connector.insert(insert_user_1)
    test_user_pk_2 = connector.insert(insert_user_2)
    test_course = connector.insert(insert_course)
    test_admin = connector.insert(insert_user_admin)

    admin_token = Token.check_for_token(connector, test_admin)

    return test_user_pk_1, test_user_pk_2, test_course, admin_token

@pytest.fixture(scope="session", autouse=True)
def setup_session():
    """
    Runs before and after all tests. Ensures nothing test
    is left in the database
    """
    __delete_all_test_inserts()

    app.config["TESTING"] = True
    with app.test_client() as test_client:
        with app.app_context():
            yield test_client

    __delete_all_test_inserts()

@pytest.fixture(scope="function", autouse=True)
def setup_functions():
    """
    Here we clean the DB so that we can perform our tests without worrying about what state
    the DB is in. Then we cleanup to leave it the way we found it. The only data we assume
    to be present in the database and unaltered are the data in test.

    All example data we will test with has the prefix test_ in the username and test. in the
    email. DO NOT USE THESE PREFIXES IN NORMAL WORK!
    """
    __delete_all_test_inserts()

    user1, user2, course, admin = __insert_test_variables()
    yield user1, user2, course, admin

    __delete_all_test_inserts()

def test_normal_enrollment_from_admin_key(setup_session, setup_functions):
    """
    Test that with a course that is free that the course
    is enrolled normal. From admin key
    """
    client = setup_session
    u1, t, course, admin_key = setup_functions

    response = client.post("/student/enroll", json={"student_id" : u1, "course_id": course, "token": admin_key})

    query = "SELECT * FROM Enrollment WHERE sid = %s"
    params = (u1,)

    u1_enrollments = connector.query_json(query, params)

    assert response.status_code == 200
    assert response.json["placement"] == "enrolled"
    assert len(u1_enrollments) > 0
    assert u1_enrollments[0].get("sid") == u1
    assert u1_enrollments[0].get("cid") == course

def test_normal_enrollment_from_student_key(setup_session, setup_functions):
    """
    Test that with a course that is free that the course
    is enrolled normal
    """
    client = setup_session
    u1, t, course, t = setup_functions

    student_token = Token.check_for_token(connector, u1)

    response = client.post("/student/enroll", json={"course_id": course, "token": student_token})

    query = "SELECT * FROM Enrollment WHERE sid = %s"
    params = (u1,)

    u1_enrollments = connector.query_json(query, params)

    assert response.status_code == 200
    assert response.json["placement"] == "enrolled"
    assert len(u1_enrollments) > 0
    assert u1_enrollments[0].get("sid") == u1
    assert u1_enrollments[0].get("cid") == course

def test_waitlist_enrollment(setup_session, setup_functions):
    """
    Test that with a course that is full, the student is placed on the waitlist
    """
    client = setup_session
    u1, u2, course, admin_key = setup_functions

    # Enroll the first student to fill the course
    response = client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_key})
    assert response.status_code == 200
    assert response.json["placement"] == "enrolled"

    # Enroll the second student who should be placed on the waitlist
    response = client.post("/student/enroll", json={"student_id": u2, "course_id": course, "token": admin_key})
    assert response.status_code == 200
    assert response.json["placement"] == "waitlisted"

def test_drop_enrollment_from_admin_key(setup_session, setup_functions):
    """
    Test that a student can drop a course they are enrolled in
    """
    client = setup_session
    u1, t, course, admin_token = setup_functions

    # Enroll the first student
    response = client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["placement"] == "enrolled"

    # Drop the course
    response = client.post("/student/drop", json={"student_id": u1, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["msg"] == "Student deleted off enrollment"

def test_drop_enrollment_from_admin_key(setup_session, setup_functions):
    """
    Test that a student can drop a course they are enrolled in
    """
    client = setup_session
    u1, t, course, admin_token = setup_functions

    student_token = Token.check_for_token(connector, u1)

    # Enroll the first student
    response = client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["placement"] == "enrolled"

    # Drop the course
    response = client.post("/student/drop", json={"course_id": course, "token": student_token})
    assert response.status_code == 200
    assert response.json["msg"] == "Student deleted off enrollment"

def test_drop_waitlist(setup_session, setup_functions):
    """
    Test that a student can drop a course they are waitlisted in
    """
    client = setup_session
    u1, u2, course, admin_token = setup_functions
    # Enroll the first student to fill the course
    response = client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["placement"] == "enrolled"
    # Enroll the second student who should be placed on the waitlist
    response = client.post("/student/enroll", json={"student_id": u2, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["placement"] == "waitlisted"

    # Drop the course from waitlist
    response = client.post("/student/drop", json={"student_id": u2, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["msg"] == "Student deleted off waitlist"

def test_drop_cascade(setup_session, setup_functions):
    """
    Test that if a student drops a course and there are students
    on the waitlist that that student gets automatically enrolled
    """
    client = setup_session
    u1, u2, course, admin_token = setup_functions

    # Enroll the first student to fill the course
    response = client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["placement"] == "enrolled"

    # Enroll the second student who should be placed on the waitlist
    response = client.post("/student/enroll", json={"student_id": u2, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["placement"] == "waitlisted"

    # Drop the course for the first student
    response = client.post("/student/drop", json={"student_id": u1, "course_id": course, "token": admin_token})
    assert response.status_code == 200
    assert response.json["msg"] == "Student deleted off enrollment and waitlist updated"

    # Check if the second student is now enrolled
    query_stmt = "SELECT * FROM Enrollment WHERE sid=%s AND cid=%s"
    query_res = connector.query_json(query_stmt, (u2, course))

    assert len(query_res) == 1



def test_get_student_info_missing_token(setup_session):
    """
    Test retrieving student information with missing token
    """
    client = setup_session

    response = client.get("/student/info", json={})
    assert response.status_code == 400
    assert response.json["err"] == "Unauthorized. No token"

def test_get_student_info_not_found(setup_session, setup_functions):
    """
    Test retrieving student information for a non-existent student
    """
    client = setup_session
    t, t, t, admin_token = setup_functions

    body = {
        'token' : admin_token
    }

    response = client.get("/student/info?student_id=-1", json = body)
    assert response.status_code == 400
    assert response.json["err"] == "Student not found"

def test_get_student_info_with_enrollments(setup_session, setup_functions):
    """
    Test retrieving student information with enrollments
    """
    client = setup_session
    u1, t, course, admin_token = setup_functions

    # Enroll the student in the course
    client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})

    body = {
        'token' : admin_token
    }

    response = client.get(f"/student/info?student_id={u1}", json=body)
    assert response.status_code == 200
    assert len(response.json["enrollments"]) == 1
    assert response.json["enrollments"][0]["cid"] == course

def test_get_student_info_with_enrollments_from_student_token(setup_session, setup_functions):
    """
    Test retrieving student information with enrollments
    """
    client = setup_session
    u1, t, course, admin_token = setup_functions

    # Enroll the student in the course
    client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})

    body = {
        'token' : Token.check_for_token(connector, u1)
    }

    response = client.get(f"/student/info", json=body)
    assert response.status_code == 200
    assert len(response.json["enrollments"]) == 1
    assert response.json["enrollments"][0]["cid"] == course

def test_student_info_returns_only_current_enrollments(setup_session, setup_functions):
    """
    Test that if a student was enrolled in a course the
    previous year, only the current enrollments appear in
    the enrollment attribute
    """

    client = setup_session
    u1, u2, course, admin_token = setup_functions

    # Enroll the student in the course
    client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})

    # Change the course to a different year
    update_course = "UPDATE Course SET Course.year = 2020 WHERE Course.cid = %s"

    connector.update(update_course, (course ,))

    body = {
        'token': admin_token
    }

    response = client.get(f"/student/info?student_id={u1}", json=body)
    assert response.status_code == 200
    assert len(response.json["enrollments"]) == 0

def test_get_student_info_with_waitlist(setup_session, setup_functions):
    """
    Test retrieving student information with waitlist
    """
    client = setup_session
    u1, u2, course, admin_token = setup_functions

    # Enroll the first student to fill the course
    client.post("/student/enroll", json={"student_id": u1, "course_id": course, "token": admin_token})
    # Enroll the second student who should be placed on the waitlist
    client.post("/student/enroll", json={"student_id": u2, "course_id": course, "token": admin_token})

    body = {
        'token' : admin_token
    }

    response = client.get(f"/student/info?student_id={u2}", json = body)
    assert response.status_code == 200
    assert len(response.json["waitlist"]) == 1
    assert response.json["waitlist"][0]["cid"] == course

def test_get_student_with_bad_token(setup_session):
    """
    Test that if we try to use the endpoint with a bad token
    we get a error.
    """

    client = setup_session

    body = {
        "token" : "If this was randomly a token, I would would be surpised!"
    }

    response = client.get(f"/student/info", json = body)
    assert response.status_code == 400
    assert response.json["err"] == "Invaild Token"

def test_previous_graded_get_return(setup_session, setup_functions):
    """
    Test that if we enroll a student in a course, we
    get that infomation comes back
    """

    client = setup_session
    u1, u2, course, admin_token = setup_functions

    insert_course = "INSERT INTO Course (title, year, session, department, course_code, capacity, ccount) VALUES ('Graded', 2022, 'Winter', 'TEST', 543, 1, 0);"

    cid = connector.insert(insert_course)

    insert_grade = "INSERT INTO Grade (cid, sid, grade) VALUES (%s, %s, 30);"

    connector.insert(insert_grade, (cid, u1))

    body = {
        "token": admin_token
    }

    response = client.get(f"/student/info?student_id={u1}", json=body)



    assert len(response.json["previous_enrollments"]) == 1
    assert response.json["previous_enrollments"][0]["title"] == 'Graded'



def test_update_student(setup_session, setup_functions):
    """
    Test updating student
    """

    client = setup_session
    u1, u2, course, admin_tok = setup_functions

    data = {
        "fname" : "sam",
        "token" : admin_tok
    }

    response = client.post(f"/student/update?student_id={u1}", json=data)

    assert response.status_code == 200
    assert response.json == {'success':True}

    query = connector.query_json("SELECT fname FROM UserLogin WHERE id = %s", (u1,))

    assert query[0]["fname"] == "sam"

def test_duplicate_email(setup_session, setup_functions):
    """
    Test updating student with dupcliate email
    """

    client = setup_session
    u1, u2, course, admin_token = setup_functions

    data = {
        "email" : "test_sam_adam@mail.com",
        "token" : admin_token
    }

    response = client.post(f"/student/update?student_id={u1}", json=data)

    assert response.status_code == 400
    assert response.json == {"err": "Email already exists"}

def test_duplicate_username(setup_session, setup_functions):
    """
    Test updating student with dupcliate email
    """

    client = setup_session
    u1, u2, course, admin_token = setup_functions

    data = {
        "username" : "test_sam_adam",
        "token": admin_token
    }

    response = client.post(f"/student/update?student_id={u1}", json=data)

    assert response.status_code == 400
    assert response.json == {"err": "Username already exists"}
