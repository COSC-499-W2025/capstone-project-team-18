"""
This file will test the following endpoints:
    - student/generate-report
"""
import pytest
from Classes.database_connector import DatabaseConnector # pylint: disable=import-error
from app import app # pylint: disable=import-error
from Util.make_token import Token
from blueprints.admin_endpoints import update_student_gpa

connector = DatabaseConnector()

def __delete_all_test_inserts():
    """
    Delete everything test from the database. Cascade will take care of
    the enrollments and grades
    """
    delete_userlogin_stmt = "DELETE FROM UserLogin WHERE username LIKE 'test_%'"
    delete_course_stmt = "DELETE FROM Course WHERE department = 'TEST'"

    connector.delete([delete_userlogin_stmt, delete_course_stmt])

def __insert_test_variables() -> tuple:
    """
    Here we generate the test data that we will then
    use to validate the endpoint. This insert adds
    the following data:

    - Student "Sam Adam."
    - Proffesor "Apple Tree"
    - One Summer 2020 course.
    - One Fall 2021 course.
    - One Winter 2021 course.
    - One Winter 2022 course.

    - Enrolls Sam Adam in the courses and puts Proffesor apple tree
      as the proffessor.

    Gives Sam Adam the following grades:
        - 62 percent for Summer 2020 course
        - 94 percent for Fall 2021 course
        - 81 percent for Winter 2021 course
        - No grade for the Winter 2022 course.
    """

    insert_user = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Sam', 'Adam', 'test_sam_adam@mail.com', 'test_sam_adam', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_prof = "INSERT INTO Instructor (fname, lname, department) VALUES ('Apple', 'Tree', 'COSC');"

    user_pk = connector.insert(insert_user)
    prof_pk = connector.insert(insert_prof)

    # Keep adding courses and fix return stuff
    insert_course = "INSERT INTO Course (title, year, session, department, course_code, instructor_id, capacity, ccount) VALUES (%s, %s, %s, %s, %s, %s, 1, 0);"

    course_sqls = [
        insert_course,
        insert_course,
        insert_course,
        insert_course
    ]

    params = [
        ('Summer 2020', 2020, 'Summer', 'TEST', 123, prof_pk),
        ('Fall 2021', 2021, 'Fall', 'TEST', 456, prof_pk),
        ('Winter 2021', 2021, 'Winter', 'TEST', 789, prof_pk),
        ('Winter 2022', 2022, 'Winter', 'TEST', 206, prof_pk)
    ]

    insert_course = connector.insert(course_sqls, params)

    courseSum2020, courseFall2021, courseWinter2021, courseWinter2022 = insert_course
    grades = [62, 94, 81]

    insert_enrollment = "INSERT INTO Enrollment (sid, cid) VALUES (%s, %s);"
    for i in range(0,4):
        connector.insert(insert_enrollment, (user_pk, insert_course[i]))

    insert_grade = "INSERT INTO Grade (sid, cid, grade) VALUES (%s, %s, %s);"
    for i in range (0,3):
        connector.insert(insert_grade, (user_pk, insert_course[i], grades[i]))

    update_student_gpa(connector, user_pk)

    return Token.check_for_token(connector, user_pk)

@pytest.fixture(scope="session", autouse=True)
def setup_session():
    """
    Runs before and after all tests. Ensures nothing test
    is left in the database
    """
    __delete_all_test_inserts()

    app.config["TESTING"] = True
    with app.test_client() as test_client:
        with app.app_context():
            yield test_client

    __delete_all_test_inserts()

@pytest.fixture(scope="function", autouse=True)
def setup_functions():
    """
    Here we clean the DB so that we can perform our tests without worrying about what state
    the DB is in. Then we cleanup to leave it the way we found it. The only data we assume
    to be present in the database and unaltered are the data in test.

    All example data we will test with has the prefix test_ in the username and test. in the
    email. DO NOT USE THESE PREFIXES IN NORMAL WORK!
    """
    __delete_all_test_inserts()

    user = __insert_test_variables()
    yield user

    __delete_all_test_inserts()

def test_generate_student_report_json(setup_session, setup_functions):
    """
    Test the /transcript/generateReport endpoint for JSON response using the real database.
    """
    test_client = setup_session
    user_token = setup_functions

    # Make the request
    response = test_client.get(
        '/transcript/generateReport',
        json= {
            "token": user_token,
            "file_type": "JSON"
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()

    # Validate the student info
    assert response_data["fname"] == "Sam"
    assert response_data["lname"] == "Adam"
    assert response_data["email"] == "test_sam_adam@mail.com"
    assert response_data["phone"] == "000-000-0000"
    assert response_data["gpa"] == '79.00'
    assert response_data["ranking"] == 2
    assert response_data["address"] == "Street 1000"

    # Validate the transcript
    assert len(response_data["transcript"]) == 4
    assert response_data["transcript"][0]["title"] == "Winter 2022"
    assert response_data["transcript"][0]["grade"] == "Pending"
    assert response_data["transcript"][1]["title"] == "Winter 2021"
    assert response_data["transcript"][1]["grade"] == "81.00"
    assert response_data["transcript"][2]["title"] == "Fall 2021"
    assert response_data["transcript"][2]["grade"] == "94.00"
    assert response_data["transcript"][3]["title"] == "Summer 2020"
    assert response_data["transcript"][3]["grade"] == "62.00"


def test_generate_student_report_txt(setup_session, setup_functions):
    """
    Test the /transcript/generateReport endpoint for TXT response using the real database.
    """
    test_client = setup_session
    tok = setup_functions

    # Make the request
    response = test_client.get(
        '/transcript/generateReport',
        json={"token": tok, "file_type": "TXT"}
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.data.decode('utf-8')

    # Validate the student info in the TXT response
    assert "fname: Sam" in response_data
    assert "lname: Adam" in response_data
    assert "email: test_sam_adam@mail.com" in response_data
    assert "phone: 000-000-0000" in response_data
    assert "address: Street 1000" in response_data

    # Validate the transcript in the TXT response
    assert "title: Winter 2022" in response_data
    assert "grade: Pending" in response_data
    assert "title: Winter 2021" in response_data
    assert "grade: 81" in response_data
    assert "title: Fall 2021" in response_data
    assert "grade: 94" in response_data
    assert "title: Summer 2020" in response_data
    assert "grade: 62" in response_data

def test_upload_transcript_success(setup_session, setup_functions):
    """
    Test the /uploadTranscript endpoint for a successful transcript upload.
    """
    test_client = setup_session
    tok = setup_functions

    # Retrieve the student ID using the token
    student_id_query = "SELECT id FROM UserLogin WHERE token = %s;"
    student_id = connector.query(student_id_query, (tok,))[0][0]

    if not student_id:
        pytest.fail("Failed to retrieve student ID using the token.")

    # Prepare the request body
    body = {
        "token": tok,
        "file_type": "JSON",
        "student_id": student_id,
        "transcript_data": {
            "fname": "John",
            "lname": "Adam",
            "email": "test_sam_adam@mail.com",
            "phone": "000-000-0000",
            "address": "Street 1000",
            "transcript": [
                {
                    "grade": "Pending",
                    "letter_grade": "Pending",
                    "title": "Winter 2022",
                    "year": 2022,
                    "session": "Winter",
                    "department": "TEST",
                    "course_code": "206",
                    "instructor_fname": "Apple",
                    "instructor_lname": "Tree"
                },
                {
                    "grade": "81.0",
                    "letter_grade": "A-",
                    "title": "Winter 2021",
                    "year": 2021,
                    "session": "Winter",
                    "department": "TEST",
                    "course_code": "789",
                    "instructor_fname": "Apple",
                    "instructor_lname": "Tree"
                }
            ]
        }
    }

    # Make the POST request
    response = test_client.post(
        '/transcript/uploadTranscript',
        json=body
    )

    # Assert the response
    response_data = response.get_json()
    assert response_data.get('err') is None
    assert response.status_code == 200
    assert response_data["success"] is True
    assert response_data["message"] == "Transcript uploaded successfully."


    query_select = "SELECT COUNT(*) FROM Grade JOIN UserLogin WHERE sid = id AND token = %s"
    grade_count = connector.query(query_select, (tok,))[0][0]

    query_select = "SELECT fname FROM UserLogin WHERE token = %s"
    fname = connector.query(query_select, (tok,))[0][0]

    assert grade_count == 1

def test_upload_transcript_missing_fields(setup_session, setup_functions):
    """
    Test the /uploadTranscript endpoint for missing required fields.
    """
    test_client = setup_session
    tok = setup_functions

    # Prepare the request body with missing fields
    body = {
        "token": tok,
        "file_type": "JSON",
        # Missing student_id and transcript_data
    }

    # Make the POST request
    response = test_client.post(
        '/transcript/uploadTranscript',
        json=body
    )

    # Assert the response
    assert response.status_code == 400
    response_data = response.get_json()
    assert response_data["err"] == "Missing required fields: student_id, file_type, or transcript_data"


def test_upload_transcript_invalid_format(setup_session, setup_functions):
    """
    Test the /uploadTranscript endpoint for an invalid file format.
    """
    test_client = setup_session
    tok = setup_functions

    # Prepare the request body with an invalid file type
    body = {
        "token": tok,
        "student_id": 1,
        "transcript_data": {}
    }

    # Make the POST request
    response = test_client.post(
        '/transcript/uploadTranscript',
        json=body
    )

    # Assert the response
    assert response.status_code == 400
    response_data = response.get_json()
    assert response_data["err"] == 'Missing required fields: student_id, file_type, or transcript_data'
