'''
This file tests that the server's /login endpoint properly
returns a response based on a user's input

HOW TO RUN TESTS:
1. cd into /server/src/
2. run `pytest tests/integration/test_login.py`
'''
from app import app  # pylint: disable=import-error
import pytest
from Classes.database_connector import DatabaseConnector

db = DatabaseConnector()

def __delete_all_test_inserts():
    """
    Delete everything test from the database
    """
    delete_userlogin_stmt = "DELETE FROM UserLogin WHERE username LIKE 'test_%'"
    delete_course_stmt = "DELETE FROM Course WHERE department = 'TEST'"

    db.delete([delete_userlogin_stmt, delete_course_stmt])

def __insert_test_variables() -> tuple:
    """
    Insert two UserLogins and one course. Will be deleted with __delete_all_test_inserts
    """
    insert_user_1 = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Ardal', 'Bader', 'test_ardal_bader99@mail.com', 'test_ardal_bader', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_user_2 = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Sam', 'Adam', 'test_sam_adam@mail.com', 'test_sam_adam', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_course = "INSERT INTO Course (title, year, session, department, course_code, capacity, ccount) VALUES ('Test Course', 2022, 'Winter', 'TEST', 544, 1, 0);"

    test_user_pk_1 = db.insert(insert_user_1)
    test_user_pk_2 = db.insert(insert_user_2)
    test_course = db.insert(insert_course)

    return test_user_pk_1, test_user_pk_2, test_course

@pytest.fixture(scope="session", autouse=True)
def setup_session():
    """
    Runs before and after all tests. Ensures nothing test
    is left in the database
    """
    __delete_all_test_inserts()

    app.config["TESTING"] = True
    with app.test_client() as test_client:
        yield test_client

    __delete_all_test_inserts()

@pytest.fixture(scope="function", autouse=True)
def setup_functions():
    """
    Here we clean the DB so that we can perform our tests without worrying about what state
    the DB is in. Then we cleanup to leave it the way we found it. The only data we assume
    to be present in the database and unaltered are the data in test.

    All example data we will test with has the prefix test_ in the username and test. in the
    email. DO NOT USE THESE PREFIXES IN NORMAL WORK!
    """
    __delete_all_test_inserts()

    user1, user2, course = __insert_test_variables()
    yield user1, user2, course

    __delete_all_test_inserts()


def test_login_success(setup_session):
    '''
    Test that a 200 status code is returned when a request
    is made with valid credentials.
    '''
    client = setup_session
    t= setup_functions
    response = client.post("/auth/login", json={'username': 'johndoe', 'pswd': '!hashmeplease!'})
    assert response.status_code == 200

def test_login_failure(setup_session):
    '''
    Test that a 401 status code is returned when a request
    is made with invalid credentials.
    '''
    client = setup_session
    t= setup_functions
    response = client.post('/auth/login', json={'username': 'invaliduser', 'pswd' : 'invalidpswd'})
    assert response.status_code == 401

def test_missing_username(setup_session, setup_functions):
    '''
    Test that a 400 status code is returned when a request
    is missing the username
    '''
    client = setup_session
    t= setup_functions
    response = client.post('/auth/login', json={'username': '', 'pswd' : 'irrelevant'}) # test for missing username
    
    info = response.get_json()
    assert response.status_code == 400
    assert info['bad request'] == 'missing username'

def test_missing_pswd(setup_session, setup_functions):
    '''
    Test that a 400 status code is returned when a request
    is missing the password
    '''
    client = setup_session
    t= setup_functions
    response = client.post('/auth/login', json={'username': 'irrelevant', 'pswd' : ''}) # test for missing pswd

    info = response.get_json()
    assert response.status_code == 400
    assert info['bad request'] == 'missing pswd'
