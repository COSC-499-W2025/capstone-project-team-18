"""
Here we test query endpoints. These tests require the MySQL container to be running!
"""
import pytest
from app import app # pylint: disable=import-error

@pytest.fixture
def client():
    """
    Create a test client for Flask.
    """
    app.config["TESTING"] = True
    with app.test_client() as test_client:
        yield test_client

def test_get_course_by_parameters_valid(client):
    """
    Test getting a course by valid parameters.
    """

    params = {
        'department': 'COSC',
        'course_code': '101',
        'year': 2022,
        'session': 'Winter'
    }

    response = client.post('/course/search', json=params)

    assert response.status_code == 200
    for course in response.get_json():
        for key, value in params.items():
            assert course[key] == value

def test_get_course_by_parameters_invalid(client):
    """
    Test getting a course by invalid parameters.
    """

    params = {
        'department': 'INVALID',
        'course_code': '999',
        'year': 2022,
        'session': 'Winter'
    }
    response = client.post('/course/search', json=params)

    assert response.status_code == 200
    assert response.get_json() == []

def test_get_course_by_parameters_missing_params(client):
    """
    Test getting a course with merely one parameter.
    """
    params = {
        'department': 'COSC'
    }
    response = client.post('/course/search', json=params)

    assert response.status_code == 200
    for course in response.get_json():
        for key, value in params.items():
            assert course[key] == value

def test_get_course_by_parameters_empty_params(client):
    """
    Test getting a course with empty parameters. This should
    return every single course
    """
    params = {}
    response = client.post('/course/search', json=params)

    assert response.status_code == 200
    assert len(response.get_json()) > 0

def test_get_course_is_current_enrollment(client):
    """
    Test that when we get courses it is only the current
    year and enrollment
    """

    params = {
        'year' : 2022,
        'session' : "Winter"
    }
    response = client.post('/course/search', json=params)

    assert response.status_code == 200
    for course in response.get_json():
        assert course['year'] == 2022
        assert course['session'] == "Winter"


def test_get_course_by_wildcard_code(client):
    """
    This function tests getting all year 1 courses with the wildcard
    opreator *
    """

    params = {
        "course_code" : "1*"
    }

    response = client.post('/course/search', json=params)

    assert response.status_code == 200
    for course in response.get_json():
        assert (int(course["course_code"]) // 100) == 1
