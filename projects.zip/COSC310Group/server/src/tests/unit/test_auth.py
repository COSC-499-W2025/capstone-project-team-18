"""
This file defines unit tests for the Authentication class.
"""

import pytest
from Classes.auth import Authentication # pylint: disable=import-error

def test_hash_with_custom_salt():
    """
    This test ensures with a password and salt importe
    """

    my_password = "password123!&63".encode()
    my_salt = b'\x8a\x1d\x8et\xfb\xca\xe9\xf0}\xb7\x1d@\x10\xfb;\xd7'

    salt, hashed_password = Authentication.hash(my_password, my_salt)

    assert my_salt == salt, "Salt from function is different as salt parameter"
    assert hashed_password != my_password, \
        "Hashed password should not be the same as the original password"

def test_hash():
    """
    This test ensures we get a salt back of length 16 and hashed password is non empty
    """

    password = "5923589348-234dhafjhfbv"
    salt, hashed_password = Authentication.hash(password)

    assert len(salt) == 16, "Salt generated is not of length 16"
    assert len(hashed_password) > 0, "Hashed password is empty"
    assert hashed_password != password.encode(), "Hashed password is same as password"

def test_hash_with_invalid_salt_length():
    """
    Tests that with invaild salt length, an exeception is thrown by hash function
    """
    password = "Hello, World!"
    invalid_salt = b'\x96'

    with pytest.raises(ValueError):
        Authentication.hash(password, invalid_salt)

def test_password_matches_hash():
    """
    Verifies that the password_matches_hash method correctly
    identifies whether a given password matches the hashed password when
    provided with the correct salt and password.
    """
    password = "!hashmeplease!"
    salt, hashed_password = Authentication.hash(password)

    assert Authentication.password_matches_hash(hashed_password, password, salt) is True
    assert Authentication.password_matches_hash(hashed_password, "wrongpassword", salt) is False
