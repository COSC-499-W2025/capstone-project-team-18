'''
This file is used to test the /admin/getStudentByParameters endpoint
We test the following cases:
    - test_full_query: All criteria is provided
    - test_for_multiple_responses: Multiple students match criteria
    - test_only_min_gpa: Only the minimum gpa is provided
    - test_only_max_gpa: Only the maximum gpa is provided
    - test_only_gpa: Both the min and max gpa are given, but nothing else
    - test_only_name: Only the student's name is provided
    - test_only_course: Only the course's name is provided



'''
import pytest
from Classes.database_connector import DatabaseConnector # pylint: disable=import-error
from app import app # pylint: disable=import-error
from Util.make_token import Token

connector = DatabaseConnector()

def __delete_all_test_inserts():
    """
    Delete everything test from the database. Cascade will take care of
    the enrollments and grades
    """
    delete_userlogin_stmt = "DELETE FROM UserLogin WHERE username LIKE 'test_%'"
    delete_course_stmt = "DELETE FROM Course WHERE department = 'TEST'"

    connector.delete([delete_userlogin_stmt, delete_course_stmt])

def __insert_test_variables() -> tuple:
    """
    Here we generate the test data that we will then
    use to validate the endpoint. This insert adds
    the following data:

    - **Student** "Sam Adam": Enrolled in 4 courses with 45 GPA
    - **Student** "Joe Appletree": Enrolled in 4 courses with 80 GPA
    - **Student** "William Boarplaugh": Enrolled in 4 courses with 15 GPA
    - **Admin** "Peter Parker" (password is 'admin')
    - **Professor** "Apple Tree"

    - One Summer 2020 course.
    - One Fall 2021 course.
    - One Winter 2021 course.
    - One Winter 2022 course.

    - Enrolls Sam Adam, Joe Appletree, and William Boarplaugh in the courses and puts Professor Apple Tree
      as the professor.

    - Gives student Sam Adam a grade of 45 in all 4 enrolled classes
    - Gives student Joe Appletree a grade of 80 in all 4 enrolled classes
    - Gives student William Boarplaugh a grade of 15 in all 4 enrolled classes
    """

    insert_user = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Sam', 'Adam', 'test_sam_adam@mail.com', 'test_sam_adam', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_user_2 = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Joe', 'Appletree', 'test_joe_apptree@mail.com', 'test_joe_appletree', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_user_3 = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('William', 'Boarplaugh', 'test_william_boarplaugh@mail.com', 'test_william_boarplaugh', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"

    insert_admin = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Peter', 'Parker', 'test_peter_parker@mail.com', 'test_peter_parker', X'931d7e72465855f7bd8c1751856ae96a05eb1ec7c38a802522a9320e508371c9', '000-000-0000', 'Street 1000', 'admin', X'19166828d7059a009e224e2efcea66ed');"
    insert_prof = "INSERT INTO Instructor (fname, lname, department) VALUES ('Apple', 'Tree', 'COSC');"

    # create temp student rows in UserLogin
    user_pk = connector.insert(insert_user)
    user_pk_two = connector.insert(insert_user_2)
    user_pk_three = connector.insert(insert_user_3)
    # create temp admin row in UserLogin
    admin_pk = connector.insert(insert_admin)

    # create temp row in Instructor
    prof_pk = connector.insert(insert_prof)

    # Keep adding courses and fix return stuff
    insert_course = "INSERT INTO Course (title, year, session, department, course_code, instructor_id, capacity, ccount) VALUES (%s, %s, %s, %s, %s, %s, 1, 0);"

    course_sqls = [
        insert_course,
        insert_course,
        insert_course,
        insert_course
    ]

    params = [
        ('Summer 2020', 2020, 'Summer', 'TEST', 123, prof_pk),
        ('Fall 2021', 2021, 'Fall', 'TEST', 456, prof_pk),
        ('Winter 2021', 2021, 'Winter', 'TEST', 789, prof_pk),
        ('Winter 2022', 2022, 'Winter', 'TEST', 206, prof_pk)
    ]

    insert_course = connector.insert(course_sqls, params)

    grades = 45
    grades_2 = 80
    grades_3 = 15

    insert_enrollment = "INSERT INTO Enrollment (sid, cid) VALUES (%s, %s);"
    for i in range(0,4):
        connector.insert(insert_enrollment, (user_pk, insert_course[i]))
        connector.insert(insert_enrollment, (user_pk_two, insert_course[i]))
        connector.insert(insert_enrollment, (user_pk_three, insert_course[i]))

    insert_grade = "INSERT INTO Grade (sid, cid, grade) VALUES (%s, %s, %s);"
    for i in range (0,3):
        connector.insert(insert_grade, (user_pk, insert_course[i], grades)) # insert Sam Adam's grades
        connector.insert(insert_grade, (user_pk_two, insert_course[i], grades_2)) # insert Joe Appletree's
        connector.insert(insert_grade, (user_pk_three, insert_course[i], grades_3)) # insert William's

    # update student gpa cols in UserLogin with their GPA
    update_gpa_stmt = 'UPDATE UserLogin SET gpa = (SELECT AVG(grade) AS gpa FROM Grade WHERE sid = %s) WHERE id = %s'
    for i in range(0,3):
        connector.update(update_gpa_stmt, (user_pk, user_pk))
        connector.update(update_gpa_stmt, (user_pk_two, user_pk_two))
        connector.update(update_gpa_stmt, (user_pk_three, user_pk_three))

    admin_token = Token.check_for_token(connector, admin_pk) # admin Peter Parker's token
    course_pk = insert_course[0] # course id of Summer 2020 course
    return [admin_token, course_pk, user_pk, user_pk_two, user_pk_three] # admin Peter Parker's token, course TEST 123's id, user Sam Adam's id

@pytest.fixture(scope="session", autouse=True)
def setup_session():
    """
    Runs before and after all tests. Ensures nothing test
    is left in the database
    """
    __delete_all_test_inserts()

    app.config["TESTING"] = True
    with app.test_client() as test_client:
        with app.app_context():
            yield test_client

    __delete_all_test_inserts()

@pytest.fixture(scope="function", autouse=True)
def setup_functions():
    """
    Here we clean the DB so that we can perform our tests without worrying about what state
    the DB is in. Then we cleanup to leave it the way we found it. The only data we assume
    to be present in the database and unaltered are the data in test.

    All example data we will test with has the prefix test_ in the username and test. in the
    email. DO NOT USE THESE PREFIXES IN NORMAL WORK!
    """
    __delete_all_test_inserts()

    user = __insert_test_variables()
    yield user

    __delete_all_test_inserts()

def test_full_query(setup_session, setup_functions):
    """
    Test the /admin/getStudentByParameters endpoint for JSON response using the real database.
    Here, we are testing a case where an admin gives us all filter criteria.

    Criteria (expects):
        - min_gpa = 10
        - max_gpa = 90
        - course_pk = Summer 2020 course's ID
        - name = Sam Adam

    Returns:
        - All 3 students
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0]
    course_id = info[1]
    sam_adam_id = info[2]

    # Make the request
    response = test_client.post(
        '/admin/getStudentByParameters',
        json= {
            "token": admin_token,
            "gpa_min" : '10',
            "gpa_max" : '90',
            "name" : 'Sam Adam',
            "course_pk" : course_id
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()

    assert response_data[0]['id'] == sam_adam_id

def test_for_multiple_responses(setup_session, setup_functions):
    """
    Here, we are testing a case where an admin gives us all filter criteria AND that
    if more than one student matches the criteria, all matching students are returned.

    Criteria (expects):
        - min_gpa = 10
        - max_gpa = 90
        - course_pk = Summer 2020 course's ID

    Returns:
        - Sam Adam's id from UserLogin
        - Joe Appletree's id from UserLogin
        - William Boarplaugh's id from UserLogin
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0]
    course_id = info[1]
    sam_adam_id = info[2]
    joe_appletree_id = info[3]
    william_boarplaugh_id = info[4]


    # Make the request
    response = test_client.post(
        '/admin/getStudentByParameters',
        json= {
            "token": admin_token,
            "gpa_min" : '10',
            "gpa_max" : '90',
            "course_pk" : course_id
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()

    assert response_data[0]['id'] == sam_adam_id
    assert response_data[1]['id'] == joe_appletree_id
    assert response_data[2]['id'] == william_boarplaugh_id


def test_only_min_gpa(setup_session, setup_functions):
    """
    Here, we are testing a case where an admin only provides
    a minimum gpa criteria.

    Criteria (expects):
        - min_gpa = 40

    Returns:
        - Sam Adam's id from UserLogin
        - Joe Appletree's id from UserLogin


    Does not return William Boarplaugh's id because
    their GPA is less than 40
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0]
    sam_adam_id = info[2]
    joe_appletree_id = info[3]
    william_boarplaugh_id = info[4]


    # Make the request
    response = test_client.post(
        '/admin/getStudentByParameters',
        json= {
            "token": admin_token,
            "gpa_min" : '40',
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()

    assert any(student['id'] == sam_adam_id or joe_appletree_id or not william_boarplaugh_id for student in response_data)


def test_only_max_gpa(setup_session, setup_functions):
    """
    Here, we are testing a case where an admin only provides
    a maximum gpa criteria.

    Criteria (expects):
        - max_gpa = 40

    Returns:
        - William Boarplaugh id from UserLogin

    Does not return Sam or John's id because
    their GPA is greater than 40
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0]
    sam_adam_id = info[2]
    joe_appletree_id = info[3]
    william_boarplaugh_id = info[4]


    # Make the request
    response = test_client.post(
        '/admin/getStudentByParameters',
        json= {
            "token": admin_token,
            "gpa_max" : '40',
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()
    assert any(student['id'] != sam_adam_id or joe_appletree_id for student in response_data)
    assert any(student['id'] == william_boarplaugh_id for student in response_data)

def test_only_gpa(setup_session, setup_functions):
    """
    Here, we are testing a case where an admin provides
    a min and max gpa criteria.

    Criteria (expects):
        - min_gpa = 40
        - max_gpa = 70

    Returns:
        - Sam Adam id from UserLogin

    Does not return Sam or John's id because
    their GPA is greater than 40
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0]
    sam_adam_id = info[2]

    # Make the request
    response = test_client.post(
        '/admin/getStudentByParameters',
        json= {
            "token": admin_token,
            "gpa_min" : '40',
            "gpa_max" : '70'
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()
    assert response_data[0]['id'] == sam_adam_id

def test_only_name(setup_session, setup_functions):
    """
    Here, we are testing a case where an admin gives us
    only a student's name

    Criteria (expects):
        - name = Sam Adam

    Returns:
        - Sam Adam's id
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0]
    course_id = info[1]
    sam_adam_id = info[2]

    # Make the request
    response = test_client.post(
        '/admin/getStudentByParameters',
        json= {
            "token": admin_token,
            "name" : 'Sam Adam'
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()

    assert response_data[0]['id'] == sam_adam_id

def test_only_course(setup_session, setup_functions):
    """
    Here, we are testing a case where an admin gives us
    only a course's name

    Criteria (expects):
        - course_pk = Summer 2020 course's ID

    Returns:
        - All 3 students
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0]
    course_id = info[1]
    sam_adam_id = info[2]
    joe_appletree_id = info[3]
    william_boarplaugh_id = info[4]

    # Make the request
    response = test_client.post(
        '/admin/getStudentByParameters',
        json= {
            "token": admin_token,
            "course_pk" : course_id
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()

    assert response_data[0]['id'] == sam_adam_id
    assert response_data[1]['id'] == joe_appletree_id
    assert response_data[2]['id'] == william_boarplaugh_id
