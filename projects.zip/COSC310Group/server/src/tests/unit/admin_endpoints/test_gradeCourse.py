'''
This file is used to test the /admin/gradeCourse endpoint
'''
import pytest
from Classes.database_connector import DatabaseConnector # pylint: disable=import-error
from app import app # pylint: disable=import-error
from Util.make_token import Token

connector = DatabaseConnector()

def __delete_all_test_inserts():
    """
    Delete everything test from the database. Cascade will take care of
    the enrollments and grades
    """
    delete_userlogin_stmt = "DELETE FROM UserLogin WHERE username LIKE 'test_%'"
    delete_course_stmt = "DELETE FROM Course WHERE department = 'TEST'"

    connector.delete([delete_userlogin_stmt, delete_course_stmt])

def __insert_test_variables() -> tuple:
    """
    Here we generate the test data that we will then
    use to validate the endpoint. This insert adds
    the following data:

    - Student "Sam Adam": Enrolled in 4 courses with 79 GPA
    - Student "Joe Appletree": Enrolled in 4 courses with no GPA
    - Admin "Peter Parker" (hashed password and salt is same as Sue Belcher's)
    - Professor "Apple Tree"
    - One Summer 2020 course.
    - One Fall 2021 course.
    - One Winter 2021 course.
    - One Winter 2022 course.

    - Enrolls Sam Adam and Joe Appletree in the courses and puts Proffesor apple tree
      as the proffessor.

    Gives Sam Adam the following grades:
        - 62 percent for Summer 2020 course
        - 94 percent for Fall 2021 course
        - 81 percent for Winter 2021 course
        - No grade for the Winter 2022 course.
    """

    insert_user = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Sam', 'Adam', 'test_sam_adam@mail.com', 'test_sam_adam', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_user_2 = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Joe', 'Appletree', 'test_joe_apptree@mail.com', 'test_joe_appletree', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_admin = "INSERT INTO UserLogin (fname, lname, email, username, password, phone, address, role, salt) VALUES ('Peter', 'Parker', 'test_peter_parker@mail.com', 'test_peter_parker', X'931d7e72465855f7bd8c1751856ae96a05eb1ec7c38a802522a9320e508371c9', '000-000-0000', 'Street 1000', 'admin', X'19166828d7059a009e224e2efcea66ed');"
    insert_prof = "INSERT INTO Instructor (fname, lname, department) VALUES ('Apple', 'Tree', 'COSC');"

    user_pk = connector.insert(insert_user)
    user_pk_2 = connector.insert(insert_user_2)
    admin_pk = connector.insert(insert_admin)
    prof_pk = connector.insert(insert_prof)

    # Keep adding courses and fix return stuff
    insert_course = "INSERT INTO Course (title, year, session, department, course_code, instructor_id, capacity, ccount) VALUES (%s, %s, %s, %s, %s, %s, 1, 0);"

    course_sqls = [
        insert_course,
        insert_course,
        insert_course,
        insert_course
    ]

    params = [
        ('Summer 2020', 2020, 'Summer', 'TEST', 123, prof_pk),
        ('Fall 2021', 2021, 'Fall', 'TEST', 456, prof_pk),
        ('Winter 2021', 2021, 'Winter', 'TEST', 789, prof_pk),
        ('Winter 2022', 2022, 'Winter', 'TEST', 206, prof_pk)
    ]

    insert_course = connector.insert(course_sqls, params)

    grades = [62, 94, 81]

    insert_enrollment = "INSERT INTO Enrollment (sid, cid) VALUES (%s, %s);"
    for i in range(0,4):
        connector.insert(insert_enrollment, (user_pk, insert_course[i]))
        connector.insert(insert_enrollment, (user_pk_2, insert_course[i]))

    insert_grade = "INSERT INTO Grade (sid, cid, grade) VALUES (%s, %s, %s);"
    for i in range (0,3):
        connector.insert(insert_grade, (user_pk, insert_course[i], grades[i]))

    # update student's gpa col in user login with their GPA
    update_gpa_stmt = 'UPDATE UserLogin SET gpa = (SELECT AVG(grade) AS gpa FROM Grade WHERE sid = %s) WHERE id = %s'
    params = (user_pk, user_pk)
    connector.update(update_gpa_stmt, params)

    student_token = Token.check_for_token(connector, user_pk)
    admin_token = Token.check_for_token(connector, admin_pk)
    course_pks = insert_course
    info = [admin_token, user_pk, user_pk_2, course_pks, student_token] # Peter Parker's token, Sam Adam's id, Joe Appletree's id, tuple of course ids, Sam adam's token

    return info

@pytest.fixture(scope="session", autouse=True)
def setup_session():
    """
    Runs before and after all tests. Ensures nothing test
    is left in the database
    """
    __delete_all_test_inserts()

    app.config["TESTING"] = True
    with app.test_client() as test_client:
        with app.app_context():
            yield test_client

    __delete_all_test_inserts()

@pytest.fixture(scope="function", autouse=True)
def setup_functions():
    """
    Here we clean the DB so that we can perform our tests without worrying about what state
    the DB is in. Then we cleanup to leave it the way we found it. The only data we assume
    to be present in the database and unaltered are the data in test.

    All example data we will test with has the prefix test_ in the username and test. in the
    email. DO NOT USE THESE PREFIXES IN NORMAL WORK!
    """
    __delete_all_test_inserts()

    user = __insert_test_variables()
    yield user

    __delete_all_test_inserts()

def test_200_gradeCourse(setup_session, setup_functions):
    """
    Test the /admin/gradeCourse endpoint for JSON response using the real database.
    This test should return a 200 response, meaning the student already has a GPA and
    that it is being updated with the new course's grade
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0] # requesting admin's token
    user_id = info[1] # user id of student that is being given grade
    course_id = info[3][3] # grade the Winter 2022 course

    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": admin_token,
            "student_id": user_id,
            "course_id": course_id,
            "course_grade": 80
            }
    )

    # Assert the response
    assert response.status_code == 200
    response_data = response.get_json()

    assert response_data['gpa'] == '79.25'


def test_201_gradeCourse(setup_session, setup_functions):
    """
    Test the /admin/gradeCourse endpoint for JSON response using the real database.
    """
    test_client = setup_session
    info = setup_functions
    admin_token = info[0] # requesting admin's token
    user_id = info[2] # user id of student that is being given grade
    course_id = info[3][3] # grade the Winter 2022 course

    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": admin_token,
            "student_id": user_id,
            "course_id": course_id,
            "course_grade": 80
            }
    )

    # Assert the response
    assert response.status_code == 201
    response_data = response.get_json()

    assert response_data['gpa'] == 80

def test_for_missing_token(setup_session, setup_functions):
    '''
    This tests for a case where a request is missing course_id:

    For this test specifically, course_id is missing
    '''
    test_client = setup_session
    info = setup_functions
    user_id = info[2] # user id of student that is being given grade
    course_id = info[3][3]

    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": '',
            "student_id": user_id,
            "course_id": course_id,
            "course_grade": 80
            }
    )
    response_data = response.get_json()
    
    # Assert the response
    assert response.status_code == 400
    assert response_data['bad request'] == 'missing token'

def test_for_missing_student_id(setup_session, setup_functions):
    '''
    This tests for a case where a request is missing course_id:

    For this test specifically, course_id is missing
    '''
    test_client = setup_session
    info = setup_functions
    admin_token = info[0] # requesting admin's token
    course_id = info[3][3]

    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": admin_token,
            "student_id": '',
            "course_id": course_id,
            "course_grade": 80
            }
    )
    response_data = response.get_json()

    # Assert the response
    assert response.status_code == 400
    assert response_data['bad request'] == 'missing student_id'

def test_for_missing_course_id(setup_session, setup_functions):
    '''
    This tests for a case where a request is missing course_id:

    For this test specifically, course_id is missing
    '''
    test_client = setup_session
    info = setup_functions
    admin_token = info[0] # requesting admin's token
    user_id = info[2] # user id of student that is being given grade

    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": admin_token,
            "student_id": user_id,
            "course_id": '',
            "course_grade": 80
            }
    )
    response_data = response.get_json()

    # Assert the response
    assert response.status_code == 400
    assert response_data['bad request'] == 'missing course_id'

def test_for_missing_course_grade(setup_session, setup_functions):
    '''
    This tests for a case where a request is missing course_id:

    For this test specifically, course_id is missing
    '''
    test_client = setup_session
    info = setup_functions
    admin_token = info[0] # requesting admin's token
    user_id = info[2] # user id of student that is being given grade
    course_id = info[3][3]


    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": admin_token,
            "student_id": user_id,
            "course_id": course_id,
            "course_grade": ''
            }
    )
    response_data = response.get_json()

    # Assert the response
    assert response.status_code == 400
    assert response_data['bad request'] == 'missing course_grade'

def test_for_user_not_admin(setup_session, setup_functions):
    '''
    This tests for a case where a request is made by a non-admin user
    '''
    test_client = setup_session
    info = setup_functions

    user_id = info[2] # user id of student that is being given grade
    token = info[4] # student's token
    course_id = info[3][3] # grade the Winter 2022 course

    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": token,
            "student_id": user_id,
            "course_id": course_id,
            "course_grade": 80
            }
    )
    response_data = response.get_json()

    # Assert the response
    assert response.status_code == 401
    assert response_data['unauthorized'] == 'invalid admin token'


def test_for_bad_grade(setup_session, setup_functions):
    '''
    This tests for a case where an admin enters a grade > 100
    '''

    test_client = setup_session
    info = setup_functions
    admin_token = info[0] # requesting admin's token
    user_id = info[2] # user id of student that is being given grade
    course_id = info[3][3] # grade the Winter 2022 course

    # Make the request
    response = test_client.put(
        '/admin/gradeCourse',
        json= {
            "token": admin_token,
            "student_id": user_id,
            "course_id": course_id,
            "course_grade": 101
            }
    )

    # Assert the response
    assert response.status_code == 400
    response_data = response.get_json()

    assert response_data['bad request'] == 'invalid grade value'
