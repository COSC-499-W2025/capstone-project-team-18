import pytest
from Util.make_token import Token
from Classes.database_connector import DatabaseConnector
from app import app

db = DatabaseConnector()

def __delete_all_test_inserts():
    """
    Delete everything test from the database
    """
    delete_userlogin_stmt = "DELETE FROM UserLogin WHERE username LIKE 'test_%'"
    delete_course_stmt = "DELETE FROM Course WHERE department = 'TEST'"

    db.delete([delete_userlogin_stmt, delete_course_stmt])


def __insert_test_variables() -> tuple:
    """
    Insert two UserLogins and one course. Will be deleted with __delete_all_test_inserts
    """
    insert_user_1 = "INSERT INTO UserLogin (id, fname, lname, email, username, password, phone, address, role, salt) VALUES ('998', 'Ardal', 'Bader', 'test_ardal_bader99@mail.com', 'test_ardal_bader', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_user_2 = "INSERT INTO UserLogin (id, fname, lname, email, username, password, phone, address, role, salt) VALUES ('999', 'Sam', 'Adam', 'test_sam_adam@mail.com', 'test_sam_adam', X'4b89573a20540a45349fce8268ffbdf29ee932004b9f64f2863aa54bc59ad99b', '000-000-0000', 'Street 1000', 'student', X'0307394446525c60a7fa422fadcf6267');"
    insert_course = "INSERT INTO Course (title, year, session, department, course_code, capacity, ccount) VALUES ('Test Course', 2022, 'Winter', 'TEST', 544, 1, 0);"

    test_user_pk_1 = db.insert(insert_user_1)
    test_user_pk_2 = db.insert(insert_user_2)
    test_course = db.insert(insert_course)

    return test_user_pk_1, test_user_pk_2, test_course


@pytest.fixture(scope="session", autouse=True)
def setup_session():
    """
    Runs before and after all tests. Ensures nothing test
    is left in the database
    """
    __delete_all_test_inserts()

    app.config["TESTING"] = True
    with app.test_client() as test_client:
        yield test_client

    __delete_all_test_inserts()


@pytest.fixture(scope="function", autouse=True)
def setup_functions():
    """
    Here we clean the DB so that we can perform our tests without worrying about what state
    the DB is in. Then we cleanup to leave it the way we found it. The only data we assume
    to be present in the database and unaltered are the data in test.

    All example data we will test with has the prefix test_ in the username and test. in the
    email. DO NOT USE THESE PREFIXES IN NORMAL WORK!
    """
    __delete_all_test_inserts()

    user1, user2, course = __insert_test_variables()
    yield user1, user2, course

    __delete_all_test_inserts()


def test_check_for__token():
    '''
    Test that are user who doesn't already have a token gets one generated
    and that if a user does have a token, it is returned.
    '''
    query = 'SELECT token FROM UserLogin WHERE id = %s'
    param = ('999',)
    result = db.query_json(query, param)
    missing_token = result[0].get('token')
    assert missing_token is None  # first, WTS that user doesn't already have token
    with app.app_context():
        test_token = Token.check_for_token(db, 999)  # call function in Token class.
    # check if the token was added to the db. This will also confirm that the function only returns
    # the token if it already exists
    token_db = db.query_json(query, param)
    generated_token = token_db[0].get('token')
    assert test_token == generated_token
