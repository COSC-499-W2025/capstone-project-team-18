import pytest
from unittest.mock import patch
from app import app # pylint: disable=import-error

@pytest.fixture
def client():
    """Create a test client for Flask."""
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

# Test for getting course by ID (COSC courses)
def test_get_course_by_id_success(client): #FI!!!
    """Test successfully retrieving a COSC course by its ID."""

    response = client.get('/course/info?cid=1')

    assert response.status_code == 200


def test_get_course_by_id_failure(client): #FI!!!
    """Test failure when the COSC course ID is not found."""

    response = client.get('/course/info?cid=-1')  # Invalid course ID

    assert response.status_code == 404  # Not found
    assert response.json['error'] == 'Course not found'
