"""
This file is the landing script for the server
"""
from flask import Flask
import os
from flask_jwt_extended import JWTManager

from blueprints.auth_endpoints import auth_bp
from blueprints.course_endpoints import course_bp
from blueprints.student_endpoints import student_bp
from blueprints.transcript_endpoints import transcript_bp
from blueprints.admin_endpoints import admin_bp

CURRENT_YEAR = 2022
CURRENT_SESSION = 'Winter'

app = Flask(__name__)

# Setup the Flask-JWT-Extended extension
app.config["JWT_SECRET_KEY"] = os.environ.get("JWT_SECRET_KEY", "default_secret_key")
jwt = JWTManager(app)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(course_bp, url_prefix='/course')
app.register_blueprint(student_bp, url_prefix='/student')
app.register_blueprint(transcript_bp, url_prefix='/transcript')
app.register_blueprint(admin_bp, url_prefix="/admin")

@app.route("/ping", methods=['GET'])
def ping():
    return "I have been pinged"

if __name__ == "__main__":
    app.run(debug=True, port=3000)

