'''
This file will check whether a user in the db
already has a JWT. If they don't a new token
is generated and saved to the Token table. It
also has functions for getting a user's role
and a user's id using their token.
'''
from flask_jwt_extended import create_access_token

class Token:

    @staticmethod
    def check_for_token(db_connector, id):
        '''
        Checks the if there is an existing token for a user.
        If there is, return it. If there is not, generate a
        new token, add it to the user's row in the UserLogin
        table, and return the token. This token must be passed
        when making requests to other endpoints, such as
        /student/enroll.

        Parameters
        db_connector : database_connector obj
            Pass in the database_connector singleton that is in server app.py.
        id : str
            The user's id that we want to get/generate a token for.

        Returns
        str
            The token returned from the SELECT query, or the newly generated token.
        '''
        param = (id, ) # a single-element tuple
        query = 'SELECT token FROM UserLogin WHERE id = %s' # check if the user already has a token
        response = db_connector.query(query, param)
        token = response[0][0] # get the token
        if token is None: # if the DB returns null, we need to create a token
            token = create_access_token(identity=id) # generate a new token
            params = (token, id)
            update_stmt = "UPDATE UserLogin SET token=%s WHERE id=%s" # update the user's row with the token
            db_connector.update(update_stmt, params)
            return token # return the token
        else: # user already has token, so we return it
            return token

    @staticmethod
    def id_role_by_token(db_connector, token):
        """
        Returns: tuple (userlogin_id: int, is_student: bool)
        """
        res_json = Token.find_user_by_token(db_connector, token)
        return res_json.get("id"), res_json.get("role") == 'student'

    @staticmethod
    def find_user_by_token(db_connector, token):
        '''
        ** Returns a user's info using their token. It
        is assumed that this will only be called for
        users with existing tokens. **

        Parameters
        token : str
            The user's JWT

        Returns
        JSON
            The user's id, username, token, role
        '''

        param = (token, ) # a single-element tuple
        query = 'SELECT id, username, token, role FROM UserLogin WHERE token = %s'

        response = db_connector.query_json(query, param)

        if len(response) == 0:
            raise ValueError("Invaild Token")

        response_json = response[0]

        return response_json

    @staticmethod
    def authenticate_token_admins_or_self(db_connector, request):
        """
        This function will be called by server endpoints.

        It will grab the token from the body. If the token
        relates to an admin it will return the student id
        in the parameters. If the token relates to a student,
        it will return what that id is
        """

        # Token stored in body.
        body = request.get_json()
        token = body.get("token")
        student_id = request.args.get("student_id")

        if token is None:
            raise ValueError("Unauthorized. No token")

        user_login_id, is_student = Token.id_role_by_token(db_connector, token)

        if is_student and student_id is not None:
            raise ValueError("Student can not access other student accounts")

        if student_id is None:
            student_id = user_login_id

        return student_id
