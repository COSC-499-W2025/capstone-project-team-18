import mysql
from flask import request, jsonify, Blueprint
from Classes.database_connector import DatabaseConnector
from Classes.auth import Authentication
from Util.make_token import Token

db_connector = DatabaseConnector() # singleton DatabaseConnector object
auth = Authentication() # singleton Authentication object

student_bp = Blueprint("student", __name__)

@student_bp.route("/all", methods=['GET'])
def get_all_students():
    """
    Retrieves all students. This is used to show
    all students on the admin dashboard.

    Returns:
        - JSON response containing a list of all students, including:
            - id: Student ID
            - fname: First name
            - lname: Last name
            - email: Email address
            - username: Username
            - phone: Phone number
            - address: Address
    """
    query = "SELECT id, fname, lname, email, username, phone, address FROM UserLogin WHERE role = 'student';"
    result = db_connector.query_json(query)

    if len(result) == 0:
        return jsonify({"err": "No students found"}), 400
    else:
        return jsonify(result), 200

@student_bp.route("/info", methods=['GET'])
def get_student_by_id():
    """
    Retrieves student information by student ID.

        - If the student is self, a valid token is required. The information
            returned is info about self.

        - In the case of an admin, a student_id may be encoded in the parameters,
            if inculded, the infomation return is about *that* student. If no parameters
            infomation returned is about self. Note that of course enrollments and waitlist
            will be empty as admin's can not enroll in courses.

        - JSON response containing the corresponding student information, including:
            - id: Student ID
            - fname: First name
            - lname: Last name
            - email: Email address
            - username: Username
            - phone: Phone number
            - address: Address
            - enrollments: List of courses the student is enrolled in, including course ID, title, department, and grade
            - previous_enrollments: List of courses the student has grades for this year
            - waitlist: List of courses the student is waitlisted for, including course ID, title, and department
        - If the student ID is missing, returns a JSON error message with status code 400.
        - If the student is not found, returns a JSON error message with status code 400.
    """

    try:
        student_id = Token.authenticate_token_admins_or_self(
            db_connector=db_connector,
            request=request
            )
    except ValueError as e:
        return jsonify({'err': str(e)}), 400

    query = "SELECT id, fname, lname, email, username, phone, address FROM UserLogin WHERE id = %s "

    result = db_connector.query_json(query, (student_id,))

    if len(result) == 0:
        return jsonify({"err": "Student not found"}), 400
    else:
        result = result[0]

    query_enrollments = ("SELECT "
                            "Course.cid, "
                            "Course.title, "
                            "Course.department, "
                            "COALESCE(Grade.grade, 'N/A') AS grade "
                        "FROM Course "
                            "JOIN Enrollment ON Course.cid = Enrollment.cid "
                            "LEFT JOIN Grade ON Enrollment.cid = Grade.cid AND Enrollment.sid = Grade.sid "
                        "WHERE Enrollment.sid = %s AND Course.session = %s AND Course.year = %s;")

    from app import CURRENT_SESSION, CURRENT_YEAR

    result_enrollments = db_connector.query_json(query_enrollments, (student_id , CURRENT_SESSION, CURRENT_YEAR))

    result['enrollments'] = result_enrollments

    query_waitlist = ("SELECT "
                        "Course.cid, "
                        "Course.title, "
                        "Course.department, "
                        "Waitlist.waitlist_position "
                    "FROM Course JOIN Waitlist ON Course.cid = Waitlist.cid "
                    "WHERE Waitlist.sid = %s AND Course.session = %s AND Course.year = %s;")

    result_waitlist = db_connector.query_json(query_waitlist, (student_id , CURRENT_SESSION, CURRENT_YEAR))

    result['waitlist'] = result_waitlist

    query_graded_courses = ("SELECT "
                        "Course.cid, "
                        "Course.title, "
                        "Course.department "
                    "FROM Course JOIN Grade ON Course.cid = Grade.cid "
                    "WHERE Grade.sid = %s AND Course.session = %s AND Course.year = %s;")

    previous_courses = db_connector.query_json(query_graded_courses, (student_id , CURRENT_SESSION, CURRENT_YEAR))

    result['previous_enrollments'] = previous_courses

    if len(result) != 0:
        return jsonify(result), 200

@student_bp.route("/update", methods=['POST'])
def update_student_by_id():
    """
    Expects:
        - Valid token.
        - Student ID must be encoded in the URL parameters.
        - Modified fields in the request body as key-value pairs.

    Returns:
        - Status of update in JSON format.
    """
    student_id = request.args.get("student_id")
    data = request.json

    try:
        student_id = Token.authenticate_token_admins_or_self(
            db_connector=db_connector,
            request=request
            )
    except ValueError as e:
        return jsonify({'err': str(e)}), 400

    if not student_id or not data:
        return jsonify({"error": "Missing student_id or update data"}), 400

    del data['token']

    query = "UPDATE UserLogin SET " + ", ".join(f"{k} = %s" for k in data.keys()) + " WHERE id = %s"
    params = tuple(data.values()) + (student_id,)

    try:
        db_connector.update(query, params)
    except mysql.connector.errors.IntegrityError as e:
        db_connector.cnx
        if "Duplicate entry" in str(e):
            if "UserLogin.email" in str(e):
                return jsonify({"err": "Email already exists"}), 400
            elif "UserLogin.username" in str(e):
                return jsonify({"err": "Username already exists"}), 400
        else:
            return jsonify({"err": "Database error"}), 500

    return jsonify({'success': True}), 200


@student_bp.route("/enroll", methods=['POST'])
def add_to_course():
    """
    This endpoint allows a student to enroll in a course. If the course has available capacity, the student is enrolled directly.
    If the course is full, the student is placed on the waitlist.

    Request JSON format:
    {
        "student_id": "<student_id>",
        "course_id": "<course_id>"
    }

    Responses
    ---------
    200 OK:
        Successful enrollment or waitlist placement.
        RETURNS: {
            "placement": "enrolled" | "waitlisted"
        }
    400 Bad Request:
        Missing student_id or course_id.
        RETURNS: {
            "error": "Missing student_id or course_id"
        }
    400 Bad Request:
        Student already has a grade for the course
        RETURNS: {
            "err": "Student already has a grade for this course"
        }
    400 Bad Request:
        Student already is enrolled or on waitlist.
        RETURNS: {
            "err": "Student already is enrolled or on waitlist"
        }
    400 Bad Request:
        Unknown error occurred.
        RETURNS: {
            "err": "Unknown error occurred"
        }
    """

    data = request.json
    token = data.get("token")
    student_id = data.get("student_id")
    course_id = data.get("course_id")

    user_login_pk, is_student = Token.id_role_by_token(db_connector, token)

    if not is_student and student_id is None:
        return jsonify({'err': "Missing student_id parameter"}), 400
    elif is_student:
        student_id = user_login_pk

    if not student_id or not course_id:
        return jsonify({"error": "Missing student_id or course_id"}), 400

    # Check to see if student has a grade

    query_graded = "SELECT cid, sid FROM Grade WHERE cid=%s AND sid=%s;"

    graded_result = db_connector.query_json(query_graded, (course_id, student_id))

    if len(graded_result) != 0:
        return jsonify({'err', "Student already has a grade for this course"}), 400

    # First, check if student is already enrolled

    query_enrollment = "SELECT cid, sid FROM Enrollment WHERE cid=%s AND sid=%s UNION SELECT cid, sid FROM Waitlist WHERE cid=%s AND sid=%s"

    results_enrollment = db_connector.query_json(query_enrollment, (course_id, student_id, course_id, student_id))

    if len(results_enrollment) != 0:
        return jsonify({'err': f"Student already is enrolled or on waitlist"}), 400

    # Then check to see if the course has capacity:

    query_course = "SELECT * FROM Course WHERE cid=%s AND ccount >= capacity"

    results = db_connector.query_json(query_course, (course_id,))

    update_stmt = None
    insert_stmt = None
    insert_param = None
    if len(results) == 0: # Has capacity

        update_stmt = "UPDATE Course SET ccount = ccount + 1 WHERE cid = %s"
        insert_stmt = "INSERT INTO Enrollment (sid, cid) VALUES (%s, %s)"

        insert_param = (student_id, course_id)
        to_return = {"placement": "enrolled"}
    elif len(results) == 1: # Does not have capacity

        # Get position of student in waitlist
        wait_list_pos = results[0]["waitlist_count"] + 1

        update_stmt = "UPDATE Course SET waitlist_count = waitlist_count + 1 WHERE cid = %s"
        insert_stmt = "INSERT INTO Waitlist (sid, cid, waitlist_position) VALUES (%s, %s, %s)"

        insert_param = (student_id, course_id, wait_list_pos)
        to_return = {"placement": "waitlisted"}
    else:
        return jsonify({"err": "Unkown error occured"}), 400

    sql_stmt = [insert_stmt, update_stmt]
    params = [insert_param, (course_id, )]

    db_connector.update(sql_stmt, params)

    return jsonify(to_return), 200

@student_bp.route("/drop", methods=['POST'])
def remove_from_course():
    """
    This endpoint allows a student to drop a course. If the student is enrolled in the course, they are removed from the enrollment.
    If the student is on the waitlist for the course, they are removed from the waitlist. If the course has a waitlist, the next student
    on the waitlist is moved to the enrollment.

    Request JSON format:
    {
        "student_id": "<student_id>",
        "course_id": "<course_id>"
    }

    Responses
    ---------
    200 OK:
        Successful drop from enrollment or waitlist.
        RETURNS: {
            "msg": "Student deleted off enrollment" | "Student deleted off waitlist"
        }
    400 Bad Request:
        Missing student_id or course_id.
        RETURNS: {
            "error": "Missing student_id or course_id"
        }
    400 Bad Request:
        Student is not enrolled or on waitlist.
        RETURNS: {
            "err": "Student is not enrolled or on waitlist for course"
        }
    400 Bad Request:
        Unknown error occurred.
        RETURNS: {
            "err": "Unknown error occurred"
        }
    """

    data = request.json
    token = data.get("token")
    student_id = data.get("student_id")
    course_id = data.get("course_id")

    user_login_pk, is_student = Token.id_role_by_token(db_connector, token)

    if not is_student and student_id is None:
        return jsonify({'err': 'Missing student_id parameter'}), 400
    elif is_student:
        student_id = user_login_pk

    # Where is student? Enrollment or Waitlist

    enrollment_query = "SELECT * FROM Enrollment WHERE sid=%s AND cid=%s"
    enrollment_response = db_connector.query_json(enrollment_query, (student_id, course_id))

    waitlist_query = "SELECT * FROM Waitlist WHERE sid=%s AND cid=%s"
    waitlist_response = db_connector.query_json(waitlist_query, (student_id, course_id))

    if len(enrollment_response) == 0 and len(waitlist_response) == 0:
        return jsonify({'err': "Student is not enrolled or on waitlist for course"})

    to_return = None

    # Case that the student is enrolled in a course:
    if len(enrollment_response) == 1:

        # Check to see if students are on the Waitlist
        waitlist_query_course = "SELECT * FROM Waitlist WHERE cid=%s AND waitlist_position = 1"
        waitlist_query_course_response = db_connector.query_json(waitlist_query_course, (course_id,))

        if len(waitlist_query_course_response) != 0:
            # Case we need to move students up into the course
            student_off_waitlist_pk = waitlist_query_course_response[0]["sid"]

            # Delete our enrollment, delete student off waitlist, update all other waitlist for course, add student in pos 1 into Enrollment
            sql_stmts = [
                "DELETE FROM Enrollment WHERE sid=%s AND cid=%s",
                "DELETE FROM Waitlist WHERE cid=%s AND sid=%s",
                "UPDATE Waitlist SET waitlist_position = waitlist_position - 1 WHERE cid=%s",
                "INSERT INTO Enrollment (sid, cid) VALUES (%s, %s)"
            ]

            params = [
                (student_id, course_id),
                (course_id, student_off_waitlist_pk),
                (course_id ,),
                (student_off_waitlist_pk, course_id)
            ]

            to_return = {'msg': "Student deleted off enrollment and waitlist updated"}
        else:
            # Case there is no one else in the waitlist

            # Delete our enrollment, decrease ccount on course

            sql_stmts = [
                "DELETE FROM Enrollment WHERE sid=%s AND cid=%s",
                "UPDATE Course SET ccount = ccount - 1 WHERE cid=%s"
            ]

            params = [
                (student_id, course_id),
                (course_id ,)
            ]

            to_return = {'msg': "Student deleted off enrollment"}
    elif len(waitlist_response) == 1:

        # Case student is on the waitlist

        sql_stmts = [
            "DELETE FROM Waitlist WHERE cid=%s AND sid=%s",
            "UPDATE Waitlist SET waitlist_position = waitlist_position - 1 WHERE cid=%s",
            "UPDATE Course SET waitlist_count = waitlist_count - 1 WHERE cid=%s"
        ]

        params = [
            (course_id, student_id),
            (course_id, ),
            (course_id, )
        ]

        to_return = {'msg': "Student deleted off waitlist"}
    else:
        return jsonify({'err': "Duplicate entries in enrollment and Waitlist"}), 400

    # Do final updates
    db_connector.update(sql_stmts, params)

    return jsonify(to_return), 200
