from flask import request, jsonify, Blueprint
from Classes.database_connector import DatabaseConnector
from Classes.auth import Authentication
from Util.make_token import Token

db_connector = DatabaseConnector() # singleton DatabaseConnector object
auth = Authentication() # singleton Authentication object

auth_bp = Blueprint("auth", __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    '''
    Call this endpoint for checking if a given username and password
    are valid login credentials.
    ----------------------------
    Parameters
    ----------
    data : JSON
        The request being made to this endpoint.
        - Includes the following:
            - Request URL
            - Request body
                - Contains only the entered username and password
            - A timeout value
    -------------------------
    Responses
    ---------
    400 Bad Request:
        The user did not enter both a username AND a password; one is missing.
    401 Unauthorized:
        The user did not enter valid credentials. They either mistyped or need to make an account
    200 OK:
        The user entered valid login credentials.
    '''
    data = request.json # get the incoming request
    
    # verify username and password are in request (does not mean they have been validated)
    if 'username' not in data or len(data.get('username')) == 0:
        return jsonify({'bad request': 'missing username'}), 400
    if 'pswd' not in data or len(data.get('pswd')) == 0:
        return jsonify({'bad request': 'missing pswd'}), 400
    
    request_username = data.get('username') # get the entered username
    request_pswd = data.get('pswd')         # get the entered password

    query_params = (request_username, ) # we'll use the username to get the corresponding pswd and salt (this is a tuple with one element)
    query = 'SELECT id, password, salt, role FROM UserLogin WHERE username = %s' # the query we'll make to the db
    result = db_connector.query_json(query, query_params) # query the db and get the result
    if len(result) > 0: # if db returned data
        result_id = result[0].get('id')   # get the id in the db
        result_pswd = result[0].get('password')  # get the password in the db
        result_salt = result[0].get('salt')  # get the salt in the db
        result_role = result[0].get('role')  # get the role (e.g. admin) in the db
        if auth.password_matches_hash(result_pswd, request_pswd, result_salt): # check is entered pswd and pswd in db match
            jwt = Token.check_for_token(db_connector, result_id) # get/generate a token for the user
            response = jsonify({'status': 'login-success', 'message': 'Login successful', 'user_role': result_role, 'token': jwt }) # send response back as JSON
            return response, 200
    return jsonify({"status": "error", "message": "Invalid credentials"}), 401
