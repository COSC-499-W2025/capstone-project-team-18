'''
This file is for "admin-only" endpoints. That is,
requests to these endpoints can only be made by
users with the "admin" role. 

Pytests for these endpoints are located in /src/tests/unit/admin_endpoints/
'''
from flask import request, jsonify, Blueprint
from Classes.database_connector import DatabaseConnector
from Classes.auth import Authentication
from Util.make_token import Token

db_connector = DatabaseConnector() # singleton DatabaseConnector object
auth = Authentication() # singleton Authentication object

admin_bp = Blueprint("admin", __name__)

'''
Helper functions for endpoints. Includes:
    - validate_admin
    - update_student_gpa
'''
def validate_admin(token : str) -> bool:
    '''
    Check that the requesting user is an admin

    Expects:
        - A valid user token
    
    Returns:
        - True, if user has role of admin in UserLogin
        - False, if user does not have role of admin in UserLogin
    '''
    if Token.find_user_by_token(db_connector, token).get('role') == 'admin':
        return True
    return False
def update_student_gpa(db_connector, student_id):

    get_update_gpa_stmt = 'SELECT AVG(grade) as gpa FROM Grade WHERE sid = %s'
    params = (student_id, )
    query = db_connector.query_json(get_update_gpa_stmt, params)
    updated_gpa  = str(float(query[0].get('gpa')))

    # student's only grade is the one for the class that is being graded,
    # their gpa = that course's grade
    update_gpa_stmt = 'UPDATE UserLogin SET gpa = %s WHERE id = %s'
    params = (updated_gpa, student_id)
    db_connector.update(update_gpa_stmt, params)

    return updated_gpa

'''
The following endpoints are in this file:

- /gradeCourse
- /getStudentByParameters
'''
@admin_bp.route('/gradeCourse', methods=['PUT'])
def grade_course():
    '''
    Admins can grade a course that a student is enrolled in. 
    This is the student's final grade for the course, 
    meaning that they are no longer enrolled in it. 
    After a course is graded, the student's GPA needs to be
    (re)calculted with the added grade.
     - The GPA column in the UserLogin table should
       be updated
     - The student's enrollment in the course should
       be removed from the Enrollment table.

    Expects:
        - Valid ADMIN token (token)
        - Student ID encoded in URL (student_id)
        - Course ID encoded in URL (course_id)
        - The course's grade (int)

    Returns:
        - Status of update
    '''
    data = request.json
    token = data.get('token')
    student_id = data.get('student_id')
    course_id = data.get('course_id')
    course_grade = data.get('course_grade')

    # verify request has all expected data
    if not token:
        return jsonify({'bad request': 'missing token'}), 400
    if not student_id:
        return jsonify({'bad request': 'missing student_id'}), 400
    if not course_id:
        return jsonify({'bad request': 'missing course_id'}), 400
    if not course_grade:
        return jsonify({'bad request': 'missing course_grade'}), 400

    # get admin's token
    requesting_users_role = Token.find_user_by_token(db_connector, token)
    
    # verify that entered grade is a number
    try:
        course_grade = float(course_grade)
    except ValueError:
        return jsonify({'bad request': 'course_grade must be a number'}), 400

    # verify that the user making the request is an admin
    if requesting_users_role.get('role') != 'admin':
        return jsonify({'unauthorized': 'invalid admin token'}), 401

    # verify that the grade is between 0 and 100
    elif course_grade < 0  or course_grade > 100:
        return jsonify({'bad request': 'invalid grade value'}), 400

    else:
        # Insert new grade into Grade table
        insert_grade_stmt = 'INSERT INTO Grade (sid, cid, grade) VALUES (%s, %s, %s)'
        params = (student_id, course_id, course_grade)
        db_connector.insert(insert_grade_stmt, params)

        # drop student from course
        remove_from_enrollment = 'DELETE FROM Enrollment WHERE sid = %s AND cid = %s'
        params = (student_id, course_id)
        db_connector.delete(remove_from_enrollment, params)

        # check if the student already has gpa
        check_for_gpa = 'SELECT gpa FROM UserLogin WHERE id = %s'
        params = (student_id, )
        response = db_connector.query_json(check_for_gpa, params)
        gpa = response[0]['gpa']

        updated_gpa = update_student_gpa(db_connector= db_connector, student_id=student_id)

        if gpa is None:
            return jsonify({'created': 'grade was recorded, student was dropped from course, gpa was created', 'gpa' : data.get('course_grade')}), 201

        # If they have other grades, update their gpa col in UserLogin
        else:
            return jsonify({'ok': 'grade was recorded, student was dropped from course, gpa was updated', 'gpa' : updated_gpa}), 200


@admin_bp.route('/getStudentByParameters', methods=['POST'])
def get_student_by_parameters():
    '''
    Admins can filter students according to 
    a given criteria. If no criteria is provided,
    all students are returned.

    Expects 0 or more:
        - GPA (range)
        - Name
        - Course ID

    Returns: 
        - Rows of students that 
        match given criteria.
    '''

    data = request.json
    token = data.get('token') # requesting user's token
    params = []
    query = 'SELECT id, fname, lname, gpa FROM UserLogin WHERE 1=1'
    # check that user is an admin
    if validate_admin(token) == False:
        return jsonify({'unauthorized': 'invalid admin token'}), 400

    if "course_pk" in data:
        query = 'SELECT id, fname, lname, gpa FROM UserLogin JOIN Enrollment ON UserLogin.id = Enrollment.sid AND Enrollment.cid = %s WHERE 1=1'
        #course_query = 'SELECT DISTINCT(sid) FROM Enrollment WHERE cid=%s'
        params.append(data['course_pk'])
        #enrollment_response = db_connector.query_json(course_query, course_params)
        #query += ' AND id = (SELECT DISTINCT(sid) FROM Enrollment WHERE cid=%s)'
        #params.append(data['course_pk'])
    
    if "gpa_min" in data: # the min GPA to filter by
        params.append(int(data['gpa_min']))
    else:
        params.append(0) # default value if not provided
    query += ' AND gpa >= %s'

    if "gpa_max" in data: # the max GPA to filter by
        params.append(int(data['gpa_max']))
    else:
        params.append(100) # default value if not provided
    query += ' AND gpa <= %s'

    # we assume that a student's full name is always provided
    # and that every student has a first and last name, separated by a space
    if 'name' in data:
        full_name = data['name'].split() # e.g. full_name = [John, Doe]
        query += ' AND fname = %s AND lname = %s'
        params.append(full_name[0])
        params.append(full_name[1])

   

    response = db_connector.query_json(query, tuple(params))
    print(query)
    print(params)
    return jsonify(response), 200