from flask import request, jsonify, Blueprint
from Classes.database_connector import DatabaseConnector
from Classes.auth import Authentication

db_connector = DatabaseConnector() # singleton DatabaseConnector object
auth = Authentication() # singleton Authentication object

course_bp = Blueprint("course", __name__)

@course_bp.route("/info", methods=['GET'])
def get_course_by_id():
    """
    Expects:
        - Valid token.
        - Course ID must be encoded in the URL parameters.

    Returns:
        - Corresponding course information in JSON.
    """
    cid = request.args.get("cid")

    if not cid:
        return jsonify({"error": "Missing course_id parameter"}), 400

    query = "SELECT * FROM Course WHERE cid = %s"
    result = db_connector.query(query, (cid,))

    if result:
        return jsonify(result[0])
    return jsonify({"error": "Course not found"}), 404

@course_bp.route("/all", methods=['GET'])
def get_all_courses():
    """
    Expects:
        - Valid token.

    Returns:
        - All courses in JSON.
    """
    query = "SELECT * FROM Course"
    result = db_connector.query(query)

    # Convert each tuple into a dictionary
    courses = [
        {
            "course_id": row[0],
            "course_name": row[1],
            "year": row[2],
            "session": row[3],
            "department": row[4],
            "course_code": row[5],
            "instructor": row[6],
            "capacity": row[7],
            "current_enrollment": row[8],
            "max_enrollment": row[9],
            "waitlist_capacity": row[10]
        } for row in result
    ]

    return jsonify(courses)

@course_bp.route("/update", methods=['PUT'])
def update_course_by_id():
    """
    Expects:
        - Valid ADMIN token.
        - Course ID must be encoded in the URL parameters.
        - Modified fields in the request body as key-value pairs.

    Returns:
        - Status of update in JSON format.
    """
    course_id = request.args.get("course_id")
    data = request.json

    if not course_id or not data:
        return jsonify({"error": "Missing course_id or update data"}), 400

    query = "UPDATE courses SET " + ", ".join(f"{k} = %s" for k in data.keys()) + " WHERE course_id = %s"
    params = tuple(data.values()) + (course_id,)

    result = db_connector.query(query, params)
    return jsonify(result)

@course_bp.route("/search", methods=['POST'])
def get_course_by_parameters():
    """
    Expects:
        - Valid token.
        - Parameters for a course to satisfy stored in the body as key-value pairs. Only include
        parameters that are used. If you don't want to sort by instructor, do not include in body.

        The following are valid parameters: INVAILD PARAMETERS ARE IGNORED.

            - department | String : Only return courses with this department code.

                Example: "COSC", "MATH"

            - course_code | String: Only return courses with a specific code. If there is a *,
                           the system will return all codes that match the characters before that.
                           For example, "1*" will return a courses whose code start with 1.

                           Example: "101", "2*", "303"

            - has_capacity | boolean : If true, we will only return classes that have capacity.
                                    Students could enroll right away without waiting in a waitlist.

            - instructor | string: Contains the PRIMARY KEY of the instructor. If present,
                                    this endpoint will only return courses taught by this professor

                                    Example: "27" (Which is primary key for Yves Lucet)

            - year | String : Return courses in this year.

                              Example: "2022", "2023"

            - session | String : Only can be "Winter", "Summer", or "Fall" . Return courses in this session.

    Returns:
        - Courses that satisfy the parameters returned in a list of objects of JSON type.
    """

    data = request.json
    query = "SELECT * FROM Course WHERE 1=1"
    params = []

    if "department" in data:
        query += " AND department = %s"
        params.append(data["department"])

    if "course_code" in data:
        if "*" in data["course_code"]:
            query += " AND course_code LIKE %s"
            params.append(data["course_code"].replace("*", "%"))
        else:
            query += " AND course_code = %s"
            params.append(data["course_code"])

    if "has_capacity" in data and data["has_capacity"]:
        query += " AND current_enrollment < max_enrollment"

    if "instructor" in data:
        query += " AND instructor = %s"
        params.append(data["instructor"])

    if "year" in data:
        query += " AND year = %s"
        params.append(data["year"])

    if "session" in data:
        query += " AND session = %s"
        params.append(data["session"])

    result = db_connector.query_json(query, tuple(params))

    return jsonify(result)
