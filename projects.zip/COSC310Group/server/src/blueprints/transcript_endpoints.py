from json2xml import json2xml
from flask import request, jsonify, Blueprint
from Classes.database_connector import DatabaseConnector
from Classes.auth import Authentication
from Util.make_token import Token
from blueprints.admin_endpoints import update_student_gpa
import json

db_connector = DatabaseConnector() # singleton DatabaseConnector object
auth = Authentication() # singleton Authentication object

transcript_bp = Blueprint("transcript", __name__)

@transcript_bp.route('/generateReport', methods=['GET'])
def generate_student_report():
    """
    Expects:
        - If student is self, vaild token, else the endpoint requires admin status.
        - Student ID encoded in URL
        - File Format for report one of JSON, CSV, or TXT

    Returns:
        - File in specified format


    Reports will have the following, format:

    {
        "fname": "John",
        "lname": "Doe",
        "email": "john.doe@example.com",
        "phone": "123-456-7890",
        "address": "123 Main St",
        "transcript": [
            {
            "grade": "Pending",
            "letter_grade": "Pending",
            "title": "Drawing Techniques",
            "year": 2022,
            "session": "Winter",
            "department": "ARTS",
            "course_code": "201",
            "instructor_fname": "Victor",
            "instructor_lname": "Sculptor"
            },
            ...
                {
            "grade": "95.0",
            "letter_grade": "A+",
            "title": "Digital Citizenship",
            "year": 2020,
            "session": "Fall",
            "department": "COSC",
            "course_code": "101",
            "instructor_fname": "Steve",
            "instructor_lname": "Coder"
            }
        ]
    }
    """

    body = request.get_json()

    token = body.get("token")
    file_type = body.get("file_type")

    student_pk = Token.authenticate_token_admins_or_self(db_connector, request)

    query_personal_info = "SELECT fname,lname,email,phone,address,gpa FROM UserLogin WHERE id = %s;"

    query_transcript = """
    SELECT
        COALESCE(Grade.grade, 'Pending') AS grade,
        COALESCE(Grade.letter_grade, 'Pending') AS letter_grade,
        Course.title,
        Course.year,
        Course.session,
        Course.department,
        Course.course_code,
        Instructor.fname AS instructor_fname,
        Instructor.lname AS instructor_lname
    FROM
        Course
    JOIN
        Instructor
    ON
        Course.instructor_id = Instructor.id
    LEFT JOIN
        Grade
    ON
        Grade.cid = Course.cid
    WHERE
        Course.cid IN (
            SELECT cid
            FROM Enrollment
            WHERE Enrollment.sid = %s
            UNION
            SELECT cid
            FROM Grade
            WHERE Grade.sid = %s
        )
    ORDER BY
        Course.year DESC,
        FIELD(Course.session, 'Winter', 'Summer', 'Fall');
    """



    # Execute the query using your database connector
    student_info = db_connector.query_json(query_personal_info, (student_pk,))
    transcript = db_connector.query_json(query_transcript, (student_pk, student_pk))

    if len(student_info) == 0:
        return jsonify({'err': 'Can not retrieve info about student. Something went wrong.'}), 400

    student_info = student_info[0]

    #Get current ranking
    query_ranking = """
        WITH Rs AS (
            SELECT id,
                RANK() OVER (ORDER BY gpa DESC) AS rank_position
            FROM UserLogin
            WHERE role = 'student' AND gpa IS NOT NULL
        )
        SELECT rank_position
        FROM Rs
        WHERE id = %s;
    """

    query_ranking_params = (student_pk,)


    ranking_res = db_connector.query_json(query_ranking, query_ranking_params)

    if len(ranking_res) != 0:
        student_info["ranking"] = ranking_res[0]["rank_position"]

    if file_type == "JSON" or file_type == "XML":

        student_info["transcript"] = transcript


        if file_type == "JSON":
            return jsonify(student_info), 200

        return json2xml.Json2xml(student_info).to_xml(), 200

    elif file_type == "TXT":
        to_return = "Student Info\n"

        # Convert Personal Info
        for key in student_info.keys():
            to_return += str(key) + ": " + str(student_info.get(key)) + ", "

        to_return += "Transcript\n"

        # Convert transcript Info
        for course in transcript:
            for key in course.keys():
                to_return += str(key) + ": " + str(course.get(key)) + ", "
            to_return += "\n"

        return to_return, 200

    return jsonify({'err': 'Unkown error occured.'}), 400

@transcript_bp.route('/uploadTranscript', methods=['POST'])
def upload_transcript():
    """
    Expects:
        - Valid ADMIN token.
        - Student ID encoded in the request body.
        - File format JSON specified in the request body.
        - Transcript data in the specified format.

    Processes:
        - Parses the transcript data.
        - Validates the courses in the transcript.
        - Updates the database with the transcript information.

    Returns:
        - Status of the upload.
    """
    body = request.get_json()

    student_pk = body.get("student_id")
    transcript_data = body.get("transcript_data")  # The actual transcript content

    # Authenticate the token to ensure the user is an admin
    Token.authenticate_token_admins_or_self(db_connector, request)

    if not student_pk or not transcript_data:
        return jsonify({'err': 'Missing required fields: student_id, file_type, or transcript_data'}), 400

    # Parse the transcript data based on the file type
    try:
        transcript = dict(transcript_data)
    except Exception as e:
        return jsonify({'err': f'Failed to parse transcript data: {str(e)}'}), 400

    # Ensure at first level that
    required_firstlvl_keys = {'fname', 'lname', 'email', 'phone', 'address', 'transcript'}

    if not verify_json_matches_template(transcript, required_firstlvl_keys):
        return jsonify({'err': 'Failed to parse transcript data.'}), 400

    sql_stmt = []
    params = []

    # Get all first level keys into parameters
    student_info_params = (
        transcript.get('fname'),
        transcript.get('lname'),
        transcript.get('email'),
        transcript.get('phone'),
        transcript.get('address'),
        student_pk
    )

    if any(value is None for value in student_info_params):
        return jsonify({'err': 'One or more required fields in student info are null'}), 400

    update_query = """
        UPDATE UserLogin
        SET fname = %s,
            lname = %s,
            email = %s,
            phone = %s,
            address = %s
        WHERE id = %s;
        """

    sql_stmt.append(update_query)
    params.append(student_info_params)

    # Delete all grades
    delete_grades_query = """
        DELETE FROM Grade
        WHERE sid = %s;
    """

    delete_params = (student_pk,)

    sql_stmt.append(delete_grades_query)
    params.append(delete_params)

    required_secondlvl_keys = {'grade', 'year', 'session', 'department', 'course_code'}

    for course in transcript['transcript']:
        if not verify_json_matches_template(course, required_secondlvl_keys):
            return jsonify({'err', "Missing one of 'grade', 'year', 'session', 'department', 'course_code'"})

        grade = course.get('grade')
        year = course.get('year')
        session = course.get('session')
        department = course.get('department')
        course_code = course.get('course_code')

        # If currently enrolled, skip over this.
        if course.get('grade') == "Pending":
            continue

        select_query = """
            SELECT cid
            FROM Course
            WHERE year = %s
                AND session = %s
                AND department = %s
                AND course_code = %s;
            """

        # Parameters for the query
        query_params = (year, session, department, course_code)

        # Execute the query
        res = db_connector.query_json(select_query, query_params)

        if len(res) == 0:
            return jsonify({
                'err': f"Course with year '{year}', session '{session}', department '{department}', and course code '{course_code}' does not exist in the database."
            }), 400

        # Insert new grades into the Grade table
        insert_grade_query = """
            INSERT INTO Grade (sid, cid, grade)
            VALUES (%s, %s, %s);
        """

        inser_grade_params = (student_pk, res[0]['cid'], grade)

        sql_stmt.append(insert_grade_query)
        params.append(inser_grade_params)

    db_connector.update(sql_stmt, params)

    update_student_gpa(db_connector=db_connector, student_id=student_pk)

    # Validate and process the transcript
    return jsonify({'success': True, 'message': 'Transcript uploaded successfully.'}), 200

def verify_json_matches_template(data, template):
    """
    Ensures all values in the template are
    keys in the data and none are null.
    """

    for key in template:
        if key not in data or data[key] is None:
            return False

    return True
