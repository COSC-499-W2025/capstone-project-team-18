"""
This file defines the Authentication class.
"""
import os
import hashlib
from typing import Final

class Authentication:
    """
    This class will handle Authentication logic between the database and the server
    """

    def __init__(self):
        pass

    @staticmethod
    def vaildate_token(token: str) -> bool:
        """
        Vaildates given token with the database. Returns true if vaild and false otherwise.
        """

    @staticmethod
    def hash(password: str | bytes, salt: bytes = os.urandom(16)) -> tuple[bytes, bytes]:
        """
        Given password and optionally salt, returns salt and hashed password
        """

        if len(salt) != 16:
            raise ValueError("Salt parameter needs to be 16 bytes long")

        if isinstance(password, str):
            password = password.encode()

        # Set once and forever! *Do not change* or old passwords will not work.
        hash_itreations: Final[int] = 5000

        hashed_password = hashlib.pbkdf2_hmac('sha256', password, salt, hash_itreations)

        return salt, hashed_password

    @staticmethod
    def password_matches_hash(hashed_password: bytes, password: str, salt: bytes) -> bool:
        """
        Checks to see if salt and hash matches password
        """

        _, proposed_hash = Authentication.hash(password, salt)

        return hashed_password == proposed_hash
