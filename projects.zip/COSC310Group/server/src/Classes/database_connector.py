"""
This file defines the DatabaseConnector class
"""
import os
from typing import Callable, List, Tuple, Any, Optional, Union
import mysql.connector
from mysql.connector.pooling import PooledMySQLConnection
from mysql.connector.abstracts import MySQLConnectionAbstract, MySQLCursorAbstract

class SingletonMeta(type):
    '''
    We use the metaclass approach for ensuring that 
    there is *actually* only one instance of 
    DatabaseConnector in our app.
    '''

    _instances = {}

    def __call__(cls, *args, **kwargs):
        """
        Possible changes to the value of the `__init__` argument do not affect
        the returned instance.
        """
        if cls not in cls._instances:
            instance = super().__call__(*args, **kwargs)
            cls._instances[cls] = instance
        return cls._instances[cls]


class DatabaseConnector(metaclass = SingletonMeta):
    """
    This file abstracts connecting to the database. The functions here should be general methods
    they should not be endpoint specific.
    """

    endpoint: str
    cnx: Optional[Union[PooledMySQLConnection, MySQLConnectionAbstract]] = None

    def __init__(self):
        """
        Will throw mysql.connector.Error if database runs into an error. Up to caller to handle
        this.
        """
        self.__establish_connection_to_db()

    def __establish_connection_to_db(self):
        """
        This function will try to connect to the database.
        """

        # This env var will only be present if we are running this script
        # on a docker container
        self.endpoint = os.environ.get("SQL_HOSTNAME") # mysql

        if self.endpoint is None:
            # If we are here, we are running on main computer
            self.endpoint = "localhost"

        try:
            self.cnx = mysql.connector.connect(user='root', password='secret',
                                               host=self.endpoint,
                                               database='university',
                                               connection_timeout=5)
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            self.cnx = None

    def insert(self, insert_stmt: Union[str, List[str]],
               params: Union[Tuple[Any, ...], List[Tuple[Any, ...]]] = ()) -> Union[int, List[int]]:
        """
        Insert data into the database with INSERT statement. If given a list of insert statments,
        all work will be ATMOIC.

        Args:
            insert_stmt: This can either be a str or a list of str. If there is a list of str, the
            database will treat each statement as ATOMIC. Meaning either all updates get added or
            none of the updates get added.

            The insert_stmt string must be formatted, that is using '%s' as a placeholder for your
            parameters to be placed.

            params: An ordered list of your parameters that will be used to replace your '%s'

        Returns:
            int or List[int]: Primary key of the added object(s). It will return one int in the case
            of a single insert and a list in the case of multiple.
        """
        return self.__switch_on_parameters(
            insert_stmt,
            params,
            lambda c: c.lastrowid
        )

    def query(self, query: str, params: Tuple[Any, ...] = ()) -> List[Tuple[Any, ...]]:
        """
        Query the database with a SELECT statement. Note: Unlike other methods, this will only
        accept one query statment.

        Args:
            query: The query string must be formatted, that is using '%s' as a placeholder for your
            parameters to be placed.

            params: An ordered list of your parameters that will be used to replace your '%s'

        Returns:
            List[Tuple[Any, ...]]: Your results in a List where each Tuple corresponds to a row in
            your result

        """
        return self.__execute_single(query,
                                     params,
                                     (lambda c: [row for row in c])
                                     )

    def query_json(self, query: str, params: Tuple[Any, ...] = ()) -> List[dict]:
        """
            Executes a SQL query and returns the result as a list of dictionaries (JSON format).

            Args:
                query (str): The SQL query to be executed.
                params (Tuple[Any, ...], optional): A tuple of parameters to be used with the SQL query. Defaults to ().

            Returns:
                List[dict]: The result of the SQL query in JSON format.
        """

        return self.__switch_on_parameters(
            query,
            params,
            self.cursor_to_json
        )

    def cursor_to_json(self, cursor: MySQLCursorAbstract) -> List[dict]:
        """
        Convert cursor results to a list of dictionaries with column names as keys.
        """
        columns = [col[0] for col in cursor.description]
        return [dict(zip(columns, row)) for row in cursor]


    def delete(self, delete_stmt: Union[str, List[str]], params: Tuple[Any, ...] = ()) -> int:
        """
        Executes a DELETE statement on the database.

        Args:
            delete_stmt (str): The DELETE SQL statement to be executed.
            params (Tuple[Any, ...], optional): The parameters to be used in the DELETE statement.
            Defaults to ().

        Returns:
            int: The number of rows affected by the DELETE statement.
        """

        rows_affected = self.__switch_on_parameters(
            delete_stmt,
            params,
            lambda c: c.rowcount
        )

        if isinstance(rows_affected, list):
            return sum(rows_affected)

        return rows_affected

    def update(self, update_stmt: Union[str, List[str]],
               params: Union[Tuple[Any, ...], List[Tuple[Any, ...]]] = ()) -> int:
        """
        Exects a UPDATE statment on the DB

        Args:
            update_stmt: The statment to be executed. Can be a single str, or it can be a list of
            str.
            params: The parameters. If update_stmt is a str, then params must be a Tuple. If
            update_stmt is List, then params must be a list of Tuple.

        Returns:
            - int: The number of rows affected by the UPDATE statement.
        """

        rows_affected = self.__switch_on_parameters(
            update_stmt,
            params,
            lambda c: c.rowcount
        )

        if isinstance(rows_affected, list):
            return sum(rows_affected)

        return rows_affected


    def __switch_on_parameters(self, sql: Union[str, List[str]],
                               params: Union[Tuple[Any, ...], List[Tuple[Any, ...]]] = (),
                               callback: Callable[[MySQLCursorAbstract], Any] = None
                               ) -> Union[int, List[int]]:
        """
        In the insert and delete functions, we will have the case where we might get many different
        sql statements to perform at once or we might get only one. We define one method here that
        will handle both cases and throw an error otherwise.
        """
        # Case we have multiple SQL statements
        if isinstance(sql, list) and (isinstance(params, list) or params == ()):
            if(params != () and len(sql) != len(params)):
                raise ValueError("List of SQL statements and list of parameters do not match")
            return self.__execute_many(sql, params, callback)
        elif isinstance(sql, str) and isinstance(params, tuple):
            # Case we have a single sql statement
            return self.__execute_single(sql, params, callback)
        else:
            raise ValueError("Both of insert_stmt and params need to be a list or none of them.")

    def __execute_single(self, sql: str, params: Tuple[Any, ...] = (),
                         callback: Callable[[MySQLCursorAbstract], Any] = None):
        """
        Execute sql statement on DB connection. Returns cursor object.
        """
        if self.cnx is None:
            self.__establish_connection_to_db()
        cursor = self.cnx.cursor()
        try:
            cursor.execute(sql, params)
            to_return = callback(cursor)
            self.cnx.commit()
        except mysql.connector.Error as err:
            self.cnx.rollback()
            raise err
        finally:
            cursor.close()

        return to_return if to_return is not None else []  # Always return a list, even if empty

    def __execute_many(self, list_of_sql: List[str],
                       params: List[Tuple[Any, ...]],
                       callback: Callable[[MySQLCursorAbstract], Any] = None) -> List[Any]:
        """
        Execute many sql statements on one cursor. Transactions are ATOMIC.

        The callback function will perfom an opreation on the cursor and put in list.
        """
        if self.cnx is None:
            self.__establish_connection_to_db()
        to_return = []

        # If length of params is empty, then we have no parameters that need to be run. In this case
        # make a list of empty tuples equal to the list of sql stmts. So that the for loop will run
        if not params or len(params) == 0:
            params = [()] * len(list_of_sql)

        try:
            cursor = self.cnx.cursor()
            for stmt, param in zip(list_of_sql, params):
                cursor.execute(stmt, param)
                if callback:
                    to_return.append(callback(cursor))
            self.cnx.commit()
        except mysql.connector.Error as err:
            self.cnx.rollback()
            raise err
        finally:
            cursor.close()
        return to_return
