-- Instructors for COSC (Computer Science)
INSERT INTO Instructor (fname, lname, department) VALUES
('Steve', 'Coder', 'COSC'),
('Jack', 'Programmer', 'COSC'),
('Alice', 'Debugger', 'COSC');

-- Instructors for MATH (Mathematics)
INSERT INTO Instructor (fname, lname, department) VALUES
('Sarah', 'Mathematician', 'MATH'),
('Grace', 'Algebra', 'MATH'),
('Eve', 'Geometer', 'MATH');

-- Instructors for ENGL (English)
INSERT INTO Instructor (fname, lname, department) VALUES
('Karen', 'Writer', 'ENGL'),
('Leo', 'Poet', 'ENGL'),
('Sophia', 'Novelist', 'ENGL');

-- Instructors for SCIN (Science)
INSERT INTO Instructor (fname, lname, department) VALUES
('Peter', 'Scientist', 'SCIN'),
('Quinn', 'Researcher', 'SCIN'),
('Rachel', 'Biologist', 'SCIN');

-- Instructors for ARTS (Fine Arts)
INSERT INTO Instructor (fname, lname, department) VALUES
('Uma', 'Painter', 'ARTS'),
('Victor', 'Sculptor', 'ARTS'),
('Wendy', 'Illustrator', 'ARTS');
