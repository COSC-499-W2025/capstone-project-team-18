-- These courses are example data generated with use of LLM AI (Deepseek).
-- There are courses of department COSC, ARTS, ENGL, SCIN.
-- Each Course choses a

-- Courses for 2022
-- Fall 2022
INSERT INTO Course (title, year, session, department, course_code, capacity, ccount, instructor_id) VALUES
('Digital Citizenship', 2022, 'Fall', 'COSC', 101, 150, 0, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Calculus I', 2022, 'Fall', 'MATH', 101, 120, 0, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1)), -- Year 1, MATH instructor
('Introduction to Literature', 2022, 'Fall', 'ENGL', 101, 100, 0, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1)), -- Year 1, ENGL instructor
('Biology Fundamentals', 2022, 'Fall', 'SCIN', 101, 90, 0, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1)), -- Year 1, SCIN instructor
('Art History', 2022, 'Fall', 'ARTS', 101, 80, 0, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1)), -- Year 1, ARTS instructor
('Data Structures', 2022, 'Fall', 'COSC', 201, 100, 0, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 2, COSC instructor
('Linear Algebra', 2022, 'Fall', 'MATH', 201, 110, 0, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 2, MATH instructor
('Creative Writing', 2022, 'Fall', 'ENGL', 201, 95, 0, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 2, ENGL instructor
('Chemistry Basics', 2022, 'Fall', 'SCIN', 201, 85, 0, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 2, SCIN instructor
('Drawing Techniques', 2022, 'Fall', 'ARTS', 201, 75, 0, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)), -- Year 2, ARTS instructor
('Software Engineering', 2022, 'Fall', 'COSC', 301, 100, 0, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 3, COSC instructor
('Statistics for Engineers', 2022, 'Fall', 'MATH', 301, 110, 0, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 3, MATH instructor
('American Literature', 2022, 'Fall', 'ENGL', 301, 95, 0, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 3, ENGL instructor
('Physics for Life Sciences', 2022, 'Fall', 'SCIN', 301, 85, 0, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 3, SCIN instructor
('Sculpture Basics', 2022, 'Fall', 'ARTS', 301, 75, 0, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 3, ARTS instructor
('Computer Networks', 2022, 'Fall', 'COSC', 401, 100, 0, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 4, COSC instructor
('Number Theory', 2022, 'Fall', 'MATH', 401, 110, 0, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 4, MATH instructor
('World Literature', 2022, 'Fall', 'ENGL', 401, 95, 0, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 4, ENGL instructor
('Environmental Science', 2022, 'Fall', 'SCIN', 401, 85, 0, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 4, SCIN instructor
('Painting Fundamentals', 2022, 'Fall', 'ARTS', 401, 75, 0, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 4, ARTS instructor
('Artificial Intelligence', 2022, 'Fall', 'COSC', 501, 100, 0, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 5, COSC instructor
('Mathematical Modeling', 2022, 'Fall', 'MATH', 501, 110, 0, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 5, MATH instructor
('Poetry Workshop', 2022, 'Fall', 'ENGL', 501, 95, 0, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 5, ENGL instructor
('Geology Basics Hardcoded as a almost full course!', 2022, 'Fall', 'SCIN', 501, 85, 84, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 5, SCIN instructor
('Digital Photography Hardcoded as a full course!', 2022, 'Fall', 'ARTS', 501, 75, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)); -- Year 5, ARTS instructor

-- Winter 2022
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Digital Citizenship', 2022, 'Winter', 'COSC', 101, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Calculus I', 2022, 'Winter', 'MATH', 101, 120, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1)), -- Year 1, MATH instructor
('Introduction to Literature', 2022, 'Winter', 'ENGL', 101, 100, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1)), -- Year 1, ENGL instructor
('Biology Fundamentals', 2022, 'Winter', 'SCIN', 101, 90, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1)), -- Year 1, SCIN instructor
('Art History', 2022, 'Winter', 'ARTS', 101, 80, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1)), -- Year 1, ARTS instructor
('Data Structures', 2022, 'Winter', 'COSC', 201, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 2, COSC instructor
('Linear Algebra', 2022, 'Winter', 'MATH', 201, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 2, MATH instructor
('Creative Writing', 2022, 'Winter', 'ENGL', 201, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 2, ENGL instructor
('Chemistry Basics', 2022, 'Winter', 'SCIN', 201, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 2, SCIN instructor
('Drawing Techniques', 2022, 'Winter', 'ARTS', 201, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)), -- Year 2, ARTS instructor
('Software Engineering', 2022, 'Winter', 'COSC', 301, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 3, COSC instructor
('Statistics for Engineers', 2022, 'Winter', 'MATH', 301, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 3, MATH instructor
('American Literature', 2022, 'Winter', 'ENGL', 301, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 3, ENGL instructor
('Physics for Life Sciences', 2022, 'Winter', 'SCIN', 301, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 3, SCIN instructor
('Sculpture Basics', 2022, 'Winter', 'ARTS', 301, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 3, ARTS instructor
('Database Systems', 2022, 'Winter', 'COSC', 302, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 3, COSC instructor
('Probability and Statistics', 2022, 'Winter', 'MATH', 302, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 3, MATH instructor
('Modern Fiction', 2022, 'Winter', 'ENGL', 302, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 3, ENGL instructor
('Astronomy Basics', 2022, 'Winter', 'SCIN', 302, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 3, SCIN instructor
('Photography Essentials', 2022, 'Winter', 'ARTS', 302, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 3, ARTS instructor
('Computer Networks', 2022, 'Winter', 'COSC', 401, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 4, COSC instructor
('Number Theory', 2022, 'Winter', 'MATH', 401, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 4, MATH instructor
('World Literature', 2022, 'Winter', 'ENGL', 401, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 4, ENGL instructor
('Environmental Science', 2022, 'Winter', 'SCIN', 401, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 4, SCIN instructor
('Painting Fundamentals', 2022, 'Winter', 'ARTS', 401, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 4, ARTS instructor
('Artificial Intelligence', 2022, 'Winter', 'COSC', 501, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 5, COSC instructor
('Mathematical Modeling', 2022, 'Winter', 'MATH', 501, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 5, MATH instructor
('Poetry Workshop', 2022, 'Winter', 'ENGL', 501, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 5, ENGL instructor
('Geology Basics', 2022, 'Winter', 'SCIN', 501, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 5, SCIN instructor
('Digital Photography', 2022, 'Winter', 'ARTS', 501, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)); -- Year 5, ARTS instructor


-- Summer 2022
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Python for Data Science', 2022, 'Summer', 'COSC', 103, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Blockchain Technology', 2022, 'Summer', 'COSC', 104, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 1, COSC instructor
('Big Data Analytics', 2022, 'Summer', 'COSC', 105, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 1, COSC instructor
('DevOps Practices', 2022, 'Summer', 'COSC', 106, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 1, COSC instructor
('Quantum Computing', 2022, 'Summer', 'COSC', 107, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)); -- Year 1, COSC instructor


-- Courses for 2021
-- Fall 2021
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Digital Citizenship', 2021, 'Fall', 'COSC', 101, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Calculus I', 2021, 'Fall', 'MATH', 101, 120, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1)), -- Year 1, MATH instructor
('Introduction to Literature', 2021, 'Fall', 'ENGL', 101, 100, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1)), -- Year 1, ENGL instructor
('Biology Fundamentals', 2021, 'Fall', 'SCIN', 101, 90, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1)), -- Year 1, SCIN instructor
('Art History', 2021, 'Fall', 'ARTS', 101, 80, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1)), -- Year 1, ARTS instructor
('Data Structures', 2021, 'Fall', 'COSC', 201, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 2, COSC instructor
('Linear Algebra', 2021, 'Fall', 'MATH', 201, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 2, MATH instructor
('Creative Writing', 2021, 'Fall', 'ENGL', 201, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 2, ENGL instructor
('Chemistry Basics', 2021, 'Fall', 'SCIN', 201, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 2, SCIN instructor
('Drawing Techniques', 2021, 'Fall', 'ARTS', 201, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)), -- Year 2, ARTS instructor
('Software Engineering', 2021, 'Fall', 'COSC', 301, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 3, COSC instructor
('Statistics for Engineers', 2021, 'Fall', 'MATH', 301, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 3, MATH instructor
('American Literature', 2021, 'Fall', 'ENGL', 301, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 3, ENGL instructor
('Physics for Life Sciences', 2021, 'Fall', 'SCIN', 301, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 3, SCIN instructor
('Sculpture Basics', 2021, 'Fall', 'ARTS', 301, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 3, ARTS instructor
('Computer Networks', 2021, 'Fall', 'COSC', 401, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 4, COSC instructor
('Number Theory', 2021, 'Fall', 'MATH', 401, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 4, MATH instructor
('World Literature', 2021, 'Fall', 'ENGL', 401, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 4, ENGL instructor
('Environmental Science', 2021, 'Fall', 'SCIN', 401, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 4, SCIN instructor
('Painting Fundamentals', 2021, 'Fall', 'ARTS', 401, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 4, ARTS instructor
('Artificial Intelligence', 2021, 'Fall', 'COSC', 501, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 5, COSC instructor
('Mathematical Modeling', 2021, 'Fall', 'MATH', 501, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 5, MATH instructor
('Poetry Workshop', 2021, 'Fall', 'ENGL', 501, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 5, ENGL instructor
('Geology Basics', 2021, 'Fall', 'SCIN', 501, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 5, SCIN instructor
('Digital Photography', 2021, 'Fall', 'ARTS', 501, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)); -- Year 5, ARTS instructor

-- Winter 2021
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Web Development', 2021, 'Winter', 'COSC', 102, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Calculus II', 2021, 'Winter', 'MATH', 102, 120, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1)), -- Year 1, MATH instructor
('Shakespeare Studies', 2021, 'Winter', 'ENGL', 102, 100, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1)), -- Year 1, ENGL instructor
('Physics Principles', 2021, 'Winter', 'SCIN', 102, 90, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1)), -- Year 1, SCIN instructor
('Sculpture Basics', 2021, 'Winter', 'ARTS', 102, 80, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1)), -- Year 1, ARTS instructor
('Algorithms', 2021, 'Winter', 'COSC', 202, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 2, COSC instructor
('Discrete Mathematics', 2021, 'Winter', 'MATH', 202, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 2, MATH instructor
('Poetry Workshop', 2021, 'Winter', 'ENGL', 202, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 2, ENGL instructor
('Environmental Science', 2021, 'Winter', 'SCIN', 202, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 2, SCIN instructor
('Painting Fundamentals', 2021, 'Winter', 'ARTS', 202, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)); -- Year 2, ARTS instructor

-- Summer 2021
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Python for Data Science', 2021, 'Summer', 'COSC', 103, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Blockchain Technology', 2021, 'Summer', 'COSC', 104, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 1, COSC instructor
('Big Data Analytics', 2021, 'Summer', 'COSC', 105, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 1, COSC instructor
('DevOps Practices', 2021, 'Summer', 'COSC', 106, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 1, COSC instructor
('Quantum Computing', 2021, 'Summer', 'COSC', 107, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)); -- Year 1, COSC instructor

-- Courses for 2020
-- Fall 2020
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Digital Citizenship', 2020, 'Fall', 'COSC', 101, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Calculus I', 2020, 'Fall', 'MATH', 101, 120, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1)), -- Year 1, MATH instructor
('Introduction to Literature', 2020, 'Fall', 'ENGL', 101, 100, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1)), -- Year 1, ENGL instructor
('Biology Fundamentals', 2020, 'Fall', 'SCIN', 101, 90, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1)), -- Year 1, SCIN instructor
('Art History', 2020, 'Fall', 'ARTS', 101, 80, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1)), -- Year 1, ARTS instructor
('Data Structures', 2020, 'Fall', 'COSC', 201, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 2, COSC instructor
('Linear Algebra', 2020, 'Fall', 'MATH', 201, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 2, MATH instructor
('Creative Writing', 2020, 'Fall', 'ENGL', 201, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 2, ENGL instructor
('Chemistry Basics', 2020, 'Fall', 'SCIN', 201, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 2, SCIN instructor
('Drawing Techniques', 2020, 'Fall', 'ARTS', 201, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)), -- Year 2, ARTS instructor
('Software Engineering', 2020, 'Fall', 'COSC', 301, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 3, COSC instructor
('Statistics for Engineers', 2020, 'Fall', 'MATH', 301, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 3, MATH instructor
('American Literature', 2020, 'Fall', 'ENGL', 301, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 3, ENGL instructor
('Physics for Life Sciences', 2020, 'Fall', 'SCIN', 301, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 3, SCIN instructor
('Sculpture Basics', 2020, 'Fall', 'ARTS', 301, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 3, ARTS instructor
('Computer Networks', 2020, 'Fall', 'COSC', 401, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 4, COSC instructor
('Number Theory', 2020, 'Fall', 'MATH', 401, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 2)), -- Year 4, MATH instructor
('World Literature', 2020, 'Fall', 'ENGL', 401, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 2)), -- Year 4, ENGL instructor
('Environmental Science', 2020, 'Fall', 'SCIN', 401, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 2)), -- Year 4, SCIN instructor
('Painting Fundamentals', 2020, 'Fall', 'ARTS', 401, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 2)), -- Year 4, ARTS instructor
('Artificial Intelligence', 2020, 'Fall', 'COSC', 501, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 5, COSC instructor
('Mathematical Modeling', 2020, 'Fall', 'MATH', 501, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 5, MATH instructor
('Poetry Workshop', 2020, 'Fall', 'ENGL', 501, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 5, ENGL instructor
('Geology Basics', 2020, 'Fall', 'SCIN', 501, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 5, SCIN instructor
('Digital Photography', 2020, 'Fall', 'ARTS', 501, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)); -- Year 5, ARTS instructor

-- Winter 2020
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Web Development', 2020, 'Winter', 'COSC', 102, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Calculus II', 2020, 'Winter', 'MATH', 102, 120, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1)), -- Year 1, MATH instructor
('Shakespeare Studies', 2020, 'Winter', 'ENGL', 102, 100, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1)), -- Year 1, ENGL instructor
('Physics Principles', 2020, 'Winter', 'SCIN', 102, 90, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1)), -- Year 1, SCIN instructor
('Sculpture Basics', 2020, 'Winter', 'ARTS', 102, 80, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1)), -- Year 1, ARTS instructor
('Algorithms', 2020, 'Winter', 'COSC', 202, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 2, COSC instructor
('Discrete Mathematics', 2020, 'Winter', 'MATH', 202, 110, (SELECT id FROM Instructor WHERE department='MATH' LIMIT 1 OFFSET 1)), -- Year 2, MATH instructor
('Poetry Workshop', 2020, 'Winter', 'ENGL', 202, 95, (SELECT id FROM Instructor WHERE department='ENGL' LIMIT 1 OFFSET 1)), -- Year 2, ENGL instructor
('Environmental Science', 2020, 'Winter', 'SCIN', 202, 85, (SELECT id FROM Instructor WHERE department='SCIN' LIMIT 1 OFFSET 1)), -- Year 2, SCIN instructor
('Painting Fundamentals', 2020, 'Winter', 'ARTS', 202, 75, (SELECT id FROM Instructor WHERE department='ARTS' LIMIT 1 OFFSET 1)); -- Year 2, ARTS instructor

-- Summer 2020
INSERT INTO Course (title, year, session, department, course_code, capacity, instructor_id) VALUES
('Python for Data Science', 2020, 'Summer', 'COSC', 103, 150, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1)), -- Year 1, COSC instructor
('Blockchain Technology', 2020, 'Summer', 'COSC', 104, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)), -- Year 1, COSC instructor
('Big Data Analytics', 2020, 'Summer', 'COSC', 105, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 1, COSC instructor
('DevOps Practices', 2020, 'Summer', 'COSC', 106, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 2)), -- Year 1, COSC instructor
('Quantum Computing', 2020, 'Summer', 'COSC', 107, 100, (SELECT id FROM Instructor WHERE department='COSC' LIMIT 1 OFFSET 1)); -- Year 1, COSC instructor
