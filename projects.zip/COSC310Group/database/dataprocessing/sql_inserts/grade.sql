-- First Year (2020) - Level 1 Courses
INSERT INTO Grade (sid, cid, grade) VALUES
(1, (SELECT cid FROM Course WHERE title = 'Digital Citizenship' AND year = 2020 AND session = 'Fall'), 95.0), -- COSC course
(1, (SELECT cid FROM Course WHERE title = 'Calculus I' AND year = 2020 AND session = 'Fall'), 87.5), -- MATH course
(1, (SELECT cid FROM Course WHERE title = 'Introduction to Literature' AND year = 2020 AND session = 'Fall'), 90.0), -- ENGL course
(1, (SELECT cid FROM Course WHERE title = 'Biology Fundamentals' AND year = 2020 AND session = 'Fall'), 85.0), -- SCIN course
(1, (SELECT cid FROM Course WHERE title = 'Art History' AND year = 2020 AND session = 'Fall'), 92.5), -- ARTS course
(1, (SELECT cid FROM Course WHERE title = 'Web Development' AND year = 2020 AND session = 'Winter'), 91.0), -- COSC course
(1, (SELECT cid FROM Course WHERE title = 'Calculus II' AND year = 2020 AND session = 'Winter'), 83.0), -- MATH course
(1, (SELECT cid FROM Course WHERE title = 'Shakespeare Studies' AND year = 2020 AND session = 'Winter'), 88.0), -- ENGL course
(1, (SELECT cid FROM Course WHERE title = 'Physics Principles' AND year = 2020 AND session = 'Winter'), 94.0), -- SCIN course
(1, (SELECT cid FROM Course WHERE title = 'Sculpture Basics' AND year = 2020 AND session = 'Winter'), 90.5); -- ARTS course

-- Second Year (2021) - Level 2 Courses
INSERT INTO Grade (sid, cid, grade) VALUES
(1, (SELECT cid FROM Course WHERE title = 'Data Structures' AND year = 2021 AND session = 'Fall'), 93.0), -- COSC course
(1, (SELECT cid FROM Course WHERE title = 'Linear Algebra' AND year = 2021 AND session = 'Fall'), 82.0), -- MATH course
(1, (SELECT cid FROM Course WHERE title = 'Creative Writing' AND year = 2021 AND session = 'Fall'), 91.5), -- ENGL course
(1, (SELECT cid FROM Course WHERE title = 'Chemistry Basics' AND year = 2021 AND session = 'Fall'), 86.0), -- SCIN course
(1, (SELECT cid FROM Course WHERE title = 'Drawing Techniques' AND year = 2021 AND session = 'Fall'), 95.0), -- ARTS course
(1, (SELECT cid FROM Course WHERE title = 'Algorithms' AND year = 2021 AND session = 'Winter'), 90.0), -- COSC course
(1, (SELECT cid FROM Course WHERE title = 'Discrete Mathematics' AND year = 2021 AND session = 'Winter'), 87.0), -- MATH course
(1, (SELECT cid FROM Course WHERE title = 'Poetry Workshop' AND year = 2021 AND session = 'Winter'), 84.0), -- ENGL course
(1, (SELECT cid FROM Course WHERE title = 'Environmental Science' AND year = 2021 AND session = 'Winter'), 93.5), -- SCIN course
(1, (SELECT cid FROM Course WHERE title = 'Painting Fundamentals' AND year = 2021 AND session = 'Winter'), 91.0); -- ARTS course

-- Third Year (2022) - Level 3 Courses
INSERT INTO Grade (sid, cid, grade) VALUES
(1, (SELECT cid FROM Course WHERE title = 'Software Engineering' AND year = 2022 AND session = 'Fall'), 94.0), -- COSC course
(1, (SELECT cid FROM Course WHERE title = 'Statistics for Engineers' AND year = 2022 AND session = 'Fall'), 87.5), -- MATH course
(1, (SELECT cid FROM Course WHERE title = 'American Literature' AND year = 2022 AND session = 'Fall'), 90.0), -- ENGL course
(1, (SELECT cid FROM Course WHERE title = 'Physics for Life Sciences' AND year = 2022 AND session = 'Fall'), 85.0), -- SCIN course
(1, (SELECT cid FROM Course WHERE title = 'Sculpture Basics' AND year = 2022 AND session = 'Fall'), 92.5); -- ARTS course

UPDATE UserLogin u
SET gpa = (
    SELECT AVG(g.grade)
    FROM Grade g
    WHERE g.sid = u.id
)
WHERE role = 'student';
