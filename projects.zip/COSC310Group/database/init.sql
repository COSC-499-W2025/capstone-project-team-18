-- This file will be run every time that the docker container is started.
-- Use this file to describe the DDL of the database.
-- DDL
DROP DATABASE IF EXISTS university;
CREATE DATABASE university;
USE university;

-- Users table (Stores both students and administrators)
CREATE TABLE UserLogin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    gpa DECIMAL(5,2), -- should be in the form **.** (or 100.00)
    email VARCHAR(100) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARBINARY(1024) NOT NULL, -- Hashed passwords
    salt BINARY(16) NOT NULL,
    token VARCHAR(1024),
    phone VARCHAR(15),
    address VARCHAR(255),
    role ENUM('student', 'admin') NOT NULL
);

-- Instructors table (Stores instructors separately from users)
CREATE TABLE Instructor (
    id INT PRIMARY KEY AUTO_INCREMENT,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    department CHAR(4) NOT NULL
);

-- Courses table (Stores course details)
CREATE TABLE Course (
    cid INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    year INT NOT NULL,
    session ENUM('Winter', 'Fall', 'Summer') NOT NULL,
    department VARCHAR(20) NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    instructor_id INT NULL,
    capacity INT NOT NULL, -- Maximum allowed students
    ccount INT DEFAULT 0, -- Current enrolled student count
    waitlist_capacity INT DEFAULT 10, -- Maximum waitlist size. Default is currently placeholder value
    waitlist_count INT DEFAULT 0, -- Current number of waitlisted students
    FOREIGN KEY (instructor_id) REFERENCES Instructor(id)
);
-- Enrollment table (Tracks which students are enrolled in which courses)
CREATE TABLE Enrollment (
    sid INT NOT NULL,
    cid INT NOT NULL,
    PRIMARY KEY (sid, cid),
    FOREIGN KEY (sid) REFERENCES UserLogin(id) ON DELETE CASCADE,
    FOREIGN KEY (cid) REFERENCES Course(cid) ON DELETE CASCADE
);
-- Grades table (Stores student grades)
CREATE TABLE Grade (
    sid INT NOT NULL,
    cid INT NOT NULL,
    grade DECIMAL(5,2) CHECK (grade >= 0 AND grade <= 100),
    letter_grade CHAR(2) GENERATED ALWAYS AS (
        CASE
            WHEN grade >= 90 THEN 'A+'
            WHEN grade >= 85 THEN 'A'
            WHEN grade >= 80 THEN 'A-'
            WHEN grade >= 75 THEN 'B+'
            WHEN grade >= 70 THEN 'B'
            WHEN grade >= 65 THEN 'B-'
            WHEN grade >= 60 THEN 'C+'
            WHEN grade >= 55 THEN 'C'
            WHEN grade >= 50 THEN 'D'
            ELSE 'F'
        END
    ) STORED,
    PRIMARY KEY (sid, cid),
    FOREIGN KEY (sid) REFERENCES UserLogin(id) ON DELETE CASCADE,
    FOREIGN KEY (cid) REFERENCES Course(cid) ON DELETE CASCADE
);
-- Waitlist table (Tracks students waiting for full courses)
CREATE TABLE Waitlist (
    cid INT NOT NULL,
    sid INT NOT NULL,
    reqDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    waitlist_position INT NOT NULL, -- Student's position in the waitlist queue
    PRIMARY KEY (cid, sid),
    FOREIGN KEY (cid) REFERENCES Course(cid) ON DELETE CASCADE,
    FOREIGN KEY (sid) REFERENCES UserLogin(id) ON DELETE CASCADE
);

-- Example UserLogins

-- example login password is !hashmeplease!
INSERT INTO UserLogin (fname, lname, email, username, salt, password, phone, address, role) VALUES
('John', 'Doe', 'john.doe@example.com', 'johndoe', X'7455d46e6765869eed97262782e6ba9c', X'be57475eb03835d55df9c7720b0d641ba16dbc3086ab71d02dc143cd4f3aa3b2', '123-456-7890', '123 Main St', 'student');

-- example admin pasword
INSERT INTO UserLogin (fname, lname, email, username, salt, password, phone, address, role) VALUES
('Sue', 'Belcher', 'sue.bel@example.com', 'suebelcher', X'19166828d7059a009e224e2efcea66ed', X'931d7e72465855f7bd8c1751856ae96a05eb1ec7c38a802522a9320e508371c9', '123-456-7890', '123 Main St', 'admin');
