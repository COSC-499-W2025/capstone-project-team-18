---
name: Exploration Template
about: Use this template when describing a exploration.
title: ''
labels: Exploration
assignees: ''

---

[Fill out of the following and delete any comments in brackets]

**Description of the Exploration**:


**Questions**: [Should be a something that the student wants to explore]

**Deliverable**: [It can be a document summarizing the results of the exploration, it can be a
comment added to the issues, etc. We need to know how the issue was completed]
