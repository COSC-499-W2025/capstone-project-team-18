---
name: Chore Template
about: Use this template when describing a chore.
title: ''
labels: Chore
assignees: ''

---

[Fill out of the following and delete any comments in brackets]

**Description of the Chore**: 

**What will this benefit?**:

**Deliverable**:
