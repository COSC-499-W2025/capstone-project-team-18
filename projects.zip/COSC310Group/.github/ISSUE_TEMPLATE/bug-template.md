---
name: Bug Template
about: Use this template when describing a bug.
title: ''
labels: Bug
assignees: ''
---

**Describe the bug:**

**To Reproduce:**

**Expected behavior:**

**#ID of the commit where the bug is present:** 

**Severity Level [critical, moderate, low]:** 

**Affected Components and/or features:**
