---
name: User Story Template
about: Use this template when describing a user story.
title: ''
labels: user-story
assignees: ''

---

**User Story**: As a [persona], I want [goal], so that [reason/benefit]

**Acceptance Criteria**: Provide technical and measurable definition of a successful implementation

**Measure of success**:
