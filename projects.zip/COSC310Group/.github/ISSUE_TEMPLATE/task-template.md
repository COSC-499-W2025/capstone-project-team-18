---
name: Task Template
about: Use this template when describing a task that needs to be accomplished.
title: ''
labels: Task
assignees: ''

---

[Fill out of the following and delete any comments in brackets]

**User Story**: [Link the user story that this task came from]

**Description of the task**:

**Acceptance criteria**:  [Should be a lower-level form of the user story. It should be specific and
measurable]

**Validation techniques**: [Find a way to make sure that the acceptance criteria has been met]
