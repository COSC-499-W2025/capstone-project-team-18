# UBCO COSC 310 Group Project - Student Management System - LAASQ (Lex, Alex[0], Alex[1], Sam, Q)

A desktop-based system to manage student records for a small academic institution. The system allows administrators to add, update, and view student information, including their enrolled courses and grades. Students may enroll in courses, update their profiles, and track their academic progress.

To read a <ins>setup guide for local development</ins>, the <ins>admin user manual</ins>, or our <ins>,API documentation</ins>, head over to this repo's [wiki](https://github.com/sjsikora/COSC310Group/wiki/).

## Project Status as of Milestone #3 (03/28/2025)

Nine out of ten functional requirements are completed, with requirement six being the only one left; it is approximately 20% done. 

**Known Bugs**

| Bug                                                                                                            |         Plan for Addressing     | PR for Fix|
| -------------------------------------------------------------------------------------------------------------- | --------------------------------|-----------|
| [Overlapping Visual Elements in Admin Dashboard](https://github.com/sjsikora/COSC310Group/issues/164)          | Resize the dashboard frame      | [#226](https://github.com/sjsikora/COSC310Group/pull/226)|
| [Pressing Tab to enter password on login does not censor characters](https://github.com/sjsikora/COSC310Group/issues/179)| Pressing `Tab` and selecting the password textbox need to be recognized as the same thing    | [#238](https://github.com/sjsikora/COSC310Group/pull/238) |
| [Unnecessary request to API can be made on user profile](https://github.com/sjsikora/COSC310Group/issues/180)  | The client should recognize if the user is already on the sub-frame that they are clicking a button for on the sidebar. For example, a student is on the `edit_current_enrollments` sub-screen and selects the `create_option_edit_current_enrollments()` button. The client should recognize that the student is already viewing that sub-frame and ignore the request.    |[#237](https://github.com/sjsikora/COSC310Group/pull/237) |
|  [Dropping a class from student profile page does not refresh sub-frame](https://github.com/sjsikora/COSC310Group/issues/181) | When a change is made to a student's enrollment status on their profile page, the `edit_current_enrollments` sub-screen should be refreshed to immediatley reflect the change(s) on the client side.  | [#237](https://github.com/sjsikora/COSC310Group/pull/237) |
|  [Transcript can not be Generated For Students that have no Grades](https://github.com/sjsikora/COSC310Group/issues/210) | If a student does not have any grades, their transcript should be generated to reflect this (e.g., a status message or have no `grade` value for each course in the transcript array). | [#236](https://github.com/sjsikora/COSC310Group/pull/236) |
| [Any Transcript Errors will Get Pasted Into the Textbox](https://github.com/sjsikora/COSC310Group/issues/211) | Refactor to display proper images| [#236](https://github.com/sjsikora/COSC310Group/pull/236)|
| [Admin dashboard has wrong title](https://github.com/sjsikora/COSC310Group/issues/217) | Change client-side hardcoded value| [#226](https://github.com/sjsikora/COSC310Group/pull/226)|



App-Wide Testing Results on March 14th 5:57 PM:

<img width="1119" alt="Screen Shot 2025-03-14 at 5 57 48 PM" src="https://github.com/user-attachments/assets/d936b836-2f94-49af-a650-a284d5054696" />


Server-Side Coverage Testing Results on March 28th 12:36 PM:

<p align='center'>
<img width="1285" alt="image" src="https://github.com/user-attachments/assets/e2a534b3-6a5e-496d-b6cf-2154658ff8ff" />
</p>

Client-Side Coverage Testing Results:

<img width="747" alt="Screen Shot 2025-03-30 at 10 05 18 PM" src="https://github.com/user-attachments/assets/59889651-3633-40a6-a576-7597c30e8738" />


